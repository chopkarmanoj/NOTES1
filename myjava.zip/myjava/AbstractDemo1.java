abstract class A{
	abstract void a1();
	abstract void a2();
	abstract void a3();

	void a4(){
		System.out.println("Inside a4 of class A");
	}

	void a5(){
		System.out.println("Inside a5 of class A");
	}
} 


abstract class B extends A{
	void a3(){
		System.out.println("Inside a3 of B class");
	}
}


class C extends B{
	void a2(){
		System.out.println("inside a2 of C class");
	}

	void a1(){
		System.out.println("inside a1 of class C");
	}
}






class AbctractDemo1{
	public static void main(String[] args) {
				
		}	
}