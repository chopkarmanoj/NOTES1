import java.util.*;
import java.text.*;


class DateFormatDemo{
	public static void main(String[] args) {
		Date d = new Date();
		System.out.println("Current date: "+d);

		//DateFormat to format a date

		DateFormat df1 = DateFormat.getDateInstance(DateFormat.SHORT);
		System.out.println("Short date : "+df1.format(d));

		DateFormat df2 = DateFormat.getDateInstance(DateFormat.MEDIUM);
		System.out.println("medium date : "+df2.format(d));

		DateFormat df3 = DateFormat.getDateInstance(DateFormat.LONG);
		System.out.println("LONG date : "+df3.format(d));


		DateFormat df4 = DateFormat.getDateInstance(DateFormat.FULL);
		System.out.println("FULL date : "+df4.format(d));

		


	}
}