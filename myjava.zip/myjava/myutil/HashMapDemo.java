import java.util.*;

class HashMapDemo{
	public static void main(String[] args) {
		HashMap<Integer,String> hm = new HashMap<Integer, String>(); 
	
		hm.put(10,"shivam");
		hm.put(5,"r");
		hm.put(4,"bro");
		hm.put(4,"bo");
	
		System.out.println("hashmap: "+hm);

		System.out.println("val at key :"+hm.get(5));

	}
}