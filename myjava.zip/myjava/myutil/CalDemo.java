import java.util.*;

class CalDemo{
	public static void main(String[] args) {
		Calendar c1 = Calendar.getInstance();
		//System.out.println("Cal " +c1.toString());
		Date d1 = c1.getTime();
		System.out.println("Date: "+d1);

		System.out.println("Day Hour: "+c1.get(Calendar.HOUR_OF_DAY));
		System.out.println("Month: "+c1.get(Calendar.MONTH));


		c1.roll(Calendar.MONTH ,4 );
		System.out.println("after roll: "+c1.getTime());
	}
}