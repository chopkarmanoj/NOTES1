import java.util.*;

class QueueDemo{
	public static void main(String[] args) {
		Queue<Integer> q1 = new Queue<Integer>();
		q1.element(10);
		q1.element(20);
		System.out.println("peek:"+q1.peek());
	}
}