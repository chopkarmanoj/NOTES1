import java.util.*;


class StackDemo{
	public static void main(String[] args) {
		Stack<Integer> st = new Stack<Integer>();

		System.out.println("is stack empty??? "+st.empty());
		st.push(26);
		st.push(64);
		st.push(85);
		st.push(71);
		st.push(62);
		//st.pop();
	
		System.out.println("Stack peek: "+st.peek());

		System.out.println("Sack is: "+st);

		st.pop();

		System.out.println("ele popped:"+st.pop());

		System.out.println("Sack is: "+st);

		System.out.println("is stack empty??? "+st.empty());

		System.out.println("search 64: "+st.search(64));

		System.out.println("search 100:  "+st.search(100));		//returns -1 if search is unsuccessful

		

	}
}