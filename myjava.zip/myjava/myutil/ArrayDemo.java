import java.util.*;

class ArrayDemo{
	public static void main(String[] args) {
		int[] ary = {100,79,40,30,80,45,70};
		Arrays.sort(ary);
		for(int x: ary){
			System.out.println(x);
		}

		System.out.println("Bin search   ele found at: "+Arrays.binarySearch(ary , 80));

		System.out.println("searching ele 50: "+Arrays.binarySearch(ary ,  50));

		int[] ary1 = {10,20,30,50,40,90,130,140,160};
		System.out.println("Array before sort: ");
		for(int x: ary1) System.out.println(x);

		Arrays.sort(ary1,3,6);
		System.out.println("array after Sort: ");
		for(int x:ary1) System.out.println(x);


		System.out.println("After fill: ");
		Arrays.fill(ary1,2,5,2000);
		for(int x:ary1) System.out.println(x);

	
		ArrayList<Integer> a1 =new ArrayList<Integer>();
		a1.add(90);
		a1.add(76);
		a1.add(60);
		a1.add(25);
		a1.add(30);
		a1.add(46);

		System.out.println("array list:" +a1);
		Collections.sort(a1);
		System.out.println("array list sorted:" +a1);




		int[] ary2 = {50,40,30,10,80,90,13};
		List<Integer> mylist = Arrays.asList(ary2);
		System.out.println("list created:"+mylist);

	}
}