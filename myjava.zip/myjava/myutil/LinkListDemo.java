import java.util.*;

class LinkListDemo{
	public static void main(String[] args) {
		LinkedList<String> ll = new LinkedList<String>();
		ll.add("akki");
		ll.add("shubhu");
		ll.add("zyan");
		ll.add("tawale");
		ll.add("manju");

		ll.addFirst("Trupti");
		ll.addLast("cm");

		ll.add(2,"kirr");

		System.out.println("Linked list: "+ll);

		ll.remove("cm");
		System.out.println("list is: "+ll);

		ll.remove(5);
		System.out.println("list is: "+ll);

	}
}