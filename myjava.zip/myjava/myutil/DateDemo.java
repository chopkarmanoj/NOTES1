import java.util.*;

class DateDemo{
	public static void main(String[] args) {
		Date d1 = new Date(1_00000_00_00_000L);
		System.out.println(d1.toString());

		Date d2 = new Date();
		System.out.println("current date:"+d2.toString());

		d2.setTime(d2.getTime() + 3600000);		//time in millisec

		System.out.println("Time :"+d2.toString());


		System.out.println("getDate: "+d2.getDate());
		System.out.println("getDay: "+d2.getDay());
		System.out.println("getHours: "+d2.getHours());
		
		d2.setHours(10);
		System.out.println("after setHours "+d2.toString());

		System.out.println("gmt string :" +d2.toGMTString());

	}
}