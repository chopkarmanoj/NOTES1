import java.util.*;


class ArrayListDemo{
	public static void main(String[] args) {
		ArrayList<Integer> a1 = new ArrayList<Integer>();
		a1.add(10);
		a1.add(20);
		a1.add(30);
		a1.add(98);


		System.out.println(a1);
		System.out.println("Element at index 2: "+a1.get(2));
		System.out.println("Element at index 3: "+a1.get(3));
	
		a1.remove(2);
		System.out.println(a1);


		ArrayList<String> a2 = new ArrayList<String>();
		a2.add("shubhu");
		a2.add("akki");
		a2.add("chaure");
		System.out.println("a2:  "a2);
	
		for (int i; i<a2.size() ; i++) {
			System.out.println("Array size:"+a2.get(i));
		}
	}
}