class SaveMe<T>{		//T stands for type
	T t;

	void setValue(T val){
		t = val;
	}

	T getValue(){
		return t;
	}

}

class GenDemo{
	public static void main(String[] args) {
		SaveMe<String> sm = new SaveMe<String>();
		sm.setValue("Ramukaka");
		System.out.println("sm: "+sm.getValue());

		SaveMe<Integer> sm1 = new SaveMe<Integer>();
		 sm1.setValue(100);	
		System.out.println("sm1:"+sm1.getValue());

//SaveMe<chair> sm2 - new SaveMe<Chair>



	}
}