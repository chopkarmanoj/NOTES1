import java.util.*;


class TokenizerDemo{
	public static void main(String[] args) {
			String s1 = new String();
			s1 = "manoj!akshay#khoshant#shivam=shubham@shubhangi,shefali";
			
			StringTokenizer st1 = new StringTokenizer(s1 , "");


			while(st1.hasMoreTokens()){
				System.out.println("tokens: "+st1.nextToken());
			}

			




	}
}