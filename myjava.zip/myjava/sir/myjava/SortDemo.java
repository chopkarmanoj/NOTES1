class SortMe{
	int[] selectionSort(int[] ary){
		int tmp =0;
		for(int i=0; i<ary.length; i++){
			for(int j=i+1; j<ary.length; j++){
				if(ary[i] > ary[j]){
					tmp = ary[i];
					ary[i] = ary[j];
					ary[j] = tmp;
				}
			}
		}

		return ary;
	}

	void printAry(int[] ary){
		//Enhance For loop...
			//.... Which is applicable to only array.
		for(int x : ary){ // {1,2,3,4,5,6}
			System.out.print(x+" ");
		}
		
		System.out.println();
	}
}

class SortDemo{
	public static void main(String[] args) {
		int[] ar = new int[]{4,3,8,-1,-40,10,0,45,12,67,43,90,87};

		SortMe sm = new SortMe();
		ar = sm.selectionSort(ar);
		sm.printAry(ar);

	}
}