final class Book{
	int cost;
	String name;

	Book(){ // Constructor // this is default because no-param
		cost = 100;
		name = "wings of fire";
	}

	void setCost(int val){
		cost = val;
	}
	void setName(String val){
		name = val;
	}

	int getCost(){
		return cost;
	}
	String getName(){
		return name;
	}

	void displayBook(){
		System.out.println("Book Name : "+getName()+" & cost is : "+getCost());
	}
}

class ConstructorDemo{
	public static void main(String[] args) {
		Book b1 = new Book();
		
		b1.displayBook();
	}
}