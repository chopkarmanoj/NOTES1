interface A{
	void a1();
}
interface B extends A{
	void b1();
}

class C implements B{
	public void a1(){
		System.out.println("inside a1 of C");
	}
	public void b1(){
		System.out.println("inside b1 of C");
	}
}