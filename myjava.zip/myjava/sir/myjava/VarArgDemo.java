class MyAdd{
	int x;
	int y;

	MyAdd(){}

	MyAdd(int... val){
		x = val[0];
		y = val[1];
	}

	void display(){
		System.out.println("X : "+x+" Y : "+y);
	}

	int add(int... x){
		int sum = 0;
		for(int i : x) sum += i;
		return sum;
	}	

	double add(double d , double d1, int... x){ 
		int sum =0 ;
		for(int i : x) sum += i;
		return (sum+d+d1);
	}

	/*int... getRet(){ // Error : Invalid Method Declaration.. Var-Arg can not be the return TYPE.
		int[] ary = {1,2,3,5};

		return (ary);
	}*/


}


class VarArgDemo{
	public static void main(String... args) {
		MyAdd ma = new MyAdd();
		System.out.println("Addn is : "+ma.add(1));
		System.out.println("Addn is : "+ma.add(1,5,6));
		System.out.println("Addn is : "+ma.add(1,5,6,23,45,12,78));

		int[] ary = {10,20,30,40,50,60,70};
		System.out.println("Addn is : "+ma.add(ary));

		System.out.println("Addn is : "+ma.add(10.2,15.23,40,5,65));

		MyAdd ma1 = new MyAdd(10,20);
		ma1.display();
	}
}


/*
	1. Create a MyStack Class, which will accept any number of arguments in the PUSH method.
		your stack should be able to push all the integers provided to push() method.	

*/