class ControlStrDemo{
	public static void main(String[] args) {
		int a = 10;
		int b = 20;

		//System.out.println( a<b ); // true and false (not a 0 or 1)
		if(a > b){
			System.out.println("a is gr");
		}else{
			System.out.println("b is gr");
		}

		if(a == 10){ // a = 10
			System.out.println("inside if");
		}

		if(true) System.out.println("if is true"); //control named block
				//System.out.println(); // not allowed
		else System.out.println("inside else");


		int mytrue = 1;
		int myfalse = 0;

		if(mytrue){ // error
			//-------------1
		}

		if(myfalse){} // error

		if(mytrue = 1) //error

		if(myfalse == mytrue){} // allowed to write
	}
}