class Person{
	int ht;
	int wt;
	String name;

	private Person(){ //Find out, another way to get the instance of a class.
		ht = 5;
		wt = 65;
		name = "Ramkumar";
	}

	static Person getInstance(){
		return new Person();
	}

	void setHt(int val){
		ht = val;
	}
	void setWt(int val){
		wt = val;
	}
	void setName(String val){
		name = val;
	}
	int getHt(){ return ht; }
	int getWt(){ return wt; }
	String getName(){ return name; }
}

class PrivateConstructorDemo{
	public static void main(String[] args) {
		//Person p1 = new Person(); // the Const--or has private access
		Person p1 = Person.getInstance();
		System.out.println(p1.getName());
	}
}