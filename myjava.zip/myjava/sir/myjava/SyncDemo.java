class PrintChar{
	 synchronized void displayChar(){
		System.out.print("{--");
		try{
			Thread.sleep(1000);
		}catch(Exception e){
			e.printStackTrace();
		}
		System.out.print("--}");
	}
}
class MyThread implements Runnable{
	PrintChar pc;
	MyThread(PrintChar p){
		pc = p;
	}
	public void run(){
		pc.displayChar();
	}
}
class SyncDemo{
	public static void main(String[] args) {
		PrintChar pc = new PrintChar();
		MyThread mt = new MyThread(pc);
		//MyThread mt1 = new MyThread();
		Thread t1 = new Thread(mt);
		Thread t2 = new Thread(mt);
		try{
			t1.start();
			t2.start();	
		}catch(Exception e){}

	}
}