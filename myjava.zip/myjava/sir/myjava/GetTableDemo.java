class GetTableDemo{
	public static void main(String[] args) {
		Table t1 = new Table();
		System.out.println("Cost : "+t1.getCost()+ " legs : "+t1.getLegs());
	}
}
