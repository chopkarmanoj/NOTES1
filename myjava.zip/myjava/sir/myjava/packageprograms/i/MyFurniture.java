package i;

public class MyFurniture{
	// Encapsulation suggests : Attributes must be marked either private or protected.
	private int cost;
	private String color;

	public MyFurniture(){
		cost = 500;
		color = "Black";
	}

	protected int getCost(){
		return cost;
	}
	protected String getColor(){
		return color;
	}
}
