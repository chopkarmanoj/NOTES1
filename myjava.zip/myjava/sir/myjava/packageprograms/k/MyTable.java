package k;
import i.MyFurniture;

public class MyTable  extends MyFurniture{
	int legs;
	public MyTable(){
		legs = 4;
	}

	int getLegs(){
		return legs;
	}

	public void displayTable(){
		System.out.println("Cost is : "+getCost()); // NO problem --> bcoz getCost() is protected and MyTabl is-a MyFurniture
		System.out.println("Color is : "+getColor());
		System.out.println("Lges are : "+getLegs());
	}
}