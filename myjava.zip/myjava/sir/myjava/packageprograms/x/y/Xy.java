package x.y;
public class Xy{ // Full Name : x.y.Xy.class
	public void myXy(){
		System.out.println("Reply from myXy method of Class Xy");
	}
	void a1(){ // not visible outside of the package--> bcoz not a public

	}
}

