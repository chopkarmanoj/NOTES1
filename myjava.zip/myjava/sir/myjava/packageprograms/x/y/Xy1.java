package x.y;

public class Xy1{
	public void myXy1(){
		System.out.println("From method myxy1 in class Xy1");
	}
}