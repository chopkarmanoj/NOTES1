package a.b;

class B{ // Full name : a.b.B.class
	public static void main(String[] args) {
		System.out.println("Inside package a -> b -> B class");
	}
}