package a;
class A{ // Full Name : a.A.class
	public static void main(String[] args) {
		System.out.println("Inside package a and class A");
	}
}