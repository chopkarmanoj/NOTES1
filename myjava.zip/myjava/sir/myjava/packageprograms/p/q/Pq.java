package p.q;
//import x.y.Xy; //1
//import x.y.Xy1; //2
// we can use wildcard in import statement

import x.y.*;



class Pq{
	public static void main(String[] args) {
		x.y.Xy x1 = new x.y.Xy(); // Using a full Qualified name : x.y.Xy
		Xy x2 = new Xy(); // It works --> because of class imported by import statement
		Xy1 x3 = new Xy1();

		x1.myXy();
		x2.myXy();
		x3.myXy1();
	}
}