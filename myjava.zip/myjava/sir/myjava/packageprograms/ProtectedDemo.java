import k.*;

class ProtectedDemo{
	public static void main(String[] args) {
		MyTable mt = new MyTable();
		mt.displayTable();
	}
}