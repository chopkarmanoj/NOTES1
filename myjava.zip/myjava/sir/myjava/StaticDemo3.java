class Hourse{
	int ht;

	static int hcnt;


	Hourse(){
		hcnt++;
		ht = 5;
	}
}

class StaticDemo3{
	public static void main(String[] args) {
		Hourse h1 = new Hourse();
		Hourse h2 = new Hourse();
		Hourse h3 = new Hourse();
		Hourse h4 = new Hourse();

		System.out.println("Total Hourses are : "+Hourse.hcnt);

	}
}