import static System.out.*;

class ImportStaticDemo{
	public static void main(String[] args) {
		//System.out.println("Try Static imports..!!");
	}
}