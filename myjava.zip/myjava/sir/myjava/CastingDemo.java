class CastingDemo{
	public static void main(String[] args) {
		byte b = 10;
		short s = b;
		System.out.println(s);

		short s1 = 14;
		int i = s1;

		int i1 = 100;
		long l = i1;

		char c = 'a';
		int i2 = c;
		System.out.println(i2);

		float f = i1;

		float f1 = 32.4f;
		//long l1 = f1; // possible loss of precision
		long l1 = 100;
		float f2 = l1;

		//------------------------UP cast (Explicit) ----------

		short s5 = 10;
		byte b5 = (byte)s5; //explicit
		System.out.println("byte " +b5);

		int i5 = 101;
		s5 = (short)i5;

		double d = 34.45;
		long l5 = (long)d;
		System.out.println(l5);

		char c5 = 'A';
		int i6 = c5; // true

		int i7 = 'A'; // true
		char c6 = 'A' + 3;

		byte b6 = 45; //-128 -- 127
		b6 = (byte) (b6 + 5); // ?????? // flase becoz of byte to int if not casted

		b6 += 5; // +=, -=, *=, /= ---> auto cast // auto Box

		byte b7 = (byte)131;
		System.out.println("byte b7 "+b7);

		long l8 = 989056865586l;

	}
}