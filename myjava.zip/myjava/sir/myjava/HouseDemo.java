class Table{
	int legs;
	int cost;
	Table(){
		legs = 4;
		cost = 500;
	}
	Table(int legs, int cost){
		this.legs = legs;
		this.cost = cost;
	}

	void setLegs(int val){
		legs = val;
	}
	void setCost(int val){
		cost = val;
	}

	int getLegs(){
		return legs;
	}
	int getCost(){
		return cost;
	}
}

class Kitchen{
	int noOfSpoons; // Pre
	int noOfRacks; // Pre
	Table t; // Non Pre

	Kitchen(){
		noOfSpoons = 10;
		noOfRacks = 2;
		t = new Table();
	}
	Kitchen(int s, int r, Table tval){
		noOfSpoons = s;
		noOfRacks = r;
		t = tval;
	}

	void setTable(Table val){
		t = val;
	}
	void setNoOfSpoons(int val){
		noOfSpoons = val;
	}
	void setNoOfRacks(int val){
		noOfRacks = val;
	}

	Table getTable(){
		return t;
	}
	int getNoOfSpoons(){
		return noOfSpoons;
	}
	int getNoOfRacks(){
		return noOfRacks;
	}
}


class House{
	int noOfRooms;
	String name;
	Kitchen k;
	House(){
		noOfRooms = 3;
		name = "Shanti Kunj";
		k = new Kitchen();
	}

	House(int r, String nm, Kitchen kval){
		noOfRooms = r;
		name = nm;
		k = kval;
	}

	void setKitchen(Kitchen val){
		k = val;
	}
	void setNoOfRooms(int val){
		noOfRooms = val;
	}	
	void setName(String val){
		name = val;
	}

	Kitchen getKitchen(){
		return k;
	}
	int getNoOfRooms(){
		return noOfRooms;
	}
	String getName(){
		return name;
	}

	void displayHouse(){
		System.out.println("----------------------------------------");
		System.out.println("House Name is : "+getName());
		System.out.println("No of romms are : "+getNoOfRooms());
		System.out.println("No of Spoons in Kitchen are : "+getKitchen().getNoOfSpoons());
		System.out.println("No of Racks in Kitchen are : "+getKitchen().getNoOfRacks());
		System.out.println("Legs of the table are : "+getKitchen().getTable().getLegs());
		System.out.println("Cost of the table is : "+getKitchen().getTable().getCost());
		System.out.println("----------------------------------------");
	}
}

class HouseDemo{
	public static void main(String[] args) {
		House h1 = new House();
		//Kitchen k1 = new Kitchen();
		//Table t1 = new Table();

		/*t1.setLegs(4);
		t1.setCost(400);

		k1.setNoOfSpoons(10);
		k1.setNoOfRacks(2);
		k1.setTable(t1);

		h1.setName("Girija Palace");
		h1.setNoOfRooms(3);
		h1.setKitchen(k1);*/

		//h1.k.t.setLegs(6); /// <--- it works
		Table t1 = new Table();
		t1.setCost(1000);
		t1.setLegs(6);
		h1.k.setTable(t1);

		h1.displayHouse();


		Table t2= new Table(6, 2000);
		Kitchen k2 = new Kitchen(20,3, t2);
		House h2 = new House(5, "Girija", k2);

		h2.displayHouse();

	}
}