class AryDemo{
	public static void main(String[] args) {
		int ary[] = new int[5]; // constructing an array ...

		//ary[1] = 45;

		for(int i=0; i<ary.length; i++){
			ary[i] = i + 10;
		}

		for(int i=0; i<ary.length; i++) System.out.println("ary "+i+" ele : "+ary[i]);

		int ary1[] = new int[3]; // size is allowed only after new keyword

		int ary2[] = {10,20,30,40,50}; //  <------ JC replace with : int ary2[] = new int[]{10,20,30,40,50};

		int ary3[] = new int[]{10,20,30,40}; // anonymous ary creation

		int ary4[] = new int[4]; //less readable by java 
		int[] ary5 = new int[4]; // recommended way (integer ary type)

		float[] flary = new float[4];

		/*
		Datatypes : 
			1. Primative
			2. Non - Pre


			1. eX : int, float, double, long, char,byte, short
			2. ex : Arrays, String, classes ref( instance )





		*/

	}
}