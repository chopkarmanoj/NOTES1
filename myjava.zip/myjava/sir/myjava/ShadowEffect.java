class ShadowX{
	int x;

	void printX(int x){
		//ShadowX s1 = new ShadowX(); // this
		this.x = x; 
		System.out.println("x inside printx method : "+x); // Shadow effect..( it will print only Local var)
	}

	void printAttr(){
		System.out.println("X attribute : "+x);
	}
}

class ShadowEffect{
	public static void main(String[] args) {
		ShadowX s = new ShadowX();
		s.printX(20);

		s.printAttr();
	}
}