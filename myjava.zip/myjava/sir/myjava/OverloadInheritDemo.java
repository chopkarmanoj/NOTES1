class Vehicle{
	void speed(){
		System.out.println("Speed method of the Vehicle");
	}
	
}  
class FourWheeler extends Vehicle{
	void speed(double c){ // this is  overload version of speed method 
		System.out.println("Overloaded Speed method");
	}
}

class OverloadInheritDemo{
	public static void main(String[] args) {
		FourWheeler fw = new FourWheeler();
		fw.speed();
		fw.speed(12.4);
	}
}