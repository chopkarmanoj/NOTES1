class Fan{
	int cost;
	String brand;

	Fan(){ // default constructor 
		cost = 100;
		brand = "usha";
	}

	Fan(int c, String b){ // overloaded constructor..
		cost = c;
		brand = b;
	}

	Fan(int cost){
		this.cost = cost; // this <--- instance of current class
	}

}

class ConstructorDemo1{
	public static void main(String[] args) {
		Fan f1 = new Fan();
		Fan f2 = new Fan(450, "bajaj");


		Fan f3 = new Fan(254);

		System.out.println("Fan cost f3 : "+f3.cost);
		
		System.out.println(f1.cost+"   "+f1.brand);
		System.out.println(f2.cost+"  "+f2.brand);
	}
}