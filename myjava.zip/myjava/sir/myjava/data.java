Identifiers and literls:

Identifiers : which will identify themselves in the program, uniquely (var)
Literals : Integer (10,20,30 <- base 10 <- decimals) (10101101 <- base 2 <- binary), hexa, oct, floats, char (a,b,c)


Data types: 
	1. byte 
	2. short
	3. int , long
	4. float , double
	5. char

Octal : 0-7
00001 = 1 00007 = 7
00010 = 8
00011 = 9

** Control Structures
	1. Loops  (for , while , do-while)
	2. Non loops -> decision control structures (if , if-else, switch)



int a = 3;
if(a == 3){ //true
	if(a > 3){
		/-/------1
	}else{
		//-------2 -------------------------------
	}
	if(a < 5){ // true
		//--------3  --------------------------------
	}else{
		//--------4
	}

}

if(a == 3){   //----------------only one in the structure can be true
	/---------------1
}else if( a < 5){
	//--------------2
}else if( a >2 ){
	//------------3
}else if(a == 5){
	//------------------4
}




Class and Object :
	Class : IS A COLLECTION OF OBJECT
	Object : TEMPLATE OF A CLASS

	Class :
		1. attributes ( properties ) <---- member of a class
		2. methods ( behaviour ) <---- member of a class

		Ex : Vehicles <--- classification
			vehicle has-a cost -- ( has-a relationship is used to test for attributes)
			------------- color
			------------- company
			------------- no of whleels

			* has-a is a relationship betn class and attributes

			behaviours <--- methods
			--------------- speed 
			--------------- avg


		* always keep set and get methods inside the class to 
			access the class members( attributes )




Array Example :
	int[] ar = new int[3]; // it constructs the array with def val as 0
	ar[0] = 10;

	Table[] tar = new Table[3]; // it constructs the array of type table with def val null
	tar[0] = new Table();


***Access Modifier :
	1. public
	2. private -------------( Class level access ONLY )
	3. protected
	4. default ( there is no keyword as default, so if the modifier is not applied means it is in default access )

Non-Access Modifier :
	1. Abstract ( only method and class can be marked abstract )
	2. Final    ( methods, calss and attributes can be marked final )
				final method ==> can not override
				final variable ==> can be changed once init
				final class ===> can not be inherited( extend )
	3. static

Casting :
	1. Implicit
	2. Explicit

	byte (8)   ranges =---- ?????	
	short (16)
	int (32)
	long (64)
	float (32)
	double (64)
	char (32)

				^			byte				|
				|			short 				|	down Casting( implicit ) auto / loss-less
UP Casting		|	char<--->int ---->float 	|
(Explicit)		|			long ----> double	|
Lossy



Ex : byte b = (int) 131;
 131 bin (8 bit) = 1000 0011
 131 bin (32 bit) = 0000 0000 0000 0000 0000 0000 1000 0011
 Byte (8 bit)  = // only Higher order bits get removed ...
 				= 1000 0011 ( Higher order bit represents -ve sign (sign bit))
 				= 1 <-- sign bit 000 0011 <--- number
 				= 1000 0011 => 0111 1101 --- > -125


*Inheritance :
	1. is-a relationship.
	2. Car is-a Vehicle.


		A      <----- Single level ( Becoz One class has only one Parent )
		^
		|
		|
	X Y Z B    <----- Single level
		|
		|
		C
		|
		|
		D   <---- allowed 


		A    B
		|    |
		|    |
		C	 C  <---- NOT allowed (Multi-level relationship)



		X
		|
		|
		Y
		|
		|
		Z


Costructor :

	1. if you are able to write the const---or, then java will not provide any Cont--or.
	2. In every const---or JAVA will insert a call to super Const---or.
	3. super() -----> Call to super class Const---or
	4. To insert the appropriate call to spuer() Const--or is in programmers hand.. Otherwise compiler will insert a call to super as call to default super constructor [ex : super();]


	5. this ===> current class instance
	6. super ===> Super class instance
	7. super() ====> super class Constructor
	8. this() ====> current class Constructor..

* Ubuntu Software update and install JDK
	1. sudo apt-get update (Sudo --> Super User Do -->> also may ask you the root passwd if u r not a root)
	2. sudo apt-get install default-jdk
		For Test : Check Version ($javac -version) and ($java -version)
	3. sudo apt-get install g++ ( <--- for c++ compiler )

==============***===================

*Final Class 
	1. final class can never be extended. (<====== ***)
	2. final variable can not change its value.
	3. you can never override the final method.

*Abstract Class :
	1. Abstract class must be subclassed.
	2. You can never create the instance of a abstract class.
	3. Abstract class may or may not contain the abstract methods.
	4. Abstract class may also contain its own concrete(Non-abstract) methods.

	NOTE : 1. You can never mark a class as abstract and final both
		   2. You can never mark a method as abstract and private both



***Variable 
	a. local --> ( inside the method )
	b. instance ---> ( inside the class but outside the method ) ... Attr
	c. static ---> ( it is a class specific functionality )

***Static : Method or instance variables(Attr)
	Note : static : class-spec.. ( can be accessed with Class Name)
		   Non - Static : instance method or attr

    1. Statics get loaded when the class get loaded by JVM.
    2. Static get init..ed simillar to normal instance variables with default values.
    3. you can-not access the non-static member in the static context.

***Interface :
	1. interface is 100% abstract super class
	2. so, interface will contain only abstract methods.
	3. interface methods are always public abstract.
	4. variables in interface are always static and final. (they are constants)
	5. A Class must implement the interface 
	   ( for Ex : class A implements B ==> B is the interface and A is a class
	   	          B is also the subclass of interface A ==> B is-a A)

*** Var-Arg :
	1. var-arg (Variable Argument List) method accepts any number of arguments.
		for ex : int add(int... x) <-- this method will accept any no of integers. Min =1 
				 and the x ( <--- Variable Argument) will be treated as ARRAY inside the method.
	2. var-arg also accepts array.
	3. you can replace the argument inside the main method as ==> public staic void main(String... arg){}
	4. var-arg must the last argument in the method.
	5. var-arg can never be used as the return type of the method.
	

*** Package :
	1. package must be the first statement in the source file.
	ex : if you are inside the folder (package) named 'packageex'.
	     then create a .java source inside the package packageex.
	     and define the package : 
	     package packageex; // <---- must be the first statement.
	2. if you want to consider the sub-package
		ex : if you are creating a .java source inside
			a  // <------- package a
			|  
			|
			b  // <------- package b
			|
			|
		 B.java // package statement will be : package a.b;
		 		// and the full qualified name of the class is : a.b.B.class

		Ex : Implement the following example : 
			x 				p 
			|				|
			|				|
			|				q
			y 				|
			|				|
			|				Pq.java
		  Xy.java

		  Problem Statemet : Try to access method of Xy class from Pq.
		  1. In class Pq method main ==> Xy x1 = new Xy();
		  	 // Error : Can not find symbol Xy --> as Xy.class file is not in the current dir.
		     // Solution : Use Full Qualified Name : x.y.Xy
		  2. In class Pq method main ==> x.y.Xy x1 = new x.y.Xy();
		     // Error : Xy is not public, Can not be accessed from outside package.
		  3. we define : public class Xy{}
		     // Error : the class member (i.e. method of the class ) must be marked public
	3. Java says : keep the package name as reverse domain names of your web application.
		Ex: domain name : www.xyz.com ------> pagckage name : package com.xyz.---- (Classes)

	4. 

		Class(private)
		<-------->
		Package (default)
		<---------------------->
		Out side of Package (public)
		<---------------------------------->
		Package (public)					(Protected) but through Inheritance ONLY
		<----------------------------------><.......................................>

	5. Use import statement to avoid writting Full Qualified name of the class evertime in the source file.
	   Ex: in class Pq : ==> import x.y.Xy;

	*Public :
		1. the member and a class if marked public then, it can be accessed outside of the package.
		2. there can be only 'one' public class per source file. (* imp)
		3. if the class marked public then, the class name and source file name must matched.

	6. We can use the import statement with wildcard :
		Ex. import x.y.*; // the statement will import all the classes from package x.y;
	7. java.lang.*; <---- this pagckage is autoimported in every source file.

	*Protected : 
		1. The protected members of the class can be accessed outside of the package in other classes but,
		   'ONLY through Inheritance'.