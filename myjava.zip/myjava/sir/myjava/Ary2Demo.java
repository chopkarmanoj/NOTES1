class Ary2Demo{
	public static void main(String[] args) {
		int[][] ary = new int[3][];

		ary[0] = new int[]{10,20,30};
		ary[1] = new int[]{3,2};
		ary[2] = new int[]{5,6,7,8,9};

		for(int i=0; i<ary.length; i++){
			for(int j=0; j<ary[i].length; j++){
				System.out.print(ary[i][j]+" ");
			}
			System.out.println();
		}


		int[][] ary1 = new int[3][3]; // valid
		//int[][3] ary2 = new int[3][]; // invalid
		//int[][] ary6 = new int[][]; // invalid ... dim missing
		int[] ary3[] = new int[2][]; // valid
		int[][] ary4 = new int[][]{{10,20,30},{20,30,40},{40,50,60}}; // valid

		int[][] ary5 = {{10,20,30},{20,30,40},{40,50,60}}; // valid
 
	}
}