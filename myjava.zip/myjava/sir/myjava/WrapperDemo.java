class WrapperDemo{
	public static void main(String[] args) {
		Integer i1 = Integer.valueOf("101110",2);
	}
}