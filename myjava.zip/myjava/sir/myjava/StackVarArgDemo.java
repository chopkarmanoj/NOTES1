class MyStack{
	int top;
	int[] stk;

	MyStack(int size){
		top = -1;
		stk = new int[size];
	}
	int pop(){
		if(top == -1) System.out.println("No elements to pop out. Sorry.!");
		else return stk[top--];
		return -1;
	}
	void push(int... val){
		for(int x : val){
			if(top == (stk.length)-1){
				System.out.println("Trying to insert : "+x+" But, Stack Full..!!");
				break;
			}else{
				System.out.println("Element pushed : "+x);
				stk[++top] = x;
			}
		}
	}
	void displayStack(){
		System.out.println("------Current Elements in stack-------");
		for(int i=top; i>-1; i--){
			System.out.println("Stack["+i+"] => "+stk[i]);
		}
		System.out.println("-------------------------------");
	}
}
class StackVarArgDemo{
	public static void main(String[] args) {
		MyStack ms1 = new MyStack(10);
		ms1.push(10,20,40,45,43,46,78);
		ms1.push(98,100,34);
		ms1.push(7);
		//pop
		for (int i=0; i<8; i++) {
			System.out.println("Element popped : "+ms1.pop());
		}

		ms1.displayStack();
	}
}