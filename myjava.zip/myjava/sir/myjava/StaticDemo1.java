class Table{
	static int cost;
	int ht;

	static void testTable(){
		System.out.println("inside method testTable");
	}
}

class StaticDemo1{
	public static void main(String[] args) {
		Table t1 = new Table();
		Table t2 = new Table();

		//t1.cost = 400;
		//System.out.println("t1 cost : "+t1.cost+" t2 cost : "+t2.cost);

		System.out.println(Table.cost);
		Table.testTable();
	}
}