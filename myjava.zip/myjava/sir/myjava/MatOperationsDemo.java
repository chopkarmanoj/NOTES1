class MatIperations{
	int[][] addMat(int[][] mat1, int[][] mat2){
		int[][] res = new int[3][];
		//-------------Write the code to add mat


		//-----------finally return the result
		return res;
	}

	int[][] transMat(int[][] mat1){
		int[][] res = new int[3][];
		//-----code for the transpose of a mat


		//------- return the result
		return res;
	}
	void printMat(int[][] mat){
		// code to print the matrix
	}
}

class MatOperationsDemo{
	public static void main(String[] args) {
		
	}
}
