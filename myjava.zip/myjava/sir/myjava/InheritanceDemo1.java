class A{

}
class B extends A{

}

class C extends A{ // Allowed ( as Class C has only one Super Class i.e. A)

}

/*class X extends B,A{ // Not allowed 

}*/


class X{ // class X extends Object

}
class Y extends X{ // Y is-a X
	// I am Inheriting the features from X only
}
class Z extends Y{ // Z is-a Y and Z is-a X
	// I am Inheriting the features from Y as well as X
}

class P{ // Compiler Watch : class P extends Object{
	// Object is a absolute Super Class of Alll...
}

class Abc{ // extends Obj
	void a1(){
		System.out.println("inside a1 of ABC");
	}
}
class Xyz extends Abc{ // Xyz is-a Abc
	// a1 get inherited here...
}

class InheritanceDemo1{
	public static void main(String[] args) {
		Xyz x1 = new Xyz(); // If Abc is Inherited by Xyz ... then it must be true for instanceof test
		Abc a1 = new Abc();

		if(x1 instanceof Abc){ // Test is TRUE becoz Xyz is-a Abc
 			System.out.println("x1 is-a instanceof Abc");			
		}

		if(a1 instanceof Object){
			System.out.println("a1 <-- Abc is-a instanceof of Object");
		}

	}
}