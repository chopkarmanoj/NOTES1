class Person{
	private int ht;
	private int wt;
	private String name;

	// set methods ..
	public void setHt(int val){
		if(val < 1 || val > 7) ht = 2;
		else ht = val;
	}
	public void setWt(int val){
		if(val < 5 || val > 80) wt = 10;
		else wt = val;
	}
	public void setName(String val){
		name = val;
	}

	//get methods ..
	public int getHt(){
		return ht;
	}
	public int getWt(){
		return wt;
	}
	public String getName(){
		return name;
	}

	public void displayPerson(){
		System.out.println("Name of the Person is : "+getName());
		System.out.println("Ht of a Person is : "+getHt());
		System.out.println("Wt of a Person is : "+getWt());
	}

}

class PersonDemo{
	public static void main(String[] args) {
		
		Person p1 = new Person();

		//p1.ht = -10; // error : ht has private access

		p1.setHt(12);
		p1.setWt(65);
		p1.setName("ram");

		p1.displayPerson();

		String[] names = {"Rajkumar","ShamKumar","Ramkumar"};

		Person[] pary = new Person[3];
		for(int i=0; i<pary.length; i++){
			pary[i] = new Person();	 // initilization
			pary[i].setHt(12); // setting attr values
			pary[i].setWt(100); // setting attr values
			pary[i].setName(names[i]); // setting attr values
			pary[i].displayPerson(); // Display person
		}

	}
}