class MyFinal{
	void setX(){
		final int x; 
		x = 10;

		//x = 20; //can not change the value of a variable marked final .. Once they are init
	}
}