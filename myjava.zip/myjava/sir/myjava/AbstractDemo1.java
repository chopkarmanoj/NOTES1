abstract class A{
	abstract void a1();
	abstract void a2();
	abstract void a3();

	void a4(){
		System.out.println("inside a4 of A class");
	}
	void a5(){
		System.out.println("inside a5 of A class");
	}
}

abstract class B extends A{
	void a3(){
		System.out.println("inside a3 of B class");
	}
}
class C extends B{
	void a2(){
		System.out.println("inside a2 of C class");
	}
	void a1(){
		System.out.println("inside a1 of C");
	}
}



abstract class GrandFather{
	void land(){
		System.out.println("inside land of GrandFather");
	}
	abstract void car();
	abstract void house();

}

abstract class Father extends GrandFather{
	void govtJob(){
		System.out.println("Enjoying Govt Job");
	}
	void house(){
		System.out.println("My new House");
	}
	abstract void plot();
}

class Child extends Father{
	void car(){
		System.out.println("my new Car");
	}
	void plot(){
		System.out.println("my new Land");
	}
}





class AbstractDemo1{
	public static void main(String[] args) {
		Child c1 = new Child();
		c1.plot();
		c1.car();
		c1.land();
	}
}