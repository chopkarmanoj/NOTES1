class Animal{ // class can never be private
	private int x; // has access inside class only
	void eat(){ 
		System.out.println("Animal is eating");
	}
}

class PrivateDemo{
	public static void main(String[] args) {
		Animal a1 = new Animal();
		a1.eat(); 
		//a1.x = 10; // it has private access
	}
}