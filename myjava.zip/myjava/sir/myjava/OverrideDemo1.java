class Father{
	void playFootball(){
		System.out.println("Father is playing football");
	}
}
class Child extends Father{
	public void playFootball(){
		System.out.println("Child is playing football");
	}
}