abstract class House{
	void kitchen(){
		System.out.println("Inside Kitchen");
	}

	abstract void hall();
	abstract void bedRoom();
}

class MyHouse extends House{
	void hall(){
		System.out.println("inside Hall");
	}
	void bedRoom(){
		System.out.println("Inside BedRoom");
	}
}

class AbstractDemo{
	public static void main(String[] args) {
		//House h = new House(); //cant be instantiated
		MyHouse mh = new MyHouse();
		mh.hall();
		//mh.bedRoom();
		mh.kitchen();
	}
}