class College{
	int noOfDepts;
	int noOfStuds;

	
	College(int noOfDepts, int noOfStuds){
		this.noOfDepts = noOfDepts;
		this.noOfStuds = noOfStuds;
	}

	void displayCollege(){
		System.out.println("No of Depts in College are : "+noOfDepts);
		System.out.println("No of Studs in College are : "+noOfStuds);
	}
}

class SbJain extends College{
	int noOfTeachers;

	
	SbJain(int d, int s, int t){
		super(d, s);
		noOfTeachers = t;
	}

	void displaySbJain(){
		super.displayCollege();
		System.out.println("No of Teachers in College are : "+noOfTeachers);
	}
}
class ConstructorDemo3{
	public static void main(String[] args) {
		SbJain sb = new SbJain(5, 500, 50);

		//SbJain sb1 = new SbJain(); // fails due to no suitable const--or FOUND

		//sb1.displaySbJain();

		sb.displaySbJain();
	}
}