interface MyStack{
	void push(int x);
	int pop();
}

class MyNewStack implements MyStack{
	//-----------------
}

class MyStackInterfaceDemo{
	public static void main(String[] args) {
		
	}
}