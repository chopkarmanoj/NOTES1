class GenerateSoap{

	final void generate(){
		System.out.println("Soup is generating/..!");
	}
}

class GenerateDetergent extends GenerateSoap{ 
	void generate(){ // error : can not override Final Method
		System.out.println("Detergent is generating..!!");
	}
}