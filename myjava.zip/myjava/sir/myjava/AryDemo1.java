class  Chair{
	int cost;
	String color;

	void init(){
		cost = 200;
		color = "Black";
	}

	void displayChair(){
		System.out.println("Cost : "+cost+" & Color is : "+color);
	}
}

class AryDemo1{
	public static void main(String[] args) {
		Chair c1 = new Chair();

		int[] ary = new int[3]; //<---- construct array on heap with all ele as value zero..
		// print ary[0]

		Chair[] cary = new Chair[3]; //<--- Construct array of type Chair with all ele as null..
		for(int i=0; i<cary.length; i++) cary[i] = new Chair();

		cary[0].init();
		cary[0].displayChair();

		cary[1].displayChair();

	}
}