interface A{
	void abc();
	void xyz();

}

class C{
	void c1(){
		System.out.println("inside C1 of class C");
	}
}

abstract class B extends C implements A{
	public void abc(){
		System.out.println("inside abc of B");
	}	
	
}

class D extends B{
	public void xyz(){
		System.out.println("inside xyz of D");
	}
}