class Furniture{
	void name(){
		System.out.println("inside Name of the Furniture");
	}
}
class Table extends Furniture{
	void name(){
		System.out.println("inside name of Table");
	}
}

class OverrideDemo{
	public static void main(String[] args) {
		
	}
}