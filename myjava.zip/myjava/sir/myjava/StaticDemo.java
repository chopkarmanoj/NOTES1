class MyTable{
	int legs;
	static int cost;
	String color;

	MyTable(){
		legs = 4;
		cost = 100;
		color = "Black";
	}

	static void speak(){
		cost = 50;
		System.out.println("Hi i am Table.. !!");
	}

	void displayMyTable(){
		System.out.println("Legs : "+legs+" cost : "+cost+" color : "+color);
	}

	public static void main(String[] args) {
		MyTable t1 = new MyTable();
		t1.displayMyTable();

		speak();
	}
}
class StaticDemo{
	public static void main(String[] args) {
		MyTable mt1 = new MyTable();
		MyTable mt2 = new MyTable();

		//mt1.cost = 2000; // it works 
		MyTable.cost = 3000; // recommended	
		MyTable.speak();

		mt1.displayMyTable();
		mt2.displayMyTable();
	}
}