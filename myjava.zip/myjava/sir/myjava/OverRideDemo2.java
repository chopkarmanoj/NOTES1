class Animal{
	void eat(){
		System.out.println("animal is eating");
	}
}
class Hourse extends Animal{
	void eat(){
		System.out.println("eating..");
	}	
}


class A{
	A get(){
		A a1 = new A();
		return a1;
	}
}

class B extends A{
	B get(){   // Legal Override
		B b1 = new B();
		return b1;
	} 
}




class OverRideDemo2{
	public static void main(String[] args) {
		Animal a = new Hourse();
		a.eat();

		Hourse h1 = (Hourse) new Animal();
		h1.eat();
	}
}