final class PlayFootball{
	void play(){
		System.out.println("Playing Football");
	}
}

//class PlayCricket extends PlayFootball{ // can not extend the final ClASS

//}