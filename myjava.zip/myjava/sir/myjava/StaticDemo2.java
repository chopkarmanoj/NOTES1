class Chair{
	int legs;

	Chair(){
		legs = 4;
		System.out.println(" Inside def const--or ");
	}

	static{
		System.out.println("inside static block");
	}

	void testChair(){
		System.out.println("inide testChair method ");
	}

	static{
		System.out.println("inside static block  2");
	}

}

class StaticDemo2{
	public static void main(String[] args) {
		Chair c1 = new Chair();
		c1.testChair();
	}
}