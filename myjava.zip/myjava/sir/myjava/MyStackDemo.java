class MyStack{
	int top;
	int[] stk;

	MyStack(){ // change this to constr----or and also write param const--or
		top = -1;
		stk = new int[5];
	}
	MyStack(int size){
		top = -1;
		stk = new int[size];
	} 

	void push(int val){
		if(top == (stk.length-1)) System.out.println("Stack Full..!!");
		else stk[++top] = val;
	}

	int pop(){
		if(top == -1) System.out.println("Stack Empty ");
		else return stk[top--];
		return -1;
	}

}

class MyNewStack extends MyStack{
	
	MyNewStack(){}
	MyNewStack(int size){
		super(size);
	}

	void extendMe(int[] val){
		int[] extended = new int[(val.length)*2];
		for(int x=0; x<val.length; x++) extended[x] = val[x];
		stk = extended;
	}

	void push(int val){
		if(top == (stk.length-1)) extendMe(stk);
		else stk[++top] = val;
	}

	int pick(){
		if(top == -1) System.out.println("Stack Empty : Unable to Pick val on Stack Top");
		else return stk[top];
		return -1;
	}

	void displayStack(){
		System.out.println("------------Current Stack Elements are ---------------");
		if(top == -1) System.out.println("Stak Empty");
		else for(int i=top; i!=-1; i--) System.out.println("Stk["+i+"] = "+stk[i]);
		System.out.println("------------------------------------------------------");
	}
}

class MyStackDemo{
	public static void main(String[] args) {
		MyNewStack ms1 = new MyNewStack();
		//ms1.init();
		ms1.displayStack();
		for(int i=0; i<10; i++) ms1.push(i+10);
		System.out.println("after Push");
		ms1.displayStack();
		for(int i=0; i<3; i++) System.out.println("Popped Ele : "+ms1.pop());	

		ms1.displayStack();

		System.out.println("Element picked : "+ms1.pick());
	}
}