class IdentifierLiteralDemo{
	// instance var // attributes
	static public void main(String[] arr) {
		int a = 10; //local var
		// Integer Literal
			//..decimal
		System.out.println(a);
		int i = 1_00__00; //1.7+ J version 1,00,000 integer separators // improves readiability
		System.out.println(i);

		int h = 0xaa232; // 0x is prefix ..represents hex no.
		System.out.println(h);

		int oct = 0103; // 0 <-- octal prefix 0-7 in range
		System.out.println(oct);

		int bin = 0b100110; //1.7+ 0b <-- is prefix .. represents binary(b - B)
		System.out.println(bin);

		int ____$$$$$_____a______b = 10; // starts with $ and _ is allowed..

		float f = 10.23f; // by default the numbers are double 
		System.out.println(f);

		double d = 34.56;
		System.out.println(d);

		char ch = 'a'; // unicode char set 
	
		System.out.println(ch);

	}
}