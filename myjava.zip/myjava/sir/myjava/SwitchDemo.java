class SwitchDemo{
	public static void main(String[] args) {
		int input = 10;
		boolean b = true; // not allowed in switch
		char ch = 'a';
		long l = 100; // allowed if casted to integer
		float f = 3.14f; // double or float not allowed in switch

		switch(input = 20){
			case 10:
				System.out.println("value is 10");
				break; // break is used to break switch-case and Loops only
			default: // this is optional
				System.out.println("inside def");
				break;
			case 20:
				System.out.println("value is 20");
				break;
			
		}

		String str = "abc";
		switch(str){ // 1.7+ J Version
			case "abc":
				System.out.println("abc");
				break;
			case "AbC":
				System.out.println("AbC");
				break;
		}
	}
}