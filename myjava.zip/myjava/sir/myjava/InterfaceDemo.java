interface MyHouse{
	void hall(); // Interface methods are always public abstract
	public abstract void kitchen();
	int x =10; // Interface variables are always static and final
	static final int y = 20;
}

class TheHouse implements MyHouse{
	public void hall(){
		System.out.println("inside house ..!");
	}
	public void kitchen(){
		//x = 25; // You can never change the value of a final Variable 
		System.out.println("inside kitchen .!");
	}
}

class InterfaceDemo{
	public static void main(String[] args) {
		TheHouse th = new TheHouse();
		th.hall();
		th.kitchen();

		System.out.println("Value of interface var X is : "+MyHouse.x);
		System.out.println("Value of interface var Y is : "+TheHouse.y);

	}
}