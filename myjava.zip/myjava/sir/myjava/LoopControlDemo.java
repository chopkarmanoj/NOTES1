class LoopControlDemo{
	public static void main(String[] args) {
		//int i=0;
		for(int i=0 ; i<5 ; i++){
			System.out.println("i = "+i);
		}

		//int j=0;
		for (int i=0 ; i<5 ; i++ ) { // condition must be boolean
			//---------------------
		}

		//System.out.println(i);
		for(int i=0; i<5 ; i++){
			for(int j=0; j<i; j++){
				//System.out.print(i+""+j+" ");
				System.out.print("*");
			}
			System.out.println();
		}


		int i=0;
		while(i<5){ // condition must be boolean
			i++; // don't forget .. otherwise infinte loop
		}
	}
}