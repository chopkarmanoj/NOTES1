class Clothes{
	void jeans(){
		System.out.println("Mufti Jeans");
	}
}

class MyClothes extends Clothes{
	void jeans(){ // Melts down at run time
		System.out.println("Local Jeans");
	}
}


class PolyDemo{
	public static void main(String[] args) {
		Clothes c = new MyClothes(); // Ploymorphic Behaviour
		c.jeans();
	}
}