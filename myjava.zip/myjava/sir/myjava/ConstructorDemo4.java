class Furniture{
	int legs;
	int cost;
	String type;

	Furniture(){
		legs = 5;
		cost = 100;
		type = "Study Table";
	}

	Furniture(int l, int c){
		legs = l;
		cost = c;
	}


	Furniture(int l, int c, String t){
		this(l,c); // reffered to current class Constructor..
		//legs = l
		//cost = c;
		type = t;
	}
}

class ConstructorDemo4{
	public static void main(String[] args) {
		Furniture f1 = new Furniture();
		Furniture f2 = new Furniture(10, 500, "Tea Table");


		System.out.println("f1 Legs : "+f1.legs+" f1 Cost : "+f1.cost+" Type : "+f1.type);

		System.out.println("f2 Legs : "+f2.legs+" f2 Cost : "+f2.cost+" type : "+f2.type);
	}
}