class Furniture{
	void name(){
		System.out.println("inside Name of the Furniture");
	}
}
class Table extends Furniture{
	void name(){
		System.out.println("inside name of Table");
	}
}

class Animal{
	void eat(){
		System.out.println("Animal is eating");
	}
}
class Horse extends Animal{
	void eat(){
		System.out.println("Horse is eating");
	}
}

class OverrideDemo{
	public static void main(String[] args) {
		Table t1 = new Table();
		t1.name();
		Furniture f = new Furniture();
		f.name();
	}
}