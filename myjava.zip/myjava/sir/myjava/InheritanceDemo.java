class Vehicle{
	private int cost;
	private String color;

	void setCost(int val){
		cost = val;
	}
	void setColor(String val){
		color = val;
	}

	int getCost(){
		return cost;
	}
	String getColor(){
		return color;
	}
	
}

class TwoWheeler extends Vehicle{ // TwoWheeler is-a Vehichle
	String name;
	void setName(String n){
		name = n;
	}

	void displayVehicle(){
		System.out.println("Color of vehicle is : "+getColor()+" & cost is : "+getCost());
		System.out.println("Name of the Vehicle is : "+name);
	}
}

class InheritanceDemo{
	public static void main(String[] args) {
		TwoWheeler tw = new TwoWheeler();
		tw.setColor("Black");
		tw.setCost(25000);
		tw.setName("Activa");
		tw.displayVehicle();
	}
}