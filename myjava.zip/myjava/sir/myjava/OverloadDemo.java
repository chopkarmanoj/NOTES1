class MyAdd{ // class MyAdd extends Object{
	int add(int x , int y){
		return (x+y);
	}
	int add(int x, int y, int z){
		return (x+y+z);
	}

	void add(int a,int b, int c, int d){
		System.out.println(a+b+c+d);
	}

	double add(double d1, double d2){
		System.out.println("inside double double");
		return (d1+d2);
	}

	double add(double d, int i){
		System.out.println("inside double int");
		return (d+i);
	}

	double add(int i, double d){
		System.out.println("inside  int double");
		return (i+d);
	}
}
class OverloadDemo{
	public static void main(String[] args) {
		MyAdd md = new MyAdd();
		System.out.println(md.add(10,20));
		md.add(3,5,7,2);

		System.out.println(md.add(12.2,14.5));
		System.out.println(md.add(12.2, 5));
	}
}