interface MyStack{
	void push(int x);
	int pop();
}

class MyNewStack implements MyStack{
	int top;
	int [] stack;

	void init(){
		top = -1;
		stack = new int[5];
	}


	public void push(int val){
		if(top==(stack.length+1)){
			System.out.println("Stack is overflow");
		}else {
			stack[++top]=val;
		}

	}

	public int pop(){
		if(top==-1){
			System.out.println("Stack is Underfow");
		}else{
			return (stack[--top]);
		}
		return (-1);
	}


	 void display(){
		if(top == -1){
			System.out.println("Stack Empty");
			}else {
				for(int i = top;i!=-1;i--){
				System.out.println("Stack["+i+"] = "+stack[i]);
				}
			}	
	}
}

class MyStackInterfaceDemo{
	public static void main(String[] args) {
		MyNewStack s1 = new MyNewStack();
		s1.init();
		s1.push(5);
		s1.push(10);
		s1.pop();
		s1.push(3);
		s1.push(7);
		s1.push(15);
		s1.pop();
		s1.display();
	}
}