interface A{
	void a1();
}

interface B extends A{
	void b1();
}

abstract class C implements B{
	
	public void a1(){
		System.out.println("inside a1 of C");
	}
	
}

class D extends C{

	public void b1(){
		System.out.println("inside b1 of C");
	}
	
}