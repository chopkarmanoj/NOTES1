class MyAdd{
	int add(int x, int y){	//1
		return(x+y);
	}

	int add(int x,int y,int z){	//2
		return (x+y+z);
	}

	void add(int a,int b, int c,int d){
		System.out.println(a+b+c+d);
	}

	double add(double d1,double d2){		//3
		return(d1+d2);
	}

	double add(double d,int i){		//4
		System.out.println("inside doubl int");
		return(d+i);

	}
}


class OverloadDemo{
	public static void main(String[] args) {
		MyAdd ma = new MyAdd();
		System.out.println(ma.add(10,20));	//1
		System.out.println(ma.add(10,20,30));	//2
	//	System.out.println(ma.add(10,20,30,50));
		System.out.println(ma.add(10.7,15.2));	//3
		System.out.println(ma.add(12.5, 5));		//4(if 4 is not present then it will cast to 3)
	}
}