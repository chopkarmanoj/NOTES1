class Animal{
	void eat(){
		System.out.println("animal is EATING");	}
}

class Horse extends Animal{
	void eat(){
		System.out.println("EATING......");
	}
}




class OverrideDemo2{
	public static void main(String[] args) {
		Animal a = new Horse();
		a.eat();


		Horse h = (Horse) new Animal();
		h.eat();

	}
}






class A{
	A get(){
		A a1 = new A();
			return a1;
	}
}
class B extends A{
	B get(){		//Legel Override
		B b1 = new B();
		return b1;
	}
}