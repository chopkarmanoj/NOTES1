interface A{
	void a1();
	void a2();
}

class D{
	public void a2(){
		System.out.println("inside a2 of D");
	}
}

class C extends D implements A{
	public void a1(){
		System.out.println("inside a1 of C");
	}
}