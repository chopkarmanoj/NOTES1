class MyAdd{
	int x,y;

	MyAdd(){}

	MyAdd(int... val){
			x= val[0];
			y= val[1];
	}

	void display(){
		System.out.println("x: "+x+"   y: "+y);
	}

		int add(int... x){
		int sum = 0;
		for(int i : x) sum += i;
			return sum;
	}

	double add(double d,double d1, int... x ){			//not allowed
		int sum =0;
		for(int i : x) sum += i;
			return (sum+d+d1);
	}

/*	double add(double... d, int... x ){			//not allowed
		int sum =0;
		for(int i : x) sum += i;
			return (sum+d+x);
	}
	}*/

}

class VarArgDemo{
	public static void main(String[] args) {
		MyAdd ma = new MyAdd();
		System.out.println("Addn is : "+ma.add(1));
		System.out.println("Addn is : "+ma.add(1,9));
		System.out.println("Addn is : "+ma.add(1,4,7,9,10));
	
		System.out.println("Addn is : "+ma.add(1.2,12.5,1,9));
//		System.out.println("Addn is : "+ma.add(13.45,15.87,1,9));




		MyAdd ma1 = new MyAdd(10,20,30);
		ma1.display();
	}
}