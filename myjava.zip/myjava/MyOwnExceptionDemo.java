class NegativeNumberException extends Exception{
	public String toString(){
		return "NegativeNuberException : occurs due to -ve no.";
	}
}

class MyOperations{
	void add(int a,int b) throws Exception{
		if(a < 0 || b < 0){
			throw new NegativeNumberException();
		}else{
			System.out.println("Addn of a & b is:"+(a+b));
		}
	}
}

class MyOwnExceptionDemo{
	public static void main(String[] args) {
		MyOperations mo = new MyOperations();
			try{
				mo.add(10,20);
				mo.add(14,30);
				mo.add(-10,30);
				mo.add(40,10);
			}catch(Exception e){
				System.out.println(e);
				//e.printStackTrace();
			}

			System.out.println("End Main");
	}	
}