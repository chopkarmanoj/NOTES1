class WrapperDemo{
	public static void main(String[] args) {
		Integer i1 = new Integer(10);
		Integer i2 = new Integer("23");
		System.out.println("i1 : "+i1);
		System.out.println("i2 : "+i2);

		String strnum = "321";
		int num = 0 ;
		try{
			num = Integer.parseInt(strnum);
			System.out.println("num is: "+num);

			num = Integer.parseInt("100011",2);		//---1----------converts to primitive
			System.out.println("\nnum is: "+num);

			num = Integer.parseInt("abc",16);
			System.out.println("\nnum is: "+num);	
			

			int a = 12;
			String astr = Integer.toBinaryString(a);
			System.out.println("\nBin of a is: "+astr);

			String hex = Integer.toHexString(a);		
			System.out.println("Hex of 12 is: "+hex);

			String oct = Integer.toOctalString(a);
			System.out.println("\nOct of a is: "+oct);


			Integer i3 = Integer.valueOf(10);		//converts primitive to nonprimitive
			System.out.println("\n: "+i3);

			Integer i4 = Integer.valueOf("1100",2);	//----------2----------converts to nonprimitives
			System.out.println("Bin : "+i4);


			int b = 100;
			String bstr = Integer.toHexString(b);
			System.out.println("\nstr from b is: "+bstr);

			String str = Integer.toString(12,16);
			System.out.println("Str is: "+str);



		}catch(NumberFormatException e){
			System.out.println("Given no +"+strnum+"is not in valid format,Enter valid no ");
		}
			
	}
}