class MyTable{
	int legs;
	static int cost;
	String color;

	MyTable(){
		legs = 4;
		cost = 100;
		color= "black";
	}

	static void speak(){
		System.out.println("hi i am Table");
	}
	void displayMyTable(){
		System.out.println("legs: "+legs+" cost: "+cost+" color: "+color);
	}
}

class StaticDemo{
	public static void main(String[] args) {
		MyTable mt1 = new MyTable();
		MyTable mt2 = new MyTable();

		//static
		mt1.cost = 2000;
		MyTable.cost = 3000;	//recommended

		mt1.displayMyTable();
		mt2.displayMyTable();
	}
}