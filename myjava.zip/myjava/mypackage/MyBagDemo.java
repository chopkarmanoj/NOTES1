package mypackage;
	class MyBagDemo{
		public static void main(String[] args) {
			System.out.println("hello this is reply from MyBagDemo");

		}
	}
	



//the full qualified name of class is
//mypackage.MyBagDemo.class