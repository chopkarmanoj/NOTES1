class FinallyDemo{
	public static void main(String[] args) {
		System.out.println("Start of main");
		try{
		//	int a = 10 / 0;
		}  catch(Exception e){
				e.printStackTrace();
		}finally{
			System.out.println("inside finally");
		}




		try{
			int a = 10 / 0;		// program will crash as catch is not present after try.
		} finally{
			System.out.println("inside finally 2");
		}

		System.out.println("End of main");
	}
}