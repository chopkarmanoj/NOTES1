interface MyHouse{
	void hall();	//interface method are always public & abstract
	public abstract void kitchen();
	int x = 10;	//interface var are always static & final
	static final int y = 20;
}

class TheHouse implements MyHouse{
	public void hall(){
		System.out.println("inside hall..");
	}
	public void kitchen(){
	//	x = 25;		//u can never change val of final var
		System.out.println("inside kitchen..");
	}

}

class Interface{
	public static void main(String[] args) {
		TheHouse th = new TheHouse();
		th.hall();
		th.kitchen();

		System.out.println("val of interface : x = "+MyHouse.x);
		System.out.println("val of interface : y = "+MyHouse.y);
	}
}