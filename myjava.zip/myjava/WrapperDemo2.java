class WrapperDemo2{
	public static void main(String[] args) {
			Character c1 = new Character('a');
			System.out.println("c1 : "+c1);

			char ch = 'x';
			System.out.println("ch :"+ch);
		
			System.out.println("is digit : "+Character.isDigit('2'));

			System.out.println("is upper:"+Character.isUpperCase('A'));

			System.out.println("is lowercase:"+Character.isLowerCase('a'));

						//'is' is used to check any particuler condition....

			//System.out.println("is valid code point :" +Character.isValidCodePoint(30.5));

			System.out.println("to upper:"+Character.toUpperCase('l'));

			System.out.println(" upper:"+Character.isUpperCase('A'));
		
			System.out.println("is java identifier start?:"+Character.isJavaIdentifierStart('a'));

		//	char[] chr = Character.toChars(945);
		//	for(char x : ch) System.out.println("char:"+x+" ");



		}	

}