class MyThread extends Thread{
	public void run(){			//makes new callstack
			for(int i = 0 ; i<5; i++){
			System.out.println("i = "+i);
			
			try{
				Thread.sleep(1000);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	}
}

class MyThreadDemo2{
	public static void main(String[] args) {
		MyThread mt1 = new MyThread();
		mt1.start();
			
		for (int i = 0 ; i<5 ; i++ ){
			System.out.println("Main i : "+i);
		}
	}
}