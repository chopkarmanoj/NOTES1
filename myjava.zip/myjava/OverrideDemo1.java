class Father{
	public void playFootball(){
		System.out.println(" father is playing football");

	}
}

class Child extends Father{
	public void playFootball(){
		System.out.println("child is playing football");

	}
}
//superclass (father) javad features kami pahije child(subclass) peksha..
//and subclass (child) javad same nhi tar jast features pahije father peksha...