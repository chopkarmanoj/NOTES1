// Solution for Producer Consumer Problem


class TextMe{
	synchronized void sayHi(){
		System.out.println("hiiiiiiiiii  ");
		try{
			Thread.sleep(2000);
		}catch(Exception e){
			e.printStackTrace();
		}

		System.out.println("Akki");
	}
}


class MyThread implements Runnable{
	TextMe tm;					//applies lock on object
	MyThread(TextMe t){
		tm = t ;
	}
	public void run(){
		//TextMe tm = new TextMe();
		tm.sayHi();
	}
}


class MyThreadDemo4{
	public static void main(String[] args) {
		TextMe t = new TextMe();
		MyThread mt = new MyThread(t);
		

		Thread t1 = new Thread(mt,"Shivam");
		Thread t2 = new Thread(mt,"Sandeep");
		

		t1.start();
		t2.start();
	}
}