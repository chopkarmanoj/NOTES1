class MatOperations{
	int[][] addMat(int[][] mat1, int[][] mat2){
		int[][] res = new int[3][3];
		//.........write the code to add mat

		for(int i=0; i<mat1.length;i++){
			for (int j=0;j<mat1[i].length ;j++ ) {
				res[i][j] = mat1[i][j] + mat2[i][j];
			}
		}

		//...............finally return the result
		return res;

	}
		

	int [][] transMat(int[][] mat1){
		//int[][] res = new int[3][];
		int temp;
		//.......code f d transpose of mat
		for (int i=0;i<mat1.length ;i++ ) {
				for (int j=0;j<mat1[i].length ;j++ ) {
					temp=mat1[i][j];
					mat1[i][j]=mat1[j][i];
					mat1[j][i]=temp;
				}
			
		}

		//...........finally return the result
		return mat1;

	}
		

	void printMat(int[][] mat){
		// code to print matrix

		for(int i=0; i<mat.length;i++){
			for (int j=0;j<mat[i].length ;j++ ) {
				System.out.print(mat[i][j]+" ");
			}
			System.out.println();
		}


	}
}

class MatOperationDemo{
		public static void main(String[] args) {
			int[][] ary1 = new int[][]{{10,20,30},{20,30,40},{20,40,50}};
			int[][] ary2 = new int[][]{{1,2,3},{4,5,6},{7,8,9}};	
			int[][] ary = new int[3][];
			MatOperations m1 = new MatOperations();
			ary = m1.addMat(ary1,ary2);
			System.out.println("matrix 1:\n");
			m1.printMat(ary1);
			System.out.println("matrix 2:\n");
			m1.printMat(ary2);
			System.out.println("\nAfter addition");
			m1.printMat(ary);


			System.out.println("\n\nMatrix:");
			m1.printMat(ary2);
			System.out.println("\nAfter transpose:\n");
			ary = m1.transMat(ary2);
			m1.printMat(ary);
		}
}