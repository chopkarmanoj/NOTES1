class MyThread1 extends Thread{		//MyThread1 is a thread
	public void run(){
		Thread t = Thread.currentThread();
		try{
			for (int i = 0;i<5 ; i++ ){
				System.out.println("By "+ t.getName()+"i : "+i);
				Thread.sleep(1000);	
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}



class MyThreadDemo1{
	public static void main(String[] args) {

		System.out.println("main starts here");

		MyThread1 mt1 = new MyThread1();
		mt1.start();
		try{
			for (int i = 0;i<5 ; i++ ){
				System.out.println("By main"+i);
				Thread.sleep(2000);	
			}
		}catch(Exception e){
			e.printStackTrace();
		}

		
		
		System.out.println("main ends here");
	}
}77