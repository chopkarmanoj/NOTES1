class Furniture{
	int legs;
	int cost;
	String type;

	Furniture(){
		legs = 5;
		cost = 100;
		type="Study Table";
	}

	Furniture(int l,int c){
		legs = l;
		cost = c;
	}

	Furniture(int l,int c,String t){
		this(l,c);
		//legs = l;
		//cost = c;
		type = t;
	}
}



class ConstructorDemo4{
	public static void main(String[] args) {
		Furniture f1 = new Furniture();
		Furniture f2 = new Furniture(10,100,"Tea Table");
	//	Furniture f3 = new Furniture(10,500,);
		
		System.out.println(" f1 Legs: "+f1.legs+" f1 cost: "+f1.cost+" f1 type: "+f1.type);
		System.out.println(" f2 Legs: "+f2.legs+" f2 cost: "+f2.cost+" f2 type: "+f2.type);

	}
}