class Vehicle{
	void speed(){
		System.out.println("Speed method of vehicle");
	}

	void speed(char c){
		System.of.println("Overloaded speed method");
	}
}


class Fourwheeler extends Vehicle{
     
}

class OverloadInheritDemo{
public static void main(String[] args){
	Fourwheeler fw =  new Fourwheeler();
	fw .speed();
	fw.speed(12.4);
}       
}