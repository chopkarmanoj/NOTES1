class CastingDemo{
	public static void main(String[] args) {
		
			///Primitive Casting...

		byte b = 10;
		
		short s = b;
		System .out.println(s);
		
		int i = b;
		System.out.println(i);

		char c = 'a';
		int i1 = c;
		System.out.println(i1);

		float f = i1;
		System.out.println(f);

		float f1 = 38.90f;
	//	long l = f1;		//possible loss of precision
	//	System.out.println(l);

		long l1 =100;
		float f2 = l1;
		System.out.println(f2);

		float f3 = 90.8F;
		double d =f3;
		System.out.println(f3);



		//--------up cast (explicit)-------------
		short s5=10;
		byte b3 = (byte)s5;
		System.out.println("byte"+b3);

		int i5 = 101;
		s5 = (short)i5;
		System.out.println("short "+s5);

		double d6 = 35.75;
		long l5 = (long)d6;
		System.out.println(l5);

		double d7 = 45.67;
		int i7 =(int) d7;
		System.out.println(i7);

		char c5 = 'D';
		byte b7 = (byte)c5;
		System.out.println(b7);

		char c6 = 'A' +3;
		System.out.println(c6);

		byte b6 = 45;
		b6 =(byte) (b6 + 5); //false bcoz yte to int
		System.out.println(b6);
		


		b6+= 5;//	+=, -+, *+, /=----->auto cast
		System.out.println(b6);


		byte b8 = (byte)130;
		System.out.println("byte b8 "+b8);

		







	}
}