//testing Unchecked Exceptions
class MyOperations{
	MyOperations(){
//		new MyOperations();
	}

	int count=0;

	void doStaff(){
		count++;
		display();
		doStaff();
	}
	void display(){
		System.out.print("  "+count);
	}
}

class ErrorDemo{
	public static void main(String[] args) {
	MyOperations m = new MyOperations();
		m.doStaff();
		m.display();
	}
}