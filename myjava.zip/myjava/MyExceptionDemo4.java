class MyExceptionDemo4{
	public static void main(String[] args) {
		int a = 10;
		int[] ary = {1,2,3,4,5,6};


		try{
			int b = a / 0;
			System.out.println("ary of 7 is : "+ary[6]);
		}catch(ArithmaticException | ArrayIndexOutOfBoundsException e){			//allowed in 1.7 jc+ only
				e.printStackTrace();											//allows us to write multi-catch block
		}


/*		try{

		}catch(ArithmaticException | Exception e){		//alternatives in a multi catch statement cannit be related to subclassing		//
	
		}									
*/


	}
}