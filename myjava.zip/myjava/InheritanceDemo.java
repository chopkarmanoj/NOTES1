class Vehicle{
	int cost;
	String color;

	void setCost(int val){
		cost = val;
	}

	void setColor(String val){
		color = val;
	}

	int getCost(){
		return cost;
	}

	String getColor(){
		return color;
	}

}



class Twowheeler extends Vehicle{		//twowheeler is SUBCLASS & vehicle is SUPERCLASS
	String name;
	void setName(String n){
		name = n;
	}



	void displayVehicle(){
		System.out.println("color of vehicle is : "+color+" & cost is "+cost);
		System.out.println("name : "+name);
	}
}


class InheritanceDemo{
	public static void main(String[] args) {

	Twowheeler tw = new Twowheeler();
	tw.setColor("Black");
	tw.setCost(200000);
	tw.setName("Pagani Hyana");
	tw.displayVehicle();		
	}
}

