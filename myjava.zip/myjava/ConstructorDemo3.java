class College{
	int noOfDepts;
	int noOfStuds;

	College(int noOfDepts, int noOfStuds){
		this.noOfStuds = noOfStuds;
		this.noOfDepts = noOfDepts;
	}

	void displayCollege(){
		System.out.println("No. od Deptd in Clg: "+noOfDepts);
		System.out.println("No. of Students in Clg: "+noOfStuds);
	}
}


class Sbjain extends College{
	int noOfTeachers;

	Sbjain(int d,int s,int t){
		super(d,s);
		noOfTeachers = t;
	}

	void displaySbJain(){
		super.displayCollege();
		System.out.println("No. od teachers in Clg: "+noOfTeachers);


	}
}



class ConstructorDemo3{
	public static void main(String[] args) {
		Sbjain sb = new Sbjain(5,500,50);
		sb.displaySbJain();
	}
}