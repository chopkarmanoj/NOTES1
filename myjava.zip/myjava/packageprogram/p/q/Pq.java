package p.q;
//import x.y.Xy;
//import x.y.Xy1;
// we can use wildcard in import statement


import x.y.*;
class Pq{
	public static void main(String[] args) {
		x.y.Xy x1 = new x.y.Xy();	//full qualified name:  x.y.Xy
		Xy x2 = new Xy();	//it works bcoz class imported by import statement..
		Xy1 x3 = new Xy1();

		x1.myXy();
		x2.myXy();
		x3.myXy1();

	}
}