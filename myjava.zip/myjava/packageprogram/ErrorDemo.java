class MyOperations{
	void doStaff(){
		doStaff();
	}
}

class ErrorDemo{
	public static void main(String[] args) {
		MyOperations m = new MyOperations();
		m.doStaff();
	}
}