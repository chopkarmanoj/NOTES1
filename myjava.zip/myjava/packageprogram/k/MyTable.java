package k;

import i.MyFurniture;

public class MyTable extends MyFurniture{
	int legs;
	public MyTable(){
		legs = 4;
	}

	int getLegs(){
		return legs;
	}

	public void displayTable(){
		System.out.println("Cost is "+getCost());
		System.out.println("Color is "+getColor());
		System.out.println("Legs is "+getLegs());
	}
}