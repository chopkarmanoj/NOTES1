package x.y;

public class Xy1{
	public void myXy1(){
		System.out.println("reply from method Xy1 of class Xy1");
	}
}