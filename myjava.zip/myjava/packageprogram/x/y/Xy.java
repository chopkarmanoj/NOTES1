package x.y;
 class Xy{
	public void myXy(){
		System.out.println("Reply from myXy method of class Xy");
	}
}