package a.b;

class B{ // a.b.B.class
	public static void main(String[] args) {
		System.out.println("inside package a->b -> B class");
	}
}