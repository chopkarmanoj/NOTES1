package a;
class A{ // full name : a.A.class
	public static void main(String[] args) {
		System.out.println("inside package a and class A");

	}
}