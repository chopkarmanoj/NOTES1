package i;

public class MyFurniture{
	//Encapsulatio suggest:  Attr must be marked either private or protected
	private int cost;
	private String color;


	public MyFurniture(){
		cost = 500;
		color = "red";
	}


	protected int getCost(){
		return cost;
	}

	protected String getColor(){
		return color;
	}
}