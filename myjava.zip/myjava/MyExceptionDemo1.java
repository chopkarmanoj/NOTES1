class MyExceptionDemo1{
	public static void main(String[] args) {
		int[] ary = new int[3];

		try{
			int a = 10/0;
			System.out.println("array 3rd element: " +ary[3]);
		}catch(Exception e){
			System.out.println("Exception occ");
		}	
	}	
}