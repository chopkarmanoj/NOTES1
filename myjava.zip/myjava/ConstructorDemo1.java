class Fan{
	int cost;
	String brand;

	Fan(){		//default constructor
		cost = 100;
		brand = "usha";
	}

	Fan(int val,String b){	//overloaded Constructor\
		cost = val;
		brand = b;
	}


	Fan(int cost){
		this.cost = cost;		//'this' keyword which seperates instance at call  & current class instance



	}
} 



class ConstructorDemo1{
	public static void main(String[] args) {
		Fan f1 = new Fan();
		Fan f2 = new Fan(450,"bajaj");
		Fan f3 = new Fan(1000);
		System.out.println("cost = "+f1.cost+" Brand= "+f1.brand);
		System.out.println("cost = "+f2.cost+" Brand= "+f2.brand);
		System.out.println("cost = "+f3.cost+" Brand= "+f3.brand);
			 
	}
}