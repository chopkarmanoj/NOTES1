import java.io.*;
class FileDemo1{
	public static void main(String[] args) {
		File f1 = new File("a");
		f1.mkdir();

		File f2 = new File(f1,"xyz.txt");
		File f4 = new File(f1,"xyz2.txt");
		try{
			f2.createNewFile();
			f4.createNewFile();
			
			File f3 = new File(f1,"anewname.txt");
			f2.renameTo(f3);
			
			//File[] fary = File.listRoots();
			//System.out.println("File Root 1: "+fary[0].getName());
			File[] fary = f1.listFiles();
			for(File x : fary) System.out.println("File First in a :"+x.getName()+"<<== is File  ?"+x.isFile());
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}