import java.io.*;

class LineNumberReaderDemo{
	public static void
	 main(String[] args) {
		try{
			FileReader fr = new FileReader("FileWriteDemo1.java");
			BufferedReader br = new BufferedReader(fr);

			LineNumberReader lnr = new LineNumberReader(br);

			String tmp = null;
			while((tmp = lnr.readLine()) !=null);
			{
				System.out.println(lnr.getLineNumber()+" "+tmp);
			
			}
		}catch(Exception e ){ e.printStackTrace();		}
	}
}