import java.io.*;

class PrintWriterDemo{
	public static void main(String[] args) {
		try{
			File fle= new File("Ramukaka.txt");
			PrintWriter pw =new PrintWriter(fle);

			pw.write("Ramukaka Ghar me ho Kya ???? ");
			pw.print(" ramram ");
			pw.println(" ye text println se hai");
			pw.println("EE new line ho sakat hai");
			pw.flush();

			pw.println(100);
			pw.println(12.25);
			pw.println(true);
			pw.println('a');
			//pw.flush();


			int i =40;
			pw.printf("int is %10d",i);
			double d = 16.6868686867644;
			pw.printf("\ndouble id %.6f",d);
			pw.flush();

			pw.close();		//should close file after erforming read / write operation

		}catch(Exception e)  { e.printStackTrace();}
	}
}