import java.io.*;

class MyFileCount{
	public static void main(String[] args) {
		File fle = null;	
		FileReader fr = null;
		 BufferedReader br = null;
		 
		try{
			fle = new File("FileDemo.java");
			fr = new FileReader(fle);
			br = new BufferedReader(fr);
			
		 
				String tmp = null;
				/*
				while( (tmp = br.readLine()) != null){
					c++;
					//System.out.println(tmp);
					System.out.println("length : "+count);
				}
`*/
		int line = 0;
		while(in.hasNextLine()){
			in nextLine();
			line++;
		}

		}catch(Exception e){e.printStackTrace();}
	}	


	}
