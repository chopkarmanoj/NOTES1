import java.io.*;

class FileDemo{
	public static void main(String[] args) {
		File f1 = new File("abc.txt");
		try{
			f1.createNewFile();  
			System.out.println("Is File   ?"+f1.isFile());
			System.out.println("File name is :"+f1.getName());
			//System.out.println("File Parent is : "+f1.getParent());
			System.out.println("is dir ?"+f1.isDirectory());
			System.out.println("Absolute Path:"+f1.getAbsolutePath());
			System.out.println("Canonical Path:"+f1.getCanonicalPath());
			System.out.println("Path: "+f1.getPath());
			System.out.println("Last modified: "+f1.lastModified());
			//f1.delete();

		}catch(Exception e ){e.printStackTrace();}

	}
}