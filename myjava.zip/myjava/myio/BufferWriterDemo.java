//error

import java.io.*;

class BufferWriterDemo{
	public static void main(String[] args) {
		try{
			File fle = new File("newfile.txt");
			FileWriter fw = new FileWriter(fle);
			BufferedWriter bw = new BufferedWriter(fw);
		

		}catch(Exception e ){e.printStackTrace();}
	}
}