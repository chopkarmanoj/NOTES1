import java.io.*;
class MyFileReaderDemo{
	public static void main(String[] args) {
		File fle = new File("abc.txt");
		FileReader fr = null;
		
		try{

			fr = new FileReader(fle);

		/*	char ch =(char)fr.read();
			System.out.println("ch is :"+ch);

			ch =(char)fr.read();
			System.out.println("ch is :"+ch);

		*/


/*
			//way1.
			char ch =' ';

			int tmp = 0;
				while(true){
					tmp =fr.read();
					if(tmp == -1)
						break;
					}
					}else{
						ch =(char)tmp;
						System.out.print(ch);

					}
			}

			*/
		//way2,
		char[] chary = new char[100];//we read complete array using char as array
		fr.read(chary);
		for(char x: chary){
				System.out.print(x);
		}
		}catch(Exception e ){e.printStackTrace();}
	
	}
}
