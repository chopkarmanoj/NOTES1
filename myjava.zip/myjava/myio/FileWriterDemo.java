import java.io.*;

class FileWriterDemo{
	public static void main(String[] args) {
		try{
			File fle = new File("sometext.txt");
			FileWriter fw = new FileWriter(fle);

			//char[] arr='';
			String text = "Hi this text that i want to write in file .";
			fw.write(text);
			fw.write("\n\nRamram");
			//fw.write(arr);
			fw.flush();

		}catch(Exception e ){e.printStackTrace();}
	}
}