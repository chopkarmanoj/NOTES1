import java.io.*;

class MyBufferReaderDemo{
	public static void main(String[] args) {
		File fle = null;	
		FileReader fr = null;
		 BufferedReader br = null;
		try{
			fle = new File("FileDemo.java");
			fr = new FileReader(fle);
			br = new BufferedReader(fr);

				String tmp = null;
				
				while( (tmp = br.readLine()) != null){
					System.out.println(tmp);
					//System.out.println("length : "+l);
				}


		}catch(Exception e){e.printStackTrace();}
	}	


	}
