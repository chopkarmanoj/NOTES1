import java.io.*;

class InputStreamDemo{
	public static void main(String[] args) {
		try{
			InputStreamReader isr = new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(isr);

			String text = br.readLine();
			System.out.println("U just typed: "+text);
		}catch(Exception e ){	e.printStackTrace();	}
	}
}