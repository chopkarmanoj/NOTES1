//	#diy

import java.io.*;

class FileWriteDemo2{
	public static void main(String[] args) {
		File f1 = new File("a1.txt");
		File f2 = new File("a2.txt");
		File f3 = new File("a3.txt");
		File f4 = new File("a4.txt");

		try{
			f1.createNewFile();
			f2.createNewFile();
			f3.createNewFile();
			f4.createNewFile();


		}catch(Exception e){ e.printStackTrace(); }

	}
}