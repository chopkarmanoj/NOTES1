import java.io.*;


class FileWriteDemo1{
	public static void main(String[] args) {
		try{

			File fle = new File("sometext.txt");
			FileWriter fw = new FileWriter(fle,true);		//will make file appendable

			fw.write("hello there ..  i am new text00");
			fw.flush();

		}catch(Exception e ){e.printStackTrace();}


	}

}