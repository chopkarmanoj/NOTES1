import java.io.*;

class Plate implements Serializable{
	String color;

	Plate(String col){
		color = col;
	}
}

class Table implements Serializable{
	int cost;
	int legs;

	Plate p;	//table has a plate

	Table(int c,int l,Plate pt){
		cost = c;
		legs = l;
		p = pt;
	}
}


class SerDemo1{
	public static void main(String[] args) {
	Plate p = new Plate("White pink");
	Table t = new Table(500,4,p);		

	System.out.println("Before Ser:\nTable cost: "+t.cost+" legs : "+t.legs+" color: "+t.p.color);

//Serialization
	try{
		FileOutputStream fos= new FileOutputStream("tablesaved.ser");
		ObjectOutputStream os = new ObjectOutputStream(fos);

		os.writeObject(t);

	}catch(Exception e ){ e.printStackTrace(); }


//Deserialization
	try{
		FileInputStream fis = new FileInputStream("tablesaved.ser");
		ObjectInputStream is = new ObjectInputStream(fis);
		Table tb1 = (Table) is.readObject();
		System.out.println("After Ser:\nTable cost: "+tb1.cost+" legs : "+tb1.legs+" color: "+tb1.p.color);

		}catch(Exception e ){ e.printStackTrace(); }

	}
}