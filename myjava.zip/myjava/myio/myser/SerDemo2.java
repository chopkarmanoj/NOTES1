import java.io.*;


class Chair implements Serializable{
	int cost;
	transient int legs;	//will be marked as 0 & will be omitted..

	Chair(int c, int l){
		cost = c;
		legs = l;
	}
}


class SerDemo2{
	public static void main(String[] args) {
		Chair ch = new Chair(500,4);
		try{
		FileOutputStream fos= new FileOutputStream("chairsaved.ser");
		ObjectOutputStream os = new ObjectOutputStream(fos);

		os.writeObject(ch);

	}catch(Exception e ){ e.printStackTrace(); }


//Deserialization
	try{
		FileInputStream fis = new FileInputStream("chairsaved.ser");
		ObjectInputStream is = new ObjectInputStream(fis);
		Chair ch1 = (Chair) is.readObject();
		System.out.println("After Ser:\nChair cost: "+ch1.cost+" legs : "+ch1.legs);

		}catch(Exception e ){ e.printStackTrace(); }
		
	}
}