import java.io.*;

class Car implements Serializable{
	int cost;
	String name;

	Car(){
		cost = 100;
		name = "Corola";
	}

	void displayCar(){
		System.out.println("Car cost is :"+cost+" name :"+name);
	}
}


class SerializationDemo{
	public static void main(String[] args) {
		Car c1 = new Car();
		//System.out.println(c1);

		try{
			FileOutputStream fis = new FileOutputStream("carsaved.ser");
			ObjectOutputStream os = new ObjectOutputStream(fis);
			os.writeObject(c1);
			System.out.println("your Object state has been saved");

		}catch(Exception e ){ e.printStackTrace(); }

	}
}