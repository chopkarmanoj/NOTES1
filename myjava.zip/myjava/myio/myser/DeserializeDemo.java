import java.io.*;

class DeserializeDemo{
	public static void main(String[] args) {
		try{
			FileInputStream fis  = new FileInputStream("carsaved.ser");
			ObjectInputStream is = new ObjectInputStream(fis);

			Car c = (Car) is.readObject();
			System.out.println("Car cost is :"+c.cost+" name :"+c.name);			

		}catch( Exception e){ e.printStackTrace(); }


	}
}