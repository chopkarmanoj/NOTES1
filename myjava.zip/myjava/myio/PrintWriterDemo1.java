import java.io.*;

class PrintWriterDemo1{
	public static void main(String[] args) {
		try{
			FileWriter fw = new FileWriter("autotest.text");
			PrintWriter pw = new PrintWriter(fw,true);	//will only with println()

			pw.println(" it is Test ");
	}catch(Exception e)  { e.printStackTrace();}
	}
} 