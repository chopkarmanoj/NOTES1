class Chair{
	int cost;
	String color;

	void init(){
		cost = 200;
		color = "Black";
	}

	void displaychair(){
		System.out.println("Cost: "+cost+" & color: "+color );
	}
}


class AryDemo1{
	public static void main(String[] args) {
		Chair c1 = new Chair();

		Chair[] cary = new Chair[3]; 		//Construct ary of type Chair By default value NULL
		for (int i = 0;i<cary.length ; i++) {
			cary[i] = new Chair();
		}

		cary[0].init();
		cary[0].displaychair();

		cary[1].displaychair();
	}
}