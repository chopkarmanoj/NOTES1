class ShadowX{
	int x;

	void printX(int x){
		//	ShadowX s1 = new ShadowX();
		x=x;	//Shadow effect
		System.out.println("x is inside printx method:"+x);
	}

	void printAttr(){
		System.out.println("x attribute:"+x);

	}
}

class ShadowEffect(){
	public static void main(String[] args) {
		
	}
}