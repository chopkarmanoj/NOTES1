class CmdLineAddDemo{
	public static void main(String[] args) {
		System.out.println("args[0] is:"+args[0]);
		System.out.println("args[1] is :"+args[1]);

		String num1 = args[0];
		String num2 = args[1];

		try{
			int a = Integer.parseInt(num1);
			int b = Integer.parseInt(num2);
			System.out.println("addn is : "+(num1+num2));
			System.out.println("addn is : "+(a+b));
		}catch(NumberFormatException e){
				System.out.println("Enter valid no.");
		}
	
	}
}