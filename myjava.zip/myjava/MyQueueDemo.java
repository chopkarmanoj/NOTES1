class MyQueue{
	int[] queue;
	int front;
	int rear;

	MyQueue(){		//change this to constructor   & also write parameterized constructor
		queue = new int[5];
		int front = -1;
		int rear = -1;
	}

	MyQueue(int size){
		queue = new int[size];
		int front = -1;
		int rear = -1;
	}

	void Enqueue(int val){
		if(rear == queue.length-1){
			MynewQueue q2 = new MynewQueue;
			q2.extendMe(queue);
		//	System.out.println("Queue is Overflow");
		}else{
			queue[++rear] = val;
		}
	}


	void Dequeue(){
		if(rear == -1){
			System.out.println("Queue is underflow");
		}else{
			System.out.println("\nelement dequeued = "+queue[rear--]);	
		}
	}
}

class MynewQueue extends MyQueue{

	void extendMe(int[] val){
		int[] extended = new int[(val.length)+2];
		for (int x= 0;x<val.length ;x++ ) {
			extended[x] = vla[x];
		}
		queue = extended;
	}
} 

class PickDisplay extends MyQueue{
	
	int pick(){
		if(front == rear){
			System.out.println("Queue empty");
			return queue[rear];
		}
		return -1;
	}


	void displayQueue(){
		if(front == rear){
			System.out.println("Queue Empty");
			}else {
				System.out.println("Queue:\n");
				for(int i = 1;  i<queue.length;i++){
				System.out.print(queue[i]+"\t");
				}
			}	
	}


}

class extendMe extends 


class MyQueueDemo{
	public static void main(String[] args) {
//		MyQueue q1 = new PickDisplay();
		PickDisplay q1 = new PickDisplay();
//		MyQueue q1 = new MyQueue();
		System.out.println("=====================================");
		q1.displayQueue();
		q1.Enqueue(56);
		q1.Enqueue(31);
		q1.Enqueue(6);
		q1.Enqueue(16);
		q1.Enqueue(40);
		q1.Enqueue(50);
		q1.Enqueue(64);
		System.out.println("=====================================");
		q1.displayQueue();
		q1.Dequeue();
		q1.Dequeue();
		System.out.println("=====================================");
		q1.displayQueue();

	}

}