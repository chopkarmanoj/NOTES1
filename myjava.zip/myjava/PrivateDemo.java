class Animal{	//never  can be private
	private int x; //acess only in class
	private void eat(){			//Private method can be accessed only in that class only & not outside class
		System.out.println("Animal is eating");
	}
}

class PrivateDemo{
	public static void main(String[] args) {
		Animal a1 = new Animal();
		a1.eat();
	}
}