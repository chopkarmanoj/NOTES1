//wap to seperate tokens from given strings which are seperated by ';'. 
//eg: i/p: "Rajkumar;Shamkumar;Ramkumar;Jaikumar"
//o/p: array==> [0] Rajkumar, [1] Shamkumar, [2] Shamkumar, [3] .......so on

class StringProgDemo{
	
}