class Chair{
	int legs;

	Chair(){
		legs = 4;
		System.out.println(" INside def constructor");
	}


	static{
		System.out.println("inside static 1");
	}

	void testChair(){
		System.out.println("inside testChair");
	}

	static{
		System.out.println("inside static 2");
	}
}



class StaticDemo2{
	public static void main(String[] args) {
		Chair c1 = new Chair();
		c1.testChair();
	}
}