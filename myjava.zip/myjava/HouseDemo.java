class Fan{
	int blade;
	String color;

	Fan(){
		blade=4;
		color="black";
		
	}

	Fan(int blade,String color){
		this.blade = blade;
		this.color = color;
	}

	void setBlade(int val){
		blade = val;
	}

	void setColor(String val){
		color = val;
	}

	int getBlade(){
		return blade;
	}

	String getColor(){
		return color;
	}

}



class Table{
	int legs;
	int cost;

	Table(int legs,int cost){
		this.legs = legs;
		this.cost = cost;
	}

	void setLegs(int val){
		legs = val;
	}

	void setCost(int val){
		cost = val;
	}

	int getLegs(){
		return legs;
	}

	int getCost(){
		return cost;
	}
}


class Kitchen{
	int noOfSpoons;	//premative
	int noOfRacks;	//primitive
	Table t;	//Non Premative
	Fan f;

	Kitchen(){
		noOfSpoons=8;
		noOfRacks=3;
		// Table t = new Table();
		 Fan f = new Fan();
	}


	Kitchen(int s,int r, Table ta,Fan fa){
		this.noOfSpoons=8;
		this.noOfRacks=3;
		t = ta;
		f = fa;
	}


	void setFan(Fan val){
		f = val;
	}

	Fan getFan(){
		return f;
	}

	void setTable(Table val){
			t = val;
	}

	Table getTable(){
		return t;
	}


	void setNoOfSpoons(int val){
		noOfSpoons = val;
	}

	void setNoOfRacks(int val){
		noOfRacks = val;
	}

	int getNoOfSpoons(){
		return noOfSpoons;
	}

	int getNoOfRacks(){
		return noOfRacks;
	}
}

class House{
	int noOfRooms;
	String name;
	Kitchen k;

	House(){
		noOfRooms=7;
		name="kalmeshwar";
		k = new Kitchen();	
	}


	House(int n,String s,Kitchen kit){
		n = noOfRooms;
		s = name;
		kit = k ;	

	}

	void setNoOfRooms(int val){
		noOfRooms = val;
	}

	void setName(String val){
		name = val;
	}

	String getName(){
		return name;
	}

	int getNoOfRooms(){
		return noOfRooms;
	}

	void setKitchen(Kitchen val){
		k = val;
	}

	Kitchen getKitchen(){
		return k;
	}

	void displayHouse(){
		System.out.println("------------------");
		System.out.println("House Name is :"+getName());
		System.out.println("No. of Rooms: "+getNoOfRooms());
		System.out.println("No. of SPoons in kitchen: "+getKitchen().getNoOfSpoons());
		System.out.println("No. of Racks in kitchen: "+getKitchen().getNoOfRacks());
		System.out.println("No. of Legs in Table: "+getKitchen().getTable().getLegs());
		System.out.println("Cost of Table: "+getKitchen().getTable().getCost());
		System.out.println("No. Of Blades in fan: "+getKitchen().getFan().getBlade());
		System.out.println("Color of Fan: "+getKitchen().getFan().getColor());
		System.out.println("--------------------");
	}
}

class HouseDemo{
	public static void main(String[] args) {
//		House h1 = new House();
		//Kitchen k1 = new Kitchen();
//		Table t1 = new Table();
//		Fan f1 = new Fan();

/*		f1.setBlade(3);
		f1.setColor("Black");

		t1.setLegs(4);
		t1.setCost(1500);

		k1.setNoOfSpoons(10);
		k1.setNoOfRacks(2);
		k1.setTable(t1);
		k1.setFan(f1);

		h1.setName("Girija Palace");
		h1.setNoOfRooms(3);
		h1.setKitchen(k1);
*/		

	//1.	h1.k.t.setCost(1000);
/*		Table t1 = new Table();
		t1.setCost(1000);
		t1.setLegs(10);
		h1.k.setTable(t1);
*/

		Fan f2 = new Fan(5,"BLack");
		Table t2 = new Table(13,2000);
		Kitchen k2 = new Kitchen(21,6,t2,f2);
		House h2 = new House(4,"akki",k2);
//		h1.displayHouse();
		h2.displayHouse();


	}
}