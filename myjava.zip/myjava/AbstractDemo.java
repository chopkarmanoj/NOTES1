abstract class House{
	void Kitchen(){//concrete method
		System.out.println("inside kichen");//already exist

	}
	abstract void hall();//we want these behavior in our home//abstract method//it not having any implimentaion
	abstract void bedRoom();
}


class MyHouse extends House{
 	void hall(){
 		System.out.println("inside hall");
 	}
 	void bedRoom(){
 		System.out.println("inside bedroom");
 	}
}

 




class AbstractDemo{
	public static void main(String[] args) {
	//House h = new House();//.......cant instantiated
	MyHouse mh = new MyHouse();
	mh.hall();
	mh.Kitchen();
	mh.bedRoom();	
	}
}