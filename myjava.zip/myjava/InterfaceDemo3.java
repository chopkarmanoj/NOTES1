interface A{
	void a1();
}

interface B{
	void b1();
}

class C implements A,B{
	public void a1(){
		System.out.println("a1");
	}

	public void b1(){
		System.out.println("b1");
	}

}