class IdentifierLiteralDemo{
	//attribute instance
	public static void main(String[] args){
		//local variable
		int a =10;//integer
		System.out.println(a);
		
		int i = 1_00__000;//1.7+version      1,00,000 int seperators
		System.out.println(i);
		
		int h = 0xabc345;	//0x is prefix //Hex no.
		System.out.println(h);
	
		int oct = 01023;	//	0 Octal prefix
		System.out.println(oct);

		int  bin = 0b100000;	//	1.7+ 0b binary prefix
		System.out.println(bin);

		int $a15_b;		//	Starts only with '$'' , '_'

		Float f = 3.24f;	//	By default no. are double(.precion)
		System.out.println(f);

		double d = 34.18d;
		System.out.println(d);

		char ch = 'A';	// unicode char set   u000
		System.out.println(ch);

	}
}