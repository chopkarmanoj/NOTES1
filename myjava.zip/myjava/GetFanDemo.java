class GetFanDemo{
	public static void main(String[] args) {
	Fan f1 = new Fan();
		System.out. println("blade :"+f1.getBlade()+ "color :"+f1.getColor());

	}
}