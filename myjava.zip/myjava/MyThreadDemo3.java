class MyThread implements Runnable{
	public void run(){
		try{
			for (int i=0; i< 5 ; i++ ) {
				System.out.println("from:"+Thread.currentThread().getName()+"i ="+i);
				Thread t = Thread.currentThread();
				String name = t.getName();
				if(name.equals("one"))
				Thread.sleep(1000);
			}

		}catch(Exception e){
			e.printStackTrace();
		}
	}
}

class MyThreadDemo3{
	public static void main(String[] args) {
		MyThread mt = new MyThread();
		Thread t1= new Thread(mt,"one");
		Thread t2 = new Thread(mt,"two");
		System.out.println("m starting a Thread");
		t1.start();
		t2.start();
		try{
			t1.join();	// wait for t1 to complete
			t2.join();
		}catch(Exception e){}


		System.out.println("possiblt thread execution will be done");
		System.out.println("main ende here0");
}
}
