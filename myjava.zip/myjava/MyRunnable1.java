class MyUtility{
	void add(int a, int b){
		Thread t = Thread.currentThread();
		System.out.println("add: "+(a+b));
	}

	void multiply(int a,int b){
		Thread t = Thread.currentThread();
		System.out.println("multiply is:"+(a*b));
	}

}

class MyThread implements Runnable{
	public void run(){
		Thread t = Thread.currentThread();
		String name= t.getName();

		MyUtility mu = new MyUtility();

		if(name.equals("One"))  mu.add(10,20);
		if(name.equals("Two")) mu.multiply(2,3);
	}
}

class MyRunnable1{
	public static void main(String[] args) {
		MyThread mt = new MyThread();
		Thread t1 = new Thread(mt,"One");
		Thread t2 = new Thread(mt,"Two");
		t1.start();
		t2.start();	
	}
}