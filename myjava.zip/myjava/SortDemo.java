class SortMe{
		int[] selectionSort(int[] ary){
			int temp=0;
			for(int i=0; i<ary.length;i++){
				for (int j=i+1;j<ary.length ;j++ ) {
					if(ary[i] > ary[j]){
							temp = ary[i];
							ary[i] = ary[j];
							ary[j] = temp;

					}
					
				}
			}

			return ary;

		}

		void printary(int[] ary){
			/*for (int i=0;i<ary.length; i++ ) {
			System.out.print(ary[i]+" ");

			}	*/

			for(int x : ary){// applicable for 1d ary.......enhance for loop
					System.out.print(x+" ");

			}
			System.out.println();
		}
}





class SortDemo{
		public static void main(String[] args) {
			int[] ar = new int[]{4,3,-1,0,6,40,-74,-82,-6,5};

			SortMe sm = new SortMe();
			ar = sm.selectionSort(ar);
			sm.printary(ar);
			
		}
}