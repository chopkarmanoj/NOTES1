class MyStack{
	int top;
	int max;
	int[] s;

	MyStack(){
		top = -1;
		max = 12;
		s = new int[max];	
	}

	void push(int... a){
		for(int i=0;i<a.length;i++){
			if(i==max){
				System.out.println("Stack is overflow....");
				break;
			}
			top++;
			s[top]=a[i];
			System.out.println("Element pushed:"+s[top]+"\n");
			//System.out.println("Element pushed:"+a[i]+"\n");
		}
	}
}


class VarArgStackDemo{
	public static void main(String[] args) {
		MyStack ms = new MyStack();
		ms.push(2,1,3,4,5,6,7,8);
	}
}