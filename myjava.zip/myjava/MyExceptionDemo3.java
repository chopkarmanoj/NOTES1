class SomeErrorsHere{
	void abc() throws Exception{
	//	int a = 10/0 ;
		
	}

	void xyz() throws  Exception{		//Exception Declered here...
		abc();
	}
}



class MyExceptionDemo3{
	public static void main(String[] args) {
		SomeErrorsHere se = new SomeErrorsHere();
		try{
			se.xyz();
		}catch(Exception e){
			System.out.println("exception  occ");
			e.printStackTrace();		//method that will help proggrammer to solve the error by showing
		}
		System.out.println("end main");
	}	
}