//goes in heap
class Person{
	private int ht;
	private int wt;
	private String name;

	//Set methods
	public	void setHt(int  val){
		if(val<1 || val>7){
			ht = 3;
		}else{
			ht = val;
		}
	}

	public void setWt(int val){
		if(val < 5 || val > 100){
			wt = 10;
		}else{
			wt = val;
		}
	}

	public void setName(String val){
		name = val;
	}


	//get methods

	public int getHt(){
		return ht;
	}

	public int getWt(){
		return wt;
	}

	public String getName(){
		return name;
	}


	public void displayPerson(){
		System.out.println("\nHt of person is : "+getHt());
		System.out.println("Wt of person is : "+getWt());
		System.out.println("Name of person is : "+getName());
	}

}





//goes in stack
class PersonDemo{
	public static void main(String[] args) {
		Person p1  = new	Person();		//similar to malloc and attributes in heap will get default value & not contain garbage value
/*		p1.wt = 68;						
		p1.name = "Ramu";

		System.out.println("Height is "+p1.ht+"\nWeight is "+p1.wt+"\nName is "+p1.name);

			//p1 & p2 is ref variable to heap

		Person p2 = new Person();
		p2.ht=5;
		System.out.println("Height is "+p2.ht+"\nWeight is "+p2.wt+"\nName is "+p2.name);
		//zero & null bcoz default value initilizatn
*/	


//Using array of 5 elements
		String[] names ={"Ram","disha","anuja","Nisarg","oopwali"};
		Person[] pary = new Person[5];
		for (int i=0;i<pary.length ;i++ ) {
			pary[i]= new Person();
			pary[i].setHt(30);
			pary[i].setWt(60);
			pary[i].setName(names[i]);
			pary[i].displayPerson();
		}


		// p1.ht=10;	//error as ht is private


		p1.setHt(12);
		p1.setWt(120);
		p1.setName("Shyam");
		p1.displayPerson();
	}
}