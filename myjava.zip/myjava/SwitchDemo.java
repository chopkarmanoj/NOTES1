class SwitchDemo{
	public static void main(String[] args) {
		int input = 10;
		boolean b = true;	//not allowed
		char ch= 'a';
		long l = 100;	// allowed if casted in integer 
		float f = 3.12f;		//not allowed

		switch (input = 20){
				case 10:
					System.out.println("value is 10");
					break;
				case 20:
					System.out.println("value is  20");
					break;
				default:
					System.out.println("value is 20");
					break;
			}	


		String str = "abc";
		switch(str){	//1.7+ j version
			case "abc":
				System.out.println("abc");
				break;
			case "ABC":
				System.out.println("ABC");
				break;

		}
	}
}