interface MyInter{
	void abc();

}

abstract class Abc implements MyInter{

}


class Xyz extends Abc{
	public void abc(){
			System.out.println("inside abc of Xyz ");
	}
}