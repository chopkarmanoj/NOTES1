//synchronized		(goes in infinite loop )


class TableTennis{
	synchronized void hit(){
		try{	
			System.out.println("Hit by:"+Thread.currentThread().getName());
			Thread.sleep(1000);
			notify();
			wait();
		}catch(Exception e){  e.printStackTrace(); }
	}
}

class Player implements Runnable{		//player is thread
	TableTennis tt;
	Player(TableTennis t){
		tt = t;
	}

	public void run(){
		while(true) tt.hit();
	}
}

class TableTennisDemo{
	public static void main(String[] args) {
		TableTennis tt = new TableTennis();
		Player p = new Player(tt);

		Thread t1 = new Thread(p,"Ramu");
		Thread t2 = new Thread(p,"bittya");
		t1.start();	
		t2.start();
	}
}