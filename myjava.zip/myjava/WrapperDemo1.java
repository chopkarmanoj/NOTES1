class WrapperDemo1{
	public static void main(String[] args) {

		int x = 30;

		Integer i1 = new Integer(x);
		System.out.println("i1 Obj.= "+i1);

		int a = i1.intValue();				//convert wrapper 2 primitive
		System.out.println("a = "+a);	

		String str = "1234";
		int mynum = Integer.parseInt(str);
		System.out.println("str = "+str);

		Integer i2 = Integer.valueOf(str);
		System.out.println("i2 Obj. = "+i2);

		int y = 12;
		String ybin=Integer.toBinaryString(y);
		System.out.println("bin of y = "+y+" is "+ybin);

		String mybin = "110011";
		Integer i3 = Integer.valueOf(mybin,2);	//non-primitive
		System.out.println("i3= "+i3);
		int i4 =  Integer.parseInt(mybin,2);	//primitive
		System.out.println("i4 = "+i4);

		
		String numstr = "abc";
		System.out.println("numstr :"+Integer.decode(numstr));
	}
}: