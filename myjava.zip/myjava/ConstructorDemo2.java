class Vehicle{
	int cost;
	String brand;

	Vehicle(){	//default
		//super();			(call to super constructor is inserted by compiler)
		cost = 10000;
		brand= "BULLET";
	}

	Vehicle(int c, String b){
		cost = c;
		brand = b;
	}
}

class MyCar extends Vehicle{
	String color;
	MyCar(){
		//super();			(call to super constructor is inserted by compiler)
		super(550,"Shine");
		color = "Black";
	}

	MyCar(String c){
		super(450,"honda");
		color = c;
	}
}

class ConstructorDemo2{
	public static void main(String[] args) {
		MyCar m1 = new MyCar();

		System.out.println("Cost: "+m1.cost);
	}
}