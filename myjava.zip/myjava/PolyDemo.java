class Clothes{// compile tym is of super class 
	void jeans(){
		System.out.println("mufti jean");

	}
}

class Myclothes extends Clothes{	//	<***********imp//sub class run at run tym
	void jeans(){// melts down at  run time
		System.out.println("local jeans");
	}
}

class PolyDemo{
	public static void main(String[] args) {
		Clothes c = new Myclothes(); // polymorphic behaviour
		c.jeans();

		
	}
}