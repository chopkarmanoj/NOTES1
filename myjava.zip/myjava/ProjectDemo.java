class bank{
	
}