class StringBuilderDemo{
	public static void main(String[] args) {
		StringBuilder sb1 = new StringBuilder("Shantabai");
		System.out.println("sb1: "+sb1);


		sb1.append(" Where r u?");		//mutable object
		System.out.println("sb1: "+sb1);


		char[] chary={'a','b','c','d','e'};
		sb1.append(chary);
		System.out.println("sb1: "+sb1);


		int i=10;
		sb1.append(i);
		System.out.println("sb1: "+sb1);



		sb1.insert(10,"Yoo...");
		System.out.println("sb1: "+sb1);
		

		sb1.delete(10,15);
		System.out.println("sb1: "+sb1);


		sb1.deleteCharAt(21);	//delete 'a'
		System.out.println("sb1: "+sb1);


		sb1.replace(10,16,"kon ahe reee?");
		System.out.println("sb1: "+sb1);


		sb1.reverse();
		System.out.println("sb1: "+sb1);


	//StringBuilder sb2 = new StringBuilder()


		String s1 = new String("kasa kay!!!");	//
		System.out.println("Uppercase : "+s1.toUpperCase());
		StringBuilder sb3 = new StringBuilder(s1);	//
		sb3.append(chary);

		String s2 = sb3.toString();	//get string object from string builder

	}
}