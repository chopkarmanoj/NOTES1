class Hourse{
	int ht;
	static int count;

	Hourse(){
		count++;
		ht = 5;
	}

}
class StaticDemo3{
	public static void main(String[] args) {
		Hourse h1 = new Hourse();
		Hourse h2 = new Hourse();
		Hourse h3 = new Hourse();	
		Hourse h4 = new Hourse();
		Hourse h5 = new Hourse();
		Hourse h6 = new Hourse();
		System.out.println("total Hourses: "+Hourse.count);
	}
}