class Furniture{
	void name(){
		System.out.println("inside name of furniture");
	}
}
class Table extends Furniture{
 void name(){
	 	 System.out.println("inside name of table");

	}
}

class Animal{
		void eat(){
			System.out.println("animal is eating");

		}
}

class Horse extends Animal{
	void eat(){
		System.out.println("horse is eating");
	}
}


class OverrideDemo{	
		public static void main(String[] args){
		Table t1 = new Table();
		t1.name();

	}
}