class MyThread implements Runnable{
	public void run(){
		Thread t1 = Thread.currentThread();
		String name = t1.getName();
		for (int i=0;i<5 ;i++ ) {
			System.out.println("By = "+t1.getName()+"   i ="+i);
			try{
				if(name.equals("Kshitij")) Thread.sleep(1000);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	}
}

class MyRunnable{
	public static void main(String[] args) {
		System.out.println("Main starts Here");
	
		MyThread mt = new MyThread();
		Thread t1 = new Thread(mt);
		Thread t2 = new Thread(mt,"Kshitij");
		Thread t3 = new Thread(mt,"Yo");																												
		t1.start();
		t2.start();
		t3.start();
		System.out.println("main ends here");
	}
}