//CHECKED exception

class MyExceptionDemo{
	public static void main(String[] args) {
		System.out.println("start main");
		String str = null;
		int a = 10;
		int[] ary = new int[3];

		try{
//			System.out.println("ary 4"+ary[3]);					//thease 3 line in try will not be commented to produce Exception
			int b = a/0;
			System.out.println("String len "+str.length());
	//	System.out.println("b:"+b);
		}catch(ArithmeticException e){
			System.out.println("can not div no. by 0");
		}catch(ArrayIndexOutOfBoundsException e){
			System.out.println("Array size is less");
		}catch(Exception e){
			System.out.println("Exception occ");
		}
		System.out.println("end  main");
	}
}