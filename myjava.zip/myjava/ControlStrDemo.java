class ControlStrDemo{
	public static void main(String argv[]){
		int a = 10;
		int b = 20;
		//	System.out.println(a>b);	//true or false
		if(a>b){
			System.out.println("A is greater");
		}
		else{
			System.out.println("B is greater");
		}

		if(true){
			System.out.println("inside if ");
		}
	}

}