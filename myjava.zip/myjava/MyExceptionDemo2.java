class SomeErrorClass{
	void x1(){
		System.out.println("From x1");	
		x2();
		
	}

	void x2(){
		System.out.println("from x2");
		try{										//if we will not write try-catch then error will occour in all functins(can try commenting try-catch )
			x3();
		}catch(Exception e){
			System.out.println("Exception");
//			throw new NullPointerException();		//it will fall down in call stack re-throw exception
		}	
	}
	
	void x3(){
		System.out.println("from x3");
		x4();
	}

	void x4(){
		System.out.println("from x4");
		x5();
	}

	void x5(){
		int a=10/0;
		System.out.println("from x5");

	}
}

class MyExceptionDemo2{
	public static void main(String[] args) {
		SomeErrorClass sm = new SomeErrorClass();
			sm.x1();
/*	try{										//if we will not write try-catch then error will occour in all functins(can try commenting try-catch )
			sm.x1();
		}catch(Exception e){
			System.out.println("Exception");
		}
*/	
	}
}