#include <iostream>
using namespace std;

void merge(int a[],int i1,int j1,int i2,int j2);
void mergesort(int a[],int i, int j);

int main(){
	
}