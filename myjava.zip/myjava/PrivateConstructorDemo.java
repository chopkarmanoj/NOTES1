class Person{
	int ht;
	int wt;
	String name;

	private Person(){		//Find anoyher way to get instance of class
		ht = 5;
		wt = 65;
		name = "Raj";
	}

	static Person getInstance(){
		return new Person();
	}
 
	void setHt(int val){
		ht = val;
	}

	void setWt(int val){
		wt = val;
	}

	void setName(String val){
		name = val;
	}

	int get(){return ht;}
	int getWt(){return wt;}
	String getName(){return namee}
}

class PrivateConstructorDemo{
	public static void main(String[] args) {
		person p1 = Person.getInstance();
		Syst
	}
}