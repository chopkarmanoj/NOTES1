class MyExecDemo{
	void abc() throws Exception{				//  throws to catch the exception
		System.out.println("Reply from abc method of MyExecDemo");
		throw new NullPointerException();				//to throw any User defined Exception..
/*		try{									//1
			throw new NullPointerException();
		}catch(Exception e){

		}
*/
	}
} 




class ThrowDemo{
	public static void main(String[] args) {
		MyExecDemo me = new MyExecDemo();
		try{								//2
			me.abc();
		}catch(Exception e){

		}
	}
}