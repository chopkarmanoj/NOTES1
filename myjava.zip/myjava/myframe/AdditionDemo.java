import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class AdditionApp extends JFrame implements ActionListener{
	JFrame jf = null;
	Container c = null;
	JTextField jt1 = null;
	JTextField jt2 = null;
	JLabel jl3 = null;


	AdditionApp(){
		jf = new JFrame("Addition Application");
		jf.setBounds(100,100,300,250);

		c = jf.getContentPane();
		c.setLayout(null);

		JLabel jl1 = new JLabel("Enter number 1: ");
		JLabel jl2 = new JLabel("Enter number 2 : ");
		jl1.setBounds(20,20,150,20);
		jl2.setBounds(20,60,150,20);

		jt1 = new JTextField();
		jt2 = new JTextField();
		jt1.setBounds(150,20,100,20);
		jt2.setBounds(150,60,100,20);

		jl3 = new JLabel();
		jl3.setBounds(20,100,230,30);

		JButton jb = new JButton("ADD");
		jb.setBounds(20,150,230,30);
		jb.addActionListener(this);

		c.add(jl1);c.add(jl2);
		c.add(jt1);c.add(jt2);
		c.add(jb);c.add(jl3);

		jf.setVisible(true);
	}

	public void actionPerformed(ActionEvent e){
		//System.out.println("action command: "+e.getActionCommand());
		String num1 = jt1.getText();
		String num2 = jt2.getText();

		String result = "";
		try{
		int res = Integer.parseInt(num1) + Integer.parseInt(num2);
		result = "Add of "+num1+" and "+num2+" is    "+res;
		jl3.setText(result);
		jt1.setText("");
		jt2.setText("");
		}catch(NumberFormatException nfe){
			jl3.setText("Please enter integer number.... ");
		}

	}
}


class AdditionDemo{
	public static void main(String[] args) {
		new AdditionApp();
	}
}