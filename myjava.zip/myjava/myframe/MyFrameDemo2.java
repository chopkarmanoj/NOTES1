//to add components in window

import java.awt.*;
import javax.swing.*;

class MyFrame extends JFrame{
	JFrame jf = null;
	Container c = null;

	void getUi(){
		jf = new JFrame("Hi mazi Frame ahe");
		jf.setBounds(200,200,600,400);
		c = jf.getContentPane();		//getting container

		//Layout.....
		c.setLayout(null);

		//components....
		JButton jb1 = new JButton("ok");
		jb1.setBounds(120,250,60,30);

		JLabel jl1 = new JLabel("Enter Name:");
		jl1.setBounds(10,10,150,50);

		JTextField jt1 = new JTextField();
		jt1.setBounds(160,10,250,30);


		JLabel jl2 = new JLabel("Enter Address:");
		jl2.setBounds(10,40,150,50);

		JTextField jt2 = new JTextField();
		jt2.setBounds(160,60,250,70);

		JLabel jl3 = new JLabel("Gender :");
		jl3.setBounds(10,150,70,10);


		JRadioButton jr1 = new JRadioButton("Male");
		JRadioButton jr2 = new JRadioButton("Female");
		jr1.setBounds(160,150,70,10);
		jr2.setBounds(230,150,90,10);
		ButtonGroup bg = new ButtonGroup();
		bg.add(jr1);
		bg.add(jr2);

		JLabel jl4 = new JLabel("Nationality :");
		jl4.setBounds(10,180,150,20);

		String[] list = {"Indian","Pakistan","Dubai","us","Japan"};
		JComboBox jc1 = new JComboBox(list);
		jc1.setBounds(160,180,200,20); 




		//Mounting components...
		c.add(jb1);
		c.add(jl1);
		c.add(jt1);
		c.add(jl2);
		c.add(jt2);
		c.add(jl3);
		c.add(jr1);
		c.add(jr2);
		c.add(jl4);
		c.add(jc1);


		jf.setVisible(true);
	}

}

class MyFrameDemo2{
	public static void main(String[] args) {
		MyFrame mf = new MyFrame();
		mf.getUi();
	}
}