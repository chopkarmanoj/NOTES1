//to create window
// ctrl c to terminate execution of  window..

import java.awt.*;
import javax.swing.*;

class MyFrame extends JFrame{
	JFrame jf = null;
	

	void getUi(){
		jf = new JFrame("this is our windows");
		jf.setVisible(true);
		jf.setBounds(100,100,650,300);	// param:
	}

}

class MyFrameDemo1{
	public static void main(String[] args) {
		MyFrame mf = new MyFrame();
		mf.getUi();

	}
}