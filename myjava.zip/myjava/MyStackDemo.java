class MyStack{
	int top;
	int[] stack;

	void init(){
		top = -1;
		stack = new int[5];
	}


	void push(int val){
		if(top==(stack.length+1)){
			System.out.println("Stack is overflow");
		}else {
			stack[++top]=val;
		}

	}

	int pop(){
		if(top==-1){
			System.out.println("Stack is Underfow");
		}else{
			return (stack[--top]);
		}
		return (-1);
	}


	
}
//void display

class PickDisplay extends MyStack{
	
	int pick(){
		if(top == -1){
			System.out.println("Stack empty: unable to pick val on stack");
		}
		return -1;
			
    }


	void displayStack(){
		if(top == -1){
			System.out.println("Stack Empty");
			}else {
				for(int i = 0;i!=-1;i--){
				System.out.println("Stack["+i+"] = "+stack[i]);
				}
			}	
	}


}

class MyStackDemo{
	public static void main(String[] args) {
		MyStack s1 = new MyStack();
		PickDisplay pd = new PickDisplay();
		s1.init();
		for(int i=0 ; i<5 ; i++ ) 	s1.push(i+10);
			pd.pick();
		for(int i=0 ; i<7 ; i++ )	System.out.println("element popped : "+s1.pop());
		pd.displayStack();	
	}
}