class PrimeDemo{
	public static void main(String[] args) {
		int num = 13,i,count=0;
		for (i=2;i<13;i++ ) {
			
		while(num%i==0){
				count++;
				break;
			}
		}
		if(count==0) {
			System.out.println("No. is prime");
		}else{
				System.out.println(" no. not prime");
		}
	}
}