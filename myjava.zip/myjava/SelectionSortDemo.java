class SelectioSortDemo{
	public static void main(String[] args) {
		int[] ary = new int[4]; 
	}
}