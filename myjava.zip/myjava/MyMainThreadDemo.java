class MyMainThreadDemo{
	public static void main(String[] args) {
		Thread t1 = Thread.currentThread();

		try{
			for (int i=0;i<5 ;i++ ) {
				System.out.println("i = "+i);
				Thread.sleep(20000);	//blocks thread for 2 sce(2000 millisec)
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		

		System.out.println("Thread name is:"+t1.getName());
	
	}
}