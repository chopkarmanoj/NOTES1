class StringDemo{
	public static void main(String[] args) {
		String s1 = new String("Rajkumar");
		String s2 = "Akki ";

		System.out.println("s1: "+s1+"\tS2: "+s2);
	
		s2 = s2.concat("R.");

		System.out.println("S2: "+s2);

		System.out.println("Index of : "+s2.indexOf('i'));	//present
		System.out.println("Index of : "+s2.indexOf('y'));	//not present
	
		System.out.println("Char at : "+s2.charAt(2));
//		System.out.println("Char at : "+s2.charAt(25));	//index out od bound exception

		System.out.println("Uppercase : "+s2.toUpperCase());

		System.out.println("Lowercase : "+s2.toLowerCase());
	
		String s3 = s1.substring(2,5);	//[index(0 based),position(1 based)]
		System.out.println("s3: "+s3);

		s1 = "Rajkumar Shastri";
		System.out.println("s1 starts with: "+s1.startsWith("Raj"));
		System.out.println("s1 starts with: "+s1.startsWith("xyz"));

		System.out.println("s1 ends with: "+s1.endsWith("tri"));
		System.out.println("s1 ends with: "+s1.endsWith("abc"));


		System.out.println("s1 length: "+s1.length());
	

		char[] ary = s1.toCharArray();
		
		for(char ch: ary) System.out.println(ch);

		System.out.println("Replaced string : "+s1.replace('r','x'));

		String email1 = " akki@gmail.com   ";
		String email2 = "akki@gmail.com";
		if(email1.equals(email2)){
			System.out.println("email1 is equals: ");		
		}else{
			System.out.println("email1 is not equals ");
		}

		email1=email1.trim(); //removes space at left & right
		if(email1.equals(email2)){
			System.out.println("email1 is equals: ");		
		}else{
			System.out.println("email1 is not equals ");
		}

		s1 = "Ramu";
		s2 = "ramU";

		if(s1.equalsIgnoreCase(s2)){
			System.out.println("s1 equals to s2");
		}else{
			System.out.println("s1 not equals to s2");
		}

		s1 = "Rajkumar Shastri";
		System.out.println("Last index: "+s1.lastIndexOf('r'));


		String s4 = new String("abc");
		String s5 = new String("abc");	
		if(s4 == s5){							//compares location on heap not content in that string
			System.out.println("s4 equals s5");
		}else{
			System.out.println("s4 not equals to s5");
		}

		// toString();   it is used to get value inside the string object
		s1 = "Who r u ?";
		System.out.println("s1: "+s1);
		System.out.println("string s1 : "+s1.toString());
	

		s5 = "akshay";
		s4 = "shefali";
		System.out.println("Compare s4 & s5: "+s4.compareTo(s5));


		String[] names = {"bunty","Golu","Manoj","bro","Chopkar","Akki","Jaduu"};
		System.out.println("names before sort: ");
		for(String x: names) System.out.println(x+",");
		
		String temp = null;

		for(int i=0 ; i<(names.length) ; i++){
			for(int j=0 ; j<names.length ; j++){
				if(names[i].compareTo(names[j])>0){
					temp = names[i];
					names[i] = names[j];
					names[j] = temp;
				}
			}
		}

		System.out.println("\nAfter :");
		for(String x: names) System.out.println(x+",");


	}
}



//wap to seperate tokens from given strings which are seperated by ';'. 
//eg: i/p: "Rajkumar;Shamkumar;Ramkumar;Jaikumar"
//		o/p: array==> [0] Rajkumar, [1] Shamkumar, [2] Shamkumar, [3] .......so on