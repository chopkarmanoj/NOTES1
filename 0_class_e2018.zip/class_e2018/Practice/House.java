class House{
	private int HouseNo;
	String houseName;
	void setHouseNo(int val){
		HouseNo =val;
	}
	int getHouseNo(){
		return HouseNo;
	}
}