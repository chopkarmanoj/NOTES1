import pack_a.MyPackA;
class AccessPackA{
	public static void main(String[] args) {
		pack_a.MyPackA pa =  new pack_a.MyPackA();

		MyPackA pa1 =  new MyPackA();
		pa.test();
	
	}
}