class Horse{ 
	void eat(){
		System.out.println("reply from eat");
	}
}
