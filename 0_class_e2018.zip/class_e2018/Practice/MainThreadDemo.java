class MainThreadDemo{ //Step1. Create a class MainThreadDemo with main method
	public static void main(String[] args) {
		Thread t = Thread.currentThread(); //We are not creating a new Thread, here we are mapping the current thread to an instance of class Thread i.e t
		System.out.println("Name of Current Thread "+t.getName());
		//try{												
			for(int i=1;i<5;i++){						//Give some work in main to see the working												main thread
				System.out.println("This is Itertion: "+i);
				//t.sleep(1000);						//call sleep method for main thread in try 											  catch block
			}
		//}catch(InterruptedException e){
		//		e.printStackTrace();
		//	}
		}

	}
