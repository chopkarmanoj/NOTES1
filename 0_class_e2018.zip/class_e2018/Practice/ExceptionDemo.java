class ExceptionDemo{
	public static void main(String[] args) {
		try{
			int a = 10 / 0; 	
			System.out.println(a);
		
		}catch(ArithmeticException e){
			System.out.println("inside catch");
		}
	}
}

class ExceptionDemo1{
	public static void main(String[] args) {
		try{
			int  a = 10;
			int b = 0;
			//int c = a / b;

			int[] ary = {10,20,30};

			System.out.println(ary[4]);
		}catch(Exception e){
			e.printStackTrace();
			//System.out.println("Exception caught");
		}
	}
}

class ExceptionDemo2{
	public static void main(String[] args) {
		try{
			int  a = 10;
			int b = 0;
			//	int c = a / b;

			int[] ary = {10,20,30};

			System.out.println(ary[4]);
		}catch(ArithmeticException e){
			e.printStackTrace();
			//System.out.println("Exception caught");
		}catch(ArrayIndexOutOfBoundsException e){
			e.printStackTrace();
		}
	}
}

class ExceptionDemo3{
	public static void main(String[] args) {
		try{
			int  a = 10;
			int b = 0;
			//int c = a / b;

			int[] ary = {10,20,30};

			System.out.println(ary[4]);
		}catch(ArrayIndexOutOfBoundsException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}

class ExceptionDemo4{
	public static void main(String[] args) {
		int  a = 10;
		//int b = 10;
		int b = 0;
		try{
			
			int c = a / b;

			//int[] ary = {10,20,30};

			System.out.println("Value of c="+c);
		}catch(ArithmeticException e){
			e.printStackTrace();
		}finally{
			System.out.println("Reply from finally");
		}
	}
}

class MyHouse{
	void calculateArea(){
		try{
			throw new Exception();
		}catch(Exception e){}
		
	}
}

class ExceptionDemo5{
	public static void main(String[] args) {
		MyHouse h = new MyHouse();
		h.calculateArea();
	}
}
