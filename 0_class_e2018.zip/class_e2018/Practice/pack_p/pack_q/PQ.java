package pack_p.pack_q;
public class PQ{
	public void test(){
		System.out.println("Reply from test of PQ");
	}
}