package i.j;

public class Animal{
	 protected double ht;
	
}
	
