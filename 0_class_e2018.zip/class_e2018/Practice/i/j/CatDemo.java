package i.j;
class Cat extends Animal{
	void setHt(double val){
		ht = val;
	}
}
class CatDemo{
	public static void main(String[] args) {
		Cat c = new Cat();
		c.setHt(4);
		System.out.println("Height ="+c.ht);
	}
}