package i.j;
class AnimalDemo{
	public static void main(String[] args) {
		Animal a = new Animal();
		a.ht = 5;
		System.out.println("Height ="+a.ht);
	}
}