import pack_p.pack_q.*;
class B{
	public static void main(String[] args) {
		pack_p.pack_q.PQ t1 = new pack_p.pack_q.PQ();
		PQ t2 = new PQ();
		t1.test();
		t2.test();
	}
}