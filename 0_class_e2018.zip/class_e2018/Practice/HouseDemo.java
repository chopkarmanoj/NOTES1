class HouseDemo {
	public static void main(String[] args) {
		House h = new House(); 	//Since class House is default so can be accessed within the package and its possible to create instance without inheritance also
		//h.HouseNo = 132;
		h.houseName = "MyHome";
		h.setHouseNo(132);
		//System.out.println("HouseNo ="+h.HouseNo);
		System.out.println("House No."+h.getHouseNo());
		System.out.println("House Name ="+h.houseName);
	}
}