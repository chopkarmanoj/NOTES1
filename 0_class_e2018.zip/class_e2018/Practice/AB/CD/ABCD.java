package AB.CD;
class ABCD{
	void display(){
		System.out.println("From ABCD");
	}
}