package AB.CD;
class ABCDdisplay{
	public static void main(String[] args) {
		ABCD a = new ABCD();
		a.display();
	}
}