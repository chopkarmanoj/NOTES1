class HorseDemo{
	public static void main(String[] args) {
		Horse h = new Horse();
		h.eat();	
	}
}