package mypack;

class MyPackClass{ // Full qualified name of the class is mypack.MyPackClass
	public static void main(String[] args) {
		System.out.println("reply from main of MyPackClass");
	}	
}