class InvalidResult extends Exception{

}

class MyOPerationss{
	void doOperations(int a , int b){
		try{
			int c = a + b;
			if(c != 10) throw new InvalidResult();
			System.out.println("REsult ok i. e. 10");
		}catch(InvalidResult e){
			System.out.println("Exception result is not 10");
		}
	}

	void doOperations1(int a , int b)throws InvalidResult{
		int c = a + b;
		if(c != 10) throw new InvalidResult();
		System.out.println("Result ok");
	}
}

class ExceptionDemo_2{
	public static void main(String[] args) {
		MyOPerationss mo = new MyOPerationss();
		mo.doOperations(5,7);

		try{
			mo.doOperations1(23,34);	
		}catch(InvalidResult r){
			System.out.println("result not ok Exception");
		}
		
	}
}

