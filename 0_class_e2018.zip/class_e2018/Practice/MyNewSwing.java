import javax.swing.*;
import java.awt.*;
class MySwingUI extends JFrame{
	JFrame jf;
	void initializeUI(){
			jf = new JFrame();
			jf.setVisible(true);
	}
}
class MyNewSwing{
	public static void main(String[] args) {
		MySwingUI ui = new MySwingUI();
		ui.initializeUI();
	}
}