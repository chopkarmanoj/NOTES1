package pack_a;

public class MyPackA{ // pack_a.MyPackA
	public void test(){
		System.out.println("reply from test of MyPackA ");
	}
}

