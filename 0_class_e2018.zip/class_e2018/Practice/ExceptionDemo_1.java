class MyOperations{
	void a1(){
		System.out.println("reply from a1");
		a2();
	}
	void a2(){
		System.out.println("reply from a2");
		a3();
	}
	void a3(){
		System.out.println("reply from a3");
		a4();
	}
	void a4(){
		System.out.println("reply from a4");
		// try{
		a5();	
		// }catch(Exception e){
		// 	//e.printStackTrace();
		// }
	}
	void a5()throws Exception{	
		System.out.println("reply from a5");
		int a = 10 / 0;
	}
}
class ExceptionDemo_1{
	public static void main(String[] args) {
		MyOperations mo = new MyOperations();
		mo.a1();	
		System.out.println("main ends");	
	}

}