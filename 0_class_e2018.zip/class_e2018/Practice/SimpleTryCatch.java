class DivideZero{
	static int anyFunction(int x,int y){
		int ret = -1;
		try{
			int a=x/y;
			ret = a;
		}catch(ArithmeticException e){
			System.out.println("a=x/y is bypassed, enter a non-zero value for y");
		}	
		return ret;
	}
}
class SimpleTryCatch{
	public static void main(String[] args) {
		int result = DivideZero.anyFunction(5,0);
		System.out.println("Result ="+result);
	}
}