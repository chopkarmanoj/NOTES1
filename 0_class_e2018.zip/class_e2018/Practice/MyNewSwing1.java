import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
class MySwingUI extends JFrame implements ActionListener{
	JFrame jf;
	Container c;
	JTextField jt1;
	JTextField jt2;
	JLabel jl1;
	JLabel jl2;
	JButton jb;

	void initializeUI(){
			jf = new JFrame("My First Swing Program"); //Add Caption via Constructor;
			
			c = jf.getContentPane(); //gives the container of the Frame
			c.setLayout(null);	

			jt1 = new JTextField();
			jt2 = new JTextField();
			jl1 = new JLabel("Enter Your Name");
			jl2 = new JLabel("Enter Year of admission");
			jb = new JButton("OK");
			
			jl1.setBounds(30,30,100,50);
			jl2.setBounds(30,50+30+10,100,50);
			jt1.setBounds(150,40,400,50);
			jt2.setBounds(150,80,400,50);
			jb.setBounds(200,170,80,30);


			jb.addActionListener(this);

			jf.setBounds(100,100,1000,1000);

			
			c.add(jt1); c.add(jl1);
			c.add(jt2); c.add(jl2);
			c.add(jb);
						// Setting Boundaries of the Frame
			jf.setVisible(true);					//setVisible should always be the last method 

	}

	public void actionPerformed(ActionEvent ae){
		// System.out.println("Hello");
		// System.out.println("action command :"+ae.getActionCommand());
		// System.out.println("source : "+ae.getSource());

		if(ae.getActionCommand().equals("OK")){
			System.out.println("ok clicked");
			String val = jt1.getText();
			System.out.println("text field input : "+val);
		}
	}
}
class MyNewSwing1{
	public static void main(String[] args) {
		MySwingUI ui = new MySwingUI();
		ui.initializeUI();
	}
}