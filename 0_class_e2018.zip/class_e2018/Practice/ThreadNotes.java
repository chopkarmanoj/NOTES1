Program Under Execution :Process
Process Under Execution :Thread
By default when we execute any JAVA program so JVM calls the main thread.
All the threads are by default an object of Thread class defined in java.lang.*
Example1: To demonstrate how main method executes via main Thread

Example2: To create a new user defined Thread

When multiple user define threads execute the same run method they are said as multiple threads of same process.

Explain the Thread Life Cycle