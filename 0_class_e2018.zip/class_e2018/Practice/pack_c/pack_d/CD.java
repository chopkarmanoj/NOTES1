package pack_c.pack_d;

//import pack_p.pack_q.*;

public class CD{
	public static void main(String[] args) {
		pack_p.pack_q.PQ t1 = new pack_p.pack_q.PQ();
		t1.test();
	}
}