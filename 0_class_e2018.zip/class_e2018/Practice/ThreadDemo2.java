class MyThread implements Runnable{
	public void run(){
		Thread t = Thread.currentThread(); //Returns current thread under exceution
		//System.out.println(t.getName());

		try{
			for(int i=0; i<5; i++){

				System.out.println(t.getName()+" "+i);
				t.sleep(1000);
			}
		}catch(InterruptedException e){
			e.printStackTrace();
		}
	}
}

class ThreadDemo2{
	public static void main(String[] args) {
		MyThread mt1 = new MyThread(); // instance of runnable 

		Thread t1 = new Thread(mt1, "Test Thread");
		t1.start();
	}
}