Private: Package_House-->House.java-->class House-->private int HouseNo
Package_House-->HouseDemo.java-->class HouseDemo-->main-->Instance of House-->Access to HouseNo using instance of House(via methods)
	Only members are private

Default: Package_House-->House.java-->class House-->private int HouseNo--> String houseName;
Package_House-->HouseDemo.java-->class HouseDemo-->main-->Instance of House-->Access to HouseNo using instance of House(via methods)
																			  Access to houseName using instance of House(without methods)
	

Public: Package_House-->House.java-->class House-->private int HouseNo--> String houseName --> public String areaName;
		Outside Package_House-->HouseDemo1.java-->class HouseDemo1-->main-->Instance of House (gives an error  as class House is not public) 
		After class is made public only public members of the class will be accessed outside package . ex: areaName

Protected: Animal and Dog