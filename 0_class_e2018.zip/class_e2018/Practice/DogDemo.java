import i.j.*;

class Dog extends Animal{
	void setHt(double val){
		ht = val;
	}
	double getHt(){
		return ht;
	}

}

class DogDemo{
	public static void main(String[] args) {
		Dog d = new Dog();
		d.setHt(4.5);
		
		System.out.println("height = "+d.getHt());
	}
}

Protected accessible outside package also by using inheritance
Protected (acts as Default) are accessible within package only (without inheritance)