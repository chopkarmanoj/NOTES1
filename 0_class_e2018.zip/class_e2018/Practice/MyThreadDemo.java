class MyThread extends Thread{
		public void run(){	//method definition is public void hence we also need to give it public access
			Thread t = Thread.currentThread();
			try{
			for(int i=0; i<5; i++){

				System.out.println(t.getName()+" "+i);
				t.sleep(1000);
			}
			}catch(InterruptedException e){
			e.printStackTrace();
		}

		}
}
class MyThreadDemo{
	public static void main(String[] args) {
		MyThread mt1 = new MyThread();   			//Since MyThread extends Thread we can create an instance of MyThread which will behave same as a Thread
		mt1.setName("MyThread");		//Used to set name of Thread
		mt1.start();
		try{
			for(int i=0; i<5; i++){

				System.out.println(Thread.currentThread().getName()+" "+i);
				Thread.currentThread().sleep(500);
			}
		}catch(InterruptedException e){
			e.printStackTrace();
		}
		System.out.println("main ends");

	}
}