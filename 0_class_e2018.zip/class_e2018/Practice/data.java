Packages :
	--> packages are used to bundle the classes
	--> it separates the classes according to its functionalitites 
	--> it also helps developer to give the meaning full name to the group of functionality dependent classes
		-- you keep movies in movies folder
		-- songs in songs folder
			-- to make search easy -- easily accessable 
	--> in every project of java you must use package to separate the classes ( bundle the classes )
		and make easily accessable and understandable to the developers working on other module of the project

	--> in every java program you wrote, there is a default pacakge imported by Java itself
		-- java.lang
		-- which includes the java lang specific and the basic impotant functi onalitites ( System, String, Thread)

	--> How package get imported ?
	--> How packages are created ?

	--> likewise in C lang we include #include<stdio.h> library to use printf and scanf
	--> in java we import the package insted include it.

	* Creating Packages 
		--> In java package is nothing but a folder, which contains all the class files
			- ( may also contains the java source file but, recommended to keep only class files)
		--> create any folder and write you java classes inside the folder

		--> In java source file, the package must be the first statement.
			-- for ex : package mypack;
			(means your source file must be inside the folder name mypack)
			Java understands that, he should consider the package for the source file as mypack

	Examples:
	1) A simple class with main within package (package statement)
	2) A class inside package, being accessed by another class with main outside package (full qualified name + import statement)
	3) A class inside package within package accessed by another class with main outside package
	4) A class inside package within package accessed by A class inside package within package
	5) When to use import 
		--If we are accessing the file within the same package then we don't need to write the import statement or full qualified name.
		
    6) Example of public keyword
	7) Example of protected keyword via inheritance




	 			

