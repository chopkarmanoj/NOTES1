class AccessXYDemo{
	public static void main(String[] args) {
		x.y.InsideXYDemo x1 = new x.y.InsideXYDemo(); // if a class is inside package then full qualified filename should be used
		x1.test();
	}
}