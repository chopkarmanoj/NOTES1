class AccessCDDemo{
	public static void main(String[] args) {
		c.d.InsideCDDemo cd = new c.d.InsideCDDemo();
		cd.test();
	}
}