package a.b;
class InsideBDemo{
	public static void main(String[] args) {
	System.out.println("Hey..Reply from InsideB");	
	}
	
}