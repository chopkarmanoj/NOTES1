package a;
class InsideADemo{
	public static void main(String[] args) {
		System.out.println("Hey..  this is reply from InsideADemo and package a ");
		System.out.println("Hello World!!");
	}
}