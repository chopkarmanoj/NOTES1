package c.d;
public class InsideCDDemo{
			public void test(){
				System.out.println("Reply from test of c.d.InsideCD");
		}
}