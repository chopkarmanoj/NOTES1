package k.l;
public class InsideKL{
	public void doSomething(){
		System.out.println("Reply from doSomething of InsideKL");
	}
	
}