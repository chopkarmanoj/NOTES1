import j.l.*;
import k.l.*;
class InsideKLJL{
	public static void main(String[] args) {
		InsideJL i1 = new InsideJL();
		InsideKL i2 = new InsideKL();
		i1.go();
		i2.doSomething();
	}
}