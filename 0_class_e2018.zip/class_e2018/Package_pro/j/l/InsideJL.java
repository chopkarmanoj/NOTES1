package j.l;
public class InsideJL{
	public void go(){
		System.out.println("Reply from go method of InsideJL");
	}
}