package mypack;
class TestPAckDemo{
	public static void main(String[] args) {
		System.out.println("Reply from main of TestPackDemo");
	}
}