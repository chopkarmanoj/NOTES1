package x.y;
public class InsideXYDemo{ //if class  is to be used outside the package then it has to be maerked public
			public void test(){ // if method is to be used outside the package then it has to be maerked public
			System.out.println("Inside test of x.y.InsideXYDemo");
	}
}