package e.f;
public class InsideEF{
	public int x = 10;
	public void test(){
		System.out.println("Reply from test of InsideEF");
	}
}