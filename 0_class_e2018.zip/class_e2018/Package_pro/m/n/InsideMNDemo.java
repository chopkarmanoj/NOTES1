package m.n;
import e.f.*;
class InsideMNDemo{
	public static void main(String[] args) {
		InsideEF i = new InsideEF();
		System.out.println("x is "+i.x);
		i.test();
	}
}