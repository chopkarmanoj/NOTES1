//To avoid using full qualified name of the files within different package we can use the import statement
import OuterDemo.MyTest; //import i.* will import all classes from package i
class AccessOuterDemo{
	public static void main(String[] args) {
		MyTest mt = new MyTest();
		mt.Test();
	}
}