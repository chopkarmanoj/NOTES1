package OuterDemo;
public class MyTest{
	public void Test(){
		System.out.println("Reply from test of OuterDemo.MyTest");
	}

}