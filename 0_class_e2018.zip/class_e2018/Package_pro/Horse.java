import n.*;
class Horse extends Animal{// class Animal could be inherited as its marked public
void display(){
	System.out.println("Horse height is "+height);
}

}
class ProtectedDemo{
	public static void main(String[] args) {
		Horse h1 = new Horse();
		h1.display();
	}
}