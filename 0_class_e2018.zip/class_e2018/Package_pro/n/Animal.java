package n;
public class Animal{
	protected int height = 20;
}