class Furniture{
	final void color(){
		System.out.println("Furniture Color is Black");
	}
}

class Table extends Furniture{
	// void color(){
	// 	System.out.println("Table's color is white");
	// }
}

class FinalMethodDemo{
	public static void main(String[] args) {
		Table t = new Table();
		t.color();
	}
}