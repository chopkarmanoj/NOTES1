class Animal{
	void eat(){
		System.out.println("Animal is eating");
	}
}

class Horse extends Animal{
	void eat(){
		super.eat(); // Super is the instance of super class
		System.out.println("Horse is eating");
	}
}
class ConstructorDemo4{
	public static void main(String[] args) {
		Horse h1 = new Horse();
		h1.eat();
	}
}