class PersonDetails{
	String fullname;
	PersonDetails(String fullname){
		this.fullname = fullname;
	}

	String getFirstName(){
		return fullname.substring(0,fullname.indexOf(' ')+1);

	}

	String getLastName(){
		return fullname.substring(fullname.indexOf(' ',fullname.indexOf(' ')+1));
	}

	// String getMiddleName(){

	// }

}

class PersonDetailsDemo{
	public static void main(String[] args){
		PersonDetails p1 = new PersonDetails("Rajkumar Hira Nandani");
		System.out.println(p1.getFirstName());
		System.out.println(p1.getLastName());
	}
}