import javax.swing.*;

public class TestFrameDemo{
	public static void main(String[] args) {
		JFrame j1 = new JFrame();
		JFrame j2 = j1;
		JFrame j3 = j2;

		j1.setVisible(true);
		j2.setVisible(true);

		j3.setVisible(true);

	}
}