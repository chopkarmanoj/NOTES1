import javax.swing.*;
import java.awt.*;


class MyFrame extends JFrame{
	void getUI(){
		JFrame jf1 = new JFrame("Welcome to Swing Frame");
		Container c = jf1.getContentPane();
		c.setLayout(null);

		int x = 20, y = 20, w = 180, h = 33;
		//step 1 : creating component
		JButton jb1 = new JButton("OK"); 
		JLabel jl1 = new JLabel("Enter Full Name");
		JLabel jl2 = new JLabel("Enter Mobile No.");
		JTextField jt1 = new JTextField(); // SLE : Single line edit
		JTextField jt2 = new JTextField();
		JLabel jl3 = new JLabel("Enter Address"); 
		JTextArea ja1 = new JTextArea(); // MLE : Multiline edit
		JRadioButton jr1 = new JRadioButton();
		JRadioButton jr2 = new JRadioButton();
		JLabel jl4 = new JLabel("Gender");
		JLabel jl5 = new JLabel("Nationality");
		//JCheckbox


		String[] nats = {"Indian", "German", "British", "French","Pakistani"};
		JComboBox jcb1 = new JComboBox(nats); 
		
		//step 2 : setting bonuds to component
		jb1.setBounds(50, 350, 90, 33); 
		jl1.setBounds(x, y, w, h);
		jl2.setBounds(x, y+h+10, w, h);
		jt1.setBounds(x+w+20, y, w, h);
		jt2.setBounds(x+w+20, y+h+10, w, h);
		jl3.setBounds(x, y+h+h+20, w, h);
		ja1.setBounds(x+w+20, y+h+h+20, w, h+90);
		jl4.setBounds(x, y+(3*h)+120, w, h);
		jr1.setBounds(x+w+20, y+(3*h)+120, 30,30);
		jr2.setBounds(x+w+20+50, y+(3*h)+120, 30,30);
		jl5.setBounds(x,y+(4*h)+120,w,h);
		jcb1.setBounds(x+w+20,y+(4*h)+120,w,h);

		


		//This is for single selection of radiobutton
		ButtonGroup bg = new ButtonGroup();
		bg.add(jr1);
		bg.add(jr2);


		//step 3 : adding component to the container of the frame
		c.add(jb1); c.add(jt1);
		c.add(jl1); c.add(jt2);
		c.add(jl2); c.add(jl3);
		c.add(ja1); c.add(jr2);
		c.add(jr1); c.add(jl4);
		c.add(jl5); c.add(jcb1);


		jf1.setBounds(100,100, 550,500); // x,y,w,h	
		jf1.setVisible(true);
	}
}

class MyFrame2Demo{
	public static void main(String[] args) {
		MyFrame mf = new MyFrame();
		mf.getUI();
	}
}

// Swing : 
// 	--> desktop application development framework.
// 	--> for events on the frame swing will use the AWT (abstract window toolkit)

