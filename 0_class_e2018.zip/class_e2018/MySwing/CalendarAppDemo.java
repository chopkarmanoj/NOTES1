import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class CalendarApp extends JFrame implements ActionListener{
	JFrame jf = null;
	JLabel jl1 = null;
	JLabel jl2 = null;
	JLabel jl3 = null;
	JLabel jl4 = null;
	JTextField jt1 = null;
	JTextField jt2 = null;
	JTextField jt3 = null;
	JButton jb1 = null;
	Container c = null;
	




	CalendarApp(){
		int x = 50, y = 50, w = 80, h = 33;
		jf = new JFrame("Calendar App");
		c = jf.getContentPane();
		c.setLayout(null);


		jl1 = new JLabel("Enter Date : ");
		jt1 = new JTextField();
		jl2 = new JLabel("Enter Month : ");
		jt2 = new JTextField();
		jl3 = new JLabel("Enter Year : ");
		jt3 = new JTextField();
		jl4 = new JLabel();
		jb1 = new JButton("Get The Day !!!");

		jl1.setBounds(x,y,w,h);
		jt1.setBounds(x+w+20,y,w,h);
		jl2.setBounds(x,y+h+20,w,h);
		jt2.setBounds(x+w+20,y+h+20,w,h);
		jl3.setBounds(x,y+(2*h)+40,w,h);	
		jt3.setBounds(x+w+20,y+(2*h)+40,w,h);
		jl4.setBounds(x,y+(h*4)+30,w+w+20,h);
		jb1.setBounds(x,y+(h*5)+30,w+w+50,h);


		jb1.addActionListener(this);	// this indicates the class of that object which is implementing the addActionListner. In this case its the CalendarApp


		c.add(jl1); c.add(jt1);
		c.add(jl2); c.add(jt2);
		c.add(jl3); c.add(jt3);
		c.add(jl4); c.add(jb1);

		jf.setBounds(100,100, 490,350);
		jf.setVisible(true);
	}
	public void actionPerformed(ActionEvent ae){
		if(ae.getActionCommand().equals("Get The Day !!!")){
						
			String s1 = jt1.getText();
			String s2 = jt2.getText();
			String s3 = jt3.getText();
			int n1 = 0 ,n2 = 0,n3 = 0,yy = 0,mk = 0,ce = 0,cc = 0,res = 0,le = 0 ;
			
			try{
				 n1 = Integer.parseInt(s1);
				 if(n1>1&&n1<32){
				 	System.out.println("Date Entered n1 : "+n1);
				 }else{
				 	System.out.println("Enter Proper Date");
				 	//Program Termination
				 }
				 
			}catch(NumberFormatException nfe){
				System.out.println("Please enter the date in proper format");
			}
			try{
				 n2 = Integer.parseInt(s2);
				 if(n2>0&&n2<13){
				 	System.out.println("Month Entered n2 : "+n2);
				 }else{
				 	System.out.println("Enter Proper Month");
				 }
				 
				if(n2==1||n2==10){
					mk = 1;
				}else{
					if(n2==2||n2==3||n2==11){
					mk = 4;
					}else{
						if(n2==4||n2==7){
							mk = 0;
						}
						else{
							if(n2==5){
								mk = 2;
							}else{
								if(n2==6){
									mk = 5;
								}else{
									if(n2==8){
										mk = 3;
									}else{
										mk = 6;
									}
									
								}
							}
						}

					}

				}
				System.out.println("Month's Key : "+mk);

			}catch(NumberFormatException nfe){
				System.out.println("Please enter the month in proper format");
			}
			

			try{
				 n3 = Integer.parseInt(s3);
				 System.out.println("Year Entered n3 : "+n3);

				 if(n3 % 4 == 0)
			        {
			            if( n3 % 100 == 0)
			            {
			                // year is divisible by 400, hence the year is a leap year
			                if ( n3 % 400 == 0)
			                    le = 1;
			                else
			                    le = 0;
			            }
			            else
			                le = 1;
			        }
			        else
			            le = 0;


				 if(le == 1)
           		 System.out.println(n3 + " is a leap year.");
       			 else
            	 System.out.println(n3 + " is not a leap year.");



				 yy = (((n3/10)%10)*10)+(n3%10);
				 System.out.println("Last two digit of the year  yy : "+yy);
					ce = (((n3/1000)%10)*10)+(((n3/100)%10));
				 	System.out.println("century ce : "+ce);
				 if(ce>17&&ce>20){
				 	ce = ce-4;
				 }
				 System.out.println("Century after condition check : "+ce);
				 if(ce==17){
				 	cc = 4;
				 }else{
				 	if(ce==18){
				 		cc = 2;
				 	}else{
				 		if(ce==19){
				 			cc = 0;
				 		}else{
				 			cc = 6;
				 		}
				 	}
				 }
			System.out.println("Century Code : "+cc);	 
			}catch(NumberFormatException nfe){
				System.out.println("Please enter the year in proper format");
			}
			System.out.println("yy/4 : "+yy/4);
			System.out.println("(yy/4)+n1 : "+((yy/4)+n1));
			System.out.println("(yy/4)+n1+mk : "+((yy/4)+n1+mk));
			System.out.println("(yy/4)+n1+mk+ce+yy : "+((yy/4)+n1+mk+cc+yy));
			System.out.println("((yy/4)+n1+mk+ce+yy)%7 : "+(((yy/4)+n1+mk+cc+yy))%7);
			if((n2==1||n2==2)&&(le==1))
			res = ((yy/4)+n1+mk-1+cc+yy)%7;
			else
			res = ((yy/4)+n1+mk+cc+yy)%7;





			System.out.println("Day code :"+res);
			switch(res){
				case 0 : jl4.setText(n1+"/"+n2+"/"+n3+" is Saturday");
						 break;
				case 1 : jl4.setText(n1+"/"+n2+"/"+n3+" is Sunday");
						 break;
				case 2 : jl4.setText(n1+"/"+n2+"/"+n3+" is Monday");
						 break;
				case 3 : jl4.setText(n1+"/"+n2+"/"+n3+" is Tuesday");
						 break;
				case 4 : jl4.setText(n1+"/"+n2+"/"+n3+" is Wednesday");
						 break;
				case 5 : jl4.setText(n1+"/"+n2+"/"+n3+" is Thursday");
						 break;
				case 6 : jl4.setText(n1+"/"+n2+"/"+n3+" is Friday");
						 break;
				default:
				
			}
			

			
		}
		}

	}


class CalendarAppDemo{
	public static void main(String[] args) {
		CalendarApp ca = new CalendarApp();
	}
}