import java.awt.*;
import javax.swing.*;
import java.awt.event.*; //S1 : Import Event Package

class AdditionApp extends JFrame implements ActionListener{ //S2 : Implement ActionListner Interface
	JFrame jf = null;
	JLabel jl1 = null;
	JLabel jl2 = null;
	JTextField jt1 = null;
	JTextField jt2 = null;
	JLabel jl3 = null;
	JButton jb1 = null;
	Container c = null;

	AdditionApp(){
		int x = 50, y = 50, w = 180, h = 33;

		jf = new JFrame("Addition App");
		c = jf.getContentPane();
		c.setLayout(null);

		jl1 = new JLabel("Enter Num 1 :");
		jl2 = new JLabel("Enter Num 2 :");
		jl3 = new JLabel(" ");
		jt1 = new JTextField();
		jt2 = new JTextField();
		jb1 = new JButton("Add");

		jl1.setBounds(x, y, w, h);
		jl2.setBounds(x, y+h+20, w, h);
		jt1.setBounds(x+w+20, y, w, h);
		jt2.setBounds(x+w+20, y+h+20, w, h);
		jl3.setBounds(x, y+(2*h)+30, w+w+20, h);
		jb1.setBounds(x, y+(3*h)+50, w+w+20, h);

		jb1.addActionListener(this);

		//Adding Components to the Container
		c.add(jl1); c.add(jt1);
		c.add(jl2); c.add(jt2);
		c.add(jl3); c.add(jb1);


		jf.setBounds(100,100, 490,350);
		jf.setVisible(true);
	}

	public void actionPerformed(ActionEvent ae){ //S3 : Implement the abstract method actionPerformed of the Interface
		//System.out.println("Some Action Performed....");
		//System.out.println(ae.getActionCommand());
		//System.out.println(ae.getSource());
		if(ae.getActionCommand().equals("Add")){
			//System.out.println("Add Button Clicked");
			String s1 = jt1.getText();
			String s2 = jt2.getText();
			String res = "";

			try{
				int n1 = Integer.parseInt(s1);
				int n2 = Integer.parseInt(s2);
				res = "Addition of "+n1+" & "+n2+" is  : "+(n1+n2);
			}catch(NumberFormatException nfe){
				System.out.println("Please Enter Number Only");
			}
			jl3.setText(res);
		}
	}
}

class AdditionAppDemo{
	public static void main(String[] args) {
		AdditionApp ap = new AdditionApp();
	}
}