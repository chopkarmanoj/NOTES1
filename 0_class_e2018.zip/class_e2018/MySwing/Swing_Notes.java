--> Create a new file
--> Keep main class ready
--> import swing, awt and awt.event package
--> Create a working class which extends JFrame class and implements ActionListener Interface
--> Initialize all the components that will be required on the application frame including container
--> Write the constructor of the working class with implementation of all components
	--> Intialize frame, add to container and setLayout(null)

