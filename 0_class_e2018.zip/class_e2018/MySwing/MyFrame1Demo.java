//Swing:
//	--> Desktop applictaion development framework
//	--> for events on the frame swing will 	use the AWT (abstract window toolkit)
//	--> UI components are of swing and event handling components are of AWT
// 	--> The name of swing components are same as those of AWT components with J attached to it.
//			Ex : Frame in AWT is JFrame in swing

import javax.swing.*;
import java.awt.*;

class MyFrame extends JFrame{ //JFrame is a class available in javax.swing package to get the frame i.e window
	void getUI(){
		JFrame jf1 = new JFrame("Welcome to Swing Frame !!!"); //Create Frame with caption
		Container c = jf1.getContentPane(); //gives the container of the component
		c.setLayout(null); //allows to add components in free form. No compulsion of layout.
		
		int x = 20, y = 20, w =180, h = 33;

		// Step 1 : Create Component
		JButton jb1 = new JButton("OK");
		JLabel jl1 = new JLabel("Enter Full Name : ");
		JLabel jl2 = new JLabel("Enter Mobile No : ");
		JTextField jt1 = new JTextField(); //SLE : Single Line Edit
		JTextField jt2 = new JTextField();
		JLabel jl3 = new JLabel("Enter Address");
		JTextArea ja1 = new JTextArea(); //MLE : Multi Line Edit
		JLabel jl4 = new JLabel("Gender");
		JRadioButton jr1 = new JRadioButton();
		JRadioButton jr2 = new JRadioButton();


		// Step 2 : Setting Bounds
		jb1.setBounds(50,350,90,33);
		jl1.setBounds(x,y,w,h);
		jl2.setBounds(x,y+h+10,w,h);
		jt1.setBounds(x+w+20,y,w,h);
		jt2.setBounds(x+w+20,y+h+10,w,h);
		jl3.setBounds(x,y+h+h+20,w,h);
		ja1.setBounds(x+w+20,y+h+h+20,w,h+90);
		jl4.setBounds(x,y+(3*h)+120,w,h);
		jr1.setBounds(x+w+20,y+(3*h),30,30);
		jr2.setBounds(x+w+20+50,y+(3*h)+120,30,30);

		ButtonGroup bg = new ButtonGroup();
		bg.add(jr1);
		bg.add(jr2);
		//ja1.setBounds(20,)
		

		//Step 3 : adding Component to the container
		c.add(jb1);
		c.add(jl1); c.add(jt1);
		c.add(jl2); c.add(jt2);
		c.add(jl3); c.add(ja1);
		c.add(jl4);
		c.add(jr1);
		c.add(jr2);


		jf1.setBounds(100,100,550,500); //parameters are x,y,w: width, h :height
		jf1.setVisible(true);
	}

}

class MyFrame1Demo{
	public static void main(String[] args) {
		MyFrame mf = new MyFrame();
		mf.getUI();
	}
}

//1. Create Component: Get Frame
//2. set Bounds x,y,w,h
//3. Mount component on Container
//4. set setVisible(true) 
//