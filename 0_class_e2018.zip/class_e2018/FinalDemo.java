class FinalDemo{
	public static void main(String[] args) {
		final int a;
		a = 20;
		System.out.println(a+2);
	}
}																																																																																																																																																																																																																																