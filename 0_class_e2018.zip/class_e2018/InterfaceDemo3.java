interface I1{
	void m1();
	void m2();
}

abstract class MyInter implements I1{
	public void m1(){
		System.out.println("Reply from m1");

	}
}

class MyInter2 extends MyInter{
	public void m2(){
		System.out.println("Reply from m2");
	}
}

class InterfaceDemo3{
	public static void main(String[] args) {
		
	}
}