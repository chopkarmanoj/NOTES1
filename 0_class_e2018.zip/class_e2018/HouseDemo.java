class Table{
	int legs;
	String shape;
	String size;

	void setLegs(int val){
		if(val < 1){
			legs = 4;
		}else{
			legs = val;
		}
	}

	int getLegs(){
		return legs;
		}

	void setShape(String val){
		if( val == "R"){
			shape = "Round";
			}else{
			shape = "Rectangle";
			}
	}
	 
	String getShape(){
	 	return shape;
	 }

	 void setSize(String val){
	 	if(val == "S"){
	 		size = "Small";
	 	}else{
	 		if(val == "M"){
	 			size = "Medium";
	 			}else{
	 				size = "Large";
	 			}
	 	}
	 }

	 String getSize(){
	 	return size;
	 }

}

class Kitchen{
	int windows;
	String Chimney;
	Table t;

	void setWindows(int val){
		if (val < 0){
			windows = 1;
		}else{
			windows = val;
		}
	}
	 int getWindows(){
	 	return windows;
	 }

	 void setChimney(String val){
	 	if(val == "Y"){
	 		Chimney = "YES";
		 }else{
		 	Chimney = "NO";
		 }
	 }

	 String getChimney(){
	 	return Chimney;
	 }

	 void setTable(Table val){
	 	t = val;
	 }

	 Table getTable(){
	 	return t;
	 }
}
class House{
	int rooms;
	String name;
	int cost;
	Kitchen k; // House has-a kitchen

	void setKitchen(Kitchen val){
		k = val;
	}

	Kitchen getKitchen(){
		return k;
	}

	void setRooms(int val){ // Set methods set the values.
		if(val < 1 || val > 8){
			rooms = 2;
		}else{
			rooms = val;
		}

	}

	void setName(String val){
		name = val;
	}

	void setCost(int val){
		if(val < 100){
			cost =100;
			}
		else{
			cost = val;
		}
	}

	int getRooms(){ // Get method is used to return values.
		return rooms;
	}

	String getName(){
		return name;
	}

	int getCost(){
		return cost;
	}
void displayHouse(){
	System.out.println("");
	System.out.println("");
	System.out.println("------------------------------");
	System.out.println("House name is : "+name);
	System.out.println("Rooms are : "+getRooms());
	System.out.println("Cost is " +getCost());
	System.out.println("Windows in the Kitchen are :"+k.getWindows());
	System.out.println("Chimney Availability: "+getKitchen().getChimney());
	System.out.println("");
	System.out.println("-------Table Details------------");
	System.out.println("Table has "+k.t.getLegs()+" legs");
	//System.out.println("Table has "+getKitchen().getTable().getLegs()+" legs");
	System.out.println("Table Shape is : "+k.t.getShape());
	System.out.println("Table Size is : "+getKitchen().getTable().getSize());
	System.out.println("------------------------------");

}
}

class HouseDemo{
	public static void main(String[] args){
		House h1 = new House();
		h1.setName("MyPalace");
		h1.setRooms(5);
		h1.setCost(5000);
		
		Table t1 = new Table();
		t1.legs = 6;
		t1.shape = "R";
		t1.size = "L";

	//	t1.setLegs(6);
	//	t1.setShape("R");
	//	t1.setSize("L");

		Kitchen k1 = new Kitchen();
		k1.setWindows(1);
		k1.setChimney("Y");
		k1.setTable(t1);
		
		h1.setKitchen(k1);

		h1.displayHouse();

		House h2 = new House();
		h2.setRooms(2);
		h2.setName("MyWorld"); // As Cost is not intialized so it gives default integer value 0
		
		Table t2 =new Table();
		t2.setLegs(4);
		t2.setShape("S");
		t2.setSize("S");

		Kitchen k2 = new Kitchen();
		k2.setWindows(2);
		k2.setChimney("N");
		k2.setTable(t2);

		h2.setKitchen(k2);

		h2.displayHouse();
		
		
	}
}

// Create a Class College which has following attributes :
// 	--> int admissionFees
// 	--> int totalStaff
// 	--> PlayGround p
// 	--> Department d

// 	.. --> Department attributes :
// 		..> String name
// 		..> int noOfStudents

// 	..--> PlayGround attributes:
// 		..> double area
// 		..> int noOfBalls
// 		..> String nameOfGame