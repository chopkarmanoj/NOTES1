class StaticTest{
	int x = 40 ;
	static void test1(){
		//System.out.println(x);  -- direct access of non-static is not allowed in static
		StaticTest t = new StaticTest(); // non-static variable can be accessed through an instance
		t.x = 40;
		System.out.println("Inside test of StaticTest");
	}

	void test2(){
		System.out.println("Inside test2 of StaticTest");
	}

	public static void main(String[] args) {
		test1();
		test2();
	}
}

class StaticDemo1{
	public static void main(String[] args) {
		// StaticTest st = new StaticTest();
		StaticTest.test1();
	}
}