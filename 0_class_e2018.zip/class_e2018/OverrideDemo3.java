class Father{
	public void play(){
		System.out.println("Father is Playing Football");
	}
}
class Child extends Father{
	public void play(){
		System.out.println("Child is Playing Football");
	}
}

class OverrideDemo3{
	public static void main(String[] args){
		Child c1 = new Child();
		c1.play();
	}
}     