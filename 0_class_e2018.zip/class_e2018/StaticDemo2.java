class StaticTest{
	static{
		System.out.println("Reply from static block 1");
	}

	void test1(){
		System.out.println("Inside test1 of StaticTest");
	}
	static{
		System.out.println("Reply from static block 2");
	}

	void test2(){
		System.out.println("Inside test2 of StaticTest");
	}
}

class StaticDemo2{
	public static void main(String[] args) {
		StaticTest st = new StaticTest();
		st.test1();
		st.test2();
}