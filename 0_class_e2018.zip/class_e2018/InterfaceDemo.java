interface House{
	void hall();
	void kitchen();
}
class MyHouse implements House{
	public void hall(){
		System.out.println("Inside hall of MyHouse");
	}

	public void kitchen(){
		System.out.println("Inside kitchen of MyHouse");
	}
}
class InterfaceDemo{
	public static void main(String[] args) {
		MyHouse h = new MyHouse();
		h.hall();
		h.kitchen();
	}
}