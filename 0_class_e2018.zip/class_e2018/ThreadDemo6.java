class TableTennis{
	synchronized void hit(){
	System.out.println("Hit By : "+Thread.currentThread().getName());
	try{
		Thread.sleep(1000);
		notify();
		wait(); // Since wait() is a method of 'Object' class whic is by default a superclass for all the userdefined classes, hence the wait() method can be directly called within this class without instance
	}catch(Exception e){ e.printStackTrace();}


	}
}

class Player implements Runnable{ // This will behave as the Thread Manager class
	TableTennis tt;  
	
	Player(TableTennis val){
		tt = val;
	}

	public void run(){
		while(true) tt.hit();
	}

}
class ThreadDemo6{
	public static void main(String[] args) {
		TableTennis tt = new TableTennis();
		Player p = new Player(tt);

		Thread t1 = new Thread(p,"Rajkumar");
		Thread t2 = new Thread(p,"Shamu");

		t1.start();
		t2.start();
		
	}
}