final class Animal{
	int ht;
	void eat(){
		System.out.println(" Animal is eating");
	}
}

// class Dog extends Animal{ // Since class 'Animal' is marked as final hence it cannot be extended
// 	void eat(){
// 		System.out.println("Dog is eatingb");
// 	}
// }
class FinalClassDemo{
	public static void main(String[] args) {
		
	}
}