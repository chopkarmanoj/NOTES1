class StringBufferDemo{
	public static void main(String[] args) {
		StringBuffer sb1 = new StringBuffer("Rajkumar Hirani");
		System.out.println(sb1);
		Object ob = new StringBuffer(" Object Based String");
		sb1.append(ob);			//1

		System.out.println(sb1);
		sb1.append(" From Nagpur");
		System.out.println(sb1);

		sb1.append( 12);
		System.out.println(sb1);
		sb1.append(12.12);
		System.out.println(sb1);


		System.out.println("Char At : "+sb1.charAt(3));		//2

		sb1.deleteCharAt(9);								//3
		System.out.println(sb1);

		sb1.deleteCharAt(9);
		System.out.println(sb1);

		sb1.delete(9,13);	//(requires start and end index)   //4
		System.out.println(sb1);

		sb1.insert(9, "Hirani");     //(requires offet, char/int/long/string..etc) //5			
		System.out.println(sb1);

		System.out.println("Length of sb1 is : "+sb1.length());

		char ary[] = {'a','b','c','d','e','f'};
		sb1.insert(0,ary,0,3); //insert(offeset,string,offset,length)
		System.out.println(sb1);

		sb1.replace(0, 3, "Shamkumar ");  //7 (start, end, String)
		System.out.println(sb1);

		sb1.reverse();  //8
		System.out.println("Reversed String : "+sb1);

		sb1.reverse();
		System.out.println("Again reversed to original : "+sb1);

		System.out.println("First index of : "+sb1.indexOf("R"));	//9

		System.out.println("Last index of : "+sb1.lastIndexOf("a"));	//10

		String s1 = sb1.substring(0, 10); // index, pos  --- 11
		System.out.println("Substring : "+s1);


		String s2 = sb1.toString();  // StringBuffer to String
		System.out.println("String Ob : "+s2);

		StringBuffer sb2 = new StringBuffer(s2);
		System.out.println("String : "+sb2);
	}	

}