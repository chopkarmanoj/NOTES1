abstract class House{
	abstract void hall();
	void kitchen(){
		System.out.println("Inside Kitchen");
	}
}

class MyHouse extends House{
	void hall(){
		System.out.println("Inside Hall");
	}
}

class AbstractDemo{
	public static void main(String[] args) {
		MyHouse h1 = new MyHouse();
		h1.hall();
		h1.kitchen();
	}
}