import java.io.*;
class LineNumberDemo{
	public static void main(String[] args) {
		try{
			FileReader fr = new FileReader("FileDemo.java");
			LineNumberReader lnr = new LineNumberReader(fr);
			 String tmp;
			 while((tmp =lnr.readLine()) != null){
			 	System.out.println(lnr.getLineNumber()+"."+tmp);
			 }
		}catch( Exception e){ e.printStackTrace();}
	}
}