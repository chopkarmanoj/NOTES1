class ExceptionDemo2{
	public static void main(String[] args) {
		try{
			int[] ary = {10,20,30};
			System.out.println("ary 3 : "+ary[3]);	

			int a = 10/0;

			String s = null;
			int l = s.length(); //Exception--- trying to get the length of null

		}catch(ArithmeticException a){// Specific exception should be written before Broader Exception
			System.out.println("There is an ArithmecticException");
		}catch(ArrayIndexOutOfBoundsException e){
			System.out.println("Out of Bound");
		}
		catch(NullPointerException e){
			System.out.println("NUll ");
		}
		catch(Exception e){ //Broader exception catch must be the last catch in heirarchy
			System.out.println("There is an Exception ");

		}
	}
}