class Identifier_Literal_Demo{
	public static void main(String[] args) {
		int a = 10; //decimal
		System.out.println(a);
		int $a = 20;
		System.out.println($a);
		int __a_ = 30;
		System.out.println(__a_);

		int h = 0x34b;//Hexadecimal
		System.out.println(h);

		int h1 = 0x1d;
		System.out.println(h1);

		int o=010;
		System.out.println(o);

		int o1=0110;
		System.out.println(o1);

		int b=0b01001;// Java 1.7+
		System.out.println(b);

		int b1=0B01001;
		System.out.println(b1);

		float f = 12.3f;
		System.out.println(f);

		float f1 = 15.55F;
		System.out.println(f1);

		double d = 12.45;
		double d1 = 12.45d;
		double d2 = 12.45D;

		System.out.println(d);
		System.out.println(d1);
		System.out.println(d2);

		
	}
}