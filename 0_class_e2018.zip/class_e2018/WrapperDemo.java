//String to primitive/non-primitive datatypes
//----------------------------------------------
//parseInt ---> converts string to primitive datatypes
//valueOf ----> converts string to non-primitive i.e object datatype
//--------------------------------------------------

class WrapperDemo{
	public static void main(String[] args) {
		Integer i1 = new Integer(10);
		Integer i2 = new Integer("12");
		System.out.println(i1);
		System.out.println(i2);

		//int to String Conversion Methods
		String s = Integer.toBinaryString(1212);
		System.out.println(s);

		System.out.println(Integer.toHexString(242424));
		System.out.println(Integer.toOctalString(1231434));



		//String to primitive conversion methods
		s ="123";
		int i = Integer.parseInt(s);
		System.out.println(i);

		s = "11001110";
		System.out.println(Integer.parseInt(s,2));

		s = "abc12";
		System.out.println(Integer.parseInt(s,16));

		s = "010";
		System.out.println(Integer.parseInt(s,8));


		// String to Non-primitive Conversion Methods
		s = "123";
		Integer i3 = Integer.valueOf(s);
		System.out.println(i3);

		s = "11011";
		System.out.println(Integer.valueOf(s,2));

		Integer i4 = new Integer(123); //Integer Object (Wrapping)
		int j = i4.intValue(); // int primitive(un-wrapping)
		System.out.println(j);


		Integer i5 = 10; // autobox
		Integer i6 = 12;

		Integer z1 = i5 + i6;  // adding the objects and storing result into a object
		int z2 = i5 + i6;  // adding the objects and storing result into a primitive


		System.out.println(z1);
		System.out.println(z2);
	}
}

//Autobox --- when the value is infront of a non-primitive (i.e object) reference variable or if it is assingment statement then it gets autoboxed which means the primitive is converted to object
//Unbox --- when the value is infront of primitive reference variable or its in operation then its unboxed which means it is converted to primitive datatype