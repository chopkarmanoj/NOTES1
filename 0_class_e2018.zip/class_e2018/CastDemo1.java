class CastDemo1{
	public static void main(String[] args) {
		byte b = (byte)131;
		System.out.println(b);
	}
}
// byte b = 131 : 1000 0011
// 131 --> int --> (MSB) (0000 0000 0000 0000 0000 0000) 1000 0011(LSB)
// byte : 1000 0011 --> (1)<-- sign bit : 000 0011(2s)
// 									== 111 1101 ==> -125
