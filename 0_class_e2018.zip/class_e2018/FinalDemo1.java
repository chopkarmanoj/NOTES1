abstract class A{
	void sample1(){
		System.out.println("Inside sample 1");
	}

	abstract void sample2();
	
	final void sample3(){
		System.out.println("Inside Sample 3");
	}
}