class MyOperations{
	int add(int x, int y){
		System.out.println("Inside first add");
		return(x+y);
	}
	// double add(int x, int y){ //if only return type is different but parametera are same then it is not Overloading
	// 	return(x+y);
	// }
	
	double add(int x, double y){
		System.out.println("Inside second add");
		return(x+y);
	}
}

class OverloadExample{
	public static void main(String[] args) {
		MyOperations mo = new MyOperations();
		System.out.println("Addition of integers"+mo.add(10,20));
		System.out.println("Addition of double"+mo.add(10,10.25));
	}
}