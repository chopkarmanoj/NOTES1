class Student{
	String name;
	String rollno;
	String dept;
	int age;

	Student(String n, String r){
		name = n;
		rollno = r;
	}
	Student(String n, String r, String d, int a){
		this(n,r); //this constructor is used to call the constructor of self class
		dept = d;
		age = a;
	}

	void displayStudent(){
		System.out.println("Name : "+name);
		System.out.println("Roll No :"+rollno);
	}
}

class ConstructorDemo5{
	public static void main(String[] args) {
		Student s1 = new Student("Shyamkumar","CS18001");
		s1.displayStudent();

		Student s2 = new Student("Ramkumar","CS18002","CSE",21);
	}
}