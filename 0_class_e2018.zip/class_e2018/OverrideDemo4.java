class Animal{
	void eat(){
		System.out.println("Animal is eating");
	}
}
class Tiger extends Animal{
	void eat(){
		System.out.println("Tiger is eating");
	}
}
class OverrideDemo4{
	public static void main(String[] args) {
		Tiger t1 = new Tiger();
		t1.eat();
		
	}
}