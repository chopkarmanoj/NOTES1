class Chair{ // This is the operational class
	int cost;
	int legs;

	void displayChair(){//this is a method. it is  also known as functionality of the class
		System.out.println("cost is : "+cost);
		System.out.println("legs are : "+legs);
	}
}
class ChairDemo{ //This is utility class and should have name same as filename. This will be called by the JVM while execution as it contains the main. In C languange the OS calls the main function.
	public static void main(String[] args){
		Chair c = new Chair(); //c is the reference variable which refers to instance of class Chair, by its address. New keyword is similar to Malloc in C, it allocates memory in runtime. C is on stack and object in heap memory.
		c.legs = 4;
		c.cost = 500;

		//System.out.println(c.legs);
		//System.out.println(c.cost);
		c.displayChair();

		Chair c1 =new Chair();
		c1.displayChair();
			}
	
}