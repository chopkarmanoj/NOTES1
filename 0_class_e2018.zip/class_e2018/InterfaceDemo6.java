interface I{
	void t1();
	void t2();
}

class A{
	public void t2(){
		System.out.println("Reply from t2");
	}
}

class B extends A implements I{
	public void t1(){
		System.out.println("Reply from t1 of B");
	}
}

class InterfaceDemo6{
	public static void main(String[] args) {
		B b1 = new B();
		b1.t1();
		b1.t2();
	}
}