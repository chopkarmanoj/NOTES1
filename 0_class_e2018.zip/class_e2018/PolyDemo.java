class Clothes{
	void jeans(){
		System.out.println("Levis Jeans");
	}
}

class MyClothes extends Clothes{
	// void jeans(){
	// 	System.out.println("local jeans");
	// }
}

class PolyDemo{
	public static void main(String[] args) {
		Clothes c = new MyClothes(); // Clothes c <-- is known as the reference of Superclass 'Clothes' which is having the instance of subclass 'MyClothes'																																																																																																																																								
		c.jeans();
	}
}