interface I1{
	public abstract void test1();
}

interface I2 extends I1{
	public void test2();
}

class A implements I2{
	public void test1(){
		System.out.println("Reply from test1");
	}
	public void test2(){
		System.out.println("Reply from test2");
	}
}
class InterfaceDemo5{
	public static void main(String[] args) {
		A a1 = new A();
		a1.test1();
		a1.test2();
	}
}