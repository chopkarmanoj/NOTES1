class StringDemo1{
	public static void main(String[] args) {
		String s1 = new String("Ramkumar Shastri");

		System.out.println("s1 len is :"+s1.length()); //1
		System.out.println("first occurence of a is : "+s1.indexOf('a')); //2
		System.out.println("last occurence of a is :"+s1.lastIndexOf('a'));//3
	
		String s2 = s1.substring(2,5); // index,pos  //4
		System.out.println("sub string : "+s2);

		s1 = s1.replace('a','X');
		System.out.println("Replaced String : "+s1); //5

		System.out.println("Char at Index 5 is :"+s1.charAt(5)); //6

		System.out.println("Is s1 starting with Ram ? :"+s1.startsWith("RXm")); // 7

		System.out.println("Is s1 ending with tri ? : "+s1.endsWith("tri")); //8

		String s3 = "       gfg gdgdg gdgsfg gdsgfsg";
		System.out.println("s3 is :"+s3);
		s3 = s3.trim();                             //9 
		System.out.println("s3 is :" +s3);

		String s4 = new String("Rajkumar");
		String s5 = new String("RaJKUmAr");
	
		if(s4.equals(s5)){
			System.out.println("s4 == s5");
		}else{
			System.out.println("s4 != s5");
		}

		if(s4.equalsIgnoreCase(s5)){                     //10
			System.out.println("s4 == s5");
		}else{
			System.out.println("s4 != s5");
		}

		s1 = s1.toLowerCase();							//11
		System.out.println(" s1 in lower case : " +s1);

		s1 = s1.toUpperCase();							//12
		System.out.println("s2 in upper case : "+s1);

		char ary[] = s1.toCharArray();					//13
		for(char x : ary) System.out.println(x);
		}
}