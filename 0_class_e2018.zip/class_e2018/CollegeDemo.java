// Create a Class College which has following attributes :
// 	--> int admissionFees
// 	--> int totalStaff
// 	--> PlayGround p
// 	--> Department d

// 	.. --> Department attributes :
// 		..> String name
// 		..> int noOfStudents

// 	..--> PlayGround attributes:
// 		..> double area
// 		..> int noOfBalls
// 		..> String nameOfGame

class PlayGround{
	double area;
	int noOfBalls;
	String nameOfGame;


	void setArea(double val){
		area = val;
	}

	double getArea(){
		return area;
	}

	void setNoOfBalls(int val){
		noOfBalls = val;
	}

	int getNoOfBalls(){
		return noOfBalls;
	}

	void setnameOfGame(String val){
		nameOfGame = val;
	}

	String getNameOfGame(){
		return nameOfGame;
	}
}

class Department{
	String name;
	int noOfStudents;

	void setName(String val){
		name = val;
	}

	String getName(){
		return name;
	}

	void setNoOfStudents(int val){
		noOfStudents = val;
	}

	int getNoOfStudents(){
		return noOfStudents;
	}
}

class College{
	int admissionFees;
	int totalStaff;
	PlayGround p;
	Department d;

	void setAdmissionFees(int val){
		admissionFees = val;
	}

	int getAdmissionFees(){
		return admissionFees;
	}

	void setTotalStaff(int val){
		totalStaff = val;
	}

	int getTotalStaff(){
		return totalStaff;
	}

	void setPlayGround(PlayGround val){
		p = val;
	}

	PlayGround getPlayGround(){
		return p;
	}
	
	void setDepartment(Department val){
		d = val;
	}

	Department getDepartment(){
		return d;
	}
void displayCollege(){
	System.out.println("---------------------------------");
	System.out.println("The College Details are as follows:");
	System.out.println("College Admission Fees is : "+getAdmissionFees()+"k");
	System.out.println("Total Staff in College : "+getTotalStaff());
	System.out.println(" ");
	System.out.println("College Department Details : ");
	System.out.println("Department Name :"+d.getName());
	System.out.println("Number of Students in the department :"+getDepartment().getNoOfStudents());
	System.out.println(" ");
	System.out.println("Colllege Playground Details");
	System.out.println("Playground area is :"+p.getArea()+" sq.ft");
	System.out.println("No. of Balls are : "+getPlayGround().getNoOfBalls());
	System.out.println("Name of the Game: "+p.getNameOfGame());
}
}
 class CollegeDemo{
 	public static void main(String[] args) {
 		PlayGround pg = new PlayGround();
 		pg.setnameOfGame("Football");
 		pg.setArea(500);
 		pg.noOfBalls = 5;

 		Department dept =new Department();
 		dept.setName("Information_Technology");
 		System.out.println("Dept. name 1="+dept.name);
 		dept.noOfStudents = 240;

 		College c = new College();
 		//System.out.println("Dept. name ="+c.d.name);
 		c.d = dept;
 		//System.out.println("Dept. name 2="+c.d.name);
 		c.d.name = "Computer_Science";
 		//System.out.println("Dept. name 3="+c.d.getName());
 		c.setDepartment(dept);
 		System.out.println("Dept. name 4="+dept.name);
 		c.setPlayGround(pg);
 		c.setAdmissionFees(2);
 		c.totalStaff = 650;		

 		c.displayCollege();
 	}
 }