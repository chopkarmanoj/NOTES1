
* Identifier and Literals :
	--> Identifier : who identify themselves through out the program.	
		Ex : int a; // a is an identifier.

		-- Only $ and _ is allowed in the identifier.

	--> Literals :

		1. Integer Literal :
			--> Decimals (10,203,40) -- the numbers with base 10
			--> Hexadeicmals (0x458A, 0XAbc) -- the numbers with base 16 --  0x or 0X is the prefix
			--> Octals (012, 001, 010) -- the numbers with base 8 -- 0 is the prefix
			--> Binary (0b1100110, 0B110101) -- the numbers with base 2 -- 0b or 0B is the prefix

		2. Float
			--> any floating point number in java is by default double.
			--> for a floating point number ex : 3.14, the user should add 'f' or 'F' at the end.


* Control Structures :
	--> loops 
		--. for loop
		--. while loop

	--> non-loops
		--. if / if-else
		--. switch


	int a = 5;

	if(a == 5){
		// -------------- 1

		if(a > 3){
			// -----------2
		}else{
			// ----------3
		}

		if(a < 6){
			// ----------4
		}
	}

	if(a > 3){
		// ----------- 1
	}else if(a < 6){
		// -----------2
	}else if(a == 5){
		// -----------3
	}

* Class and Object.
	class : collection of Objects
	Object : template of the class.
	
	class Vehicle :
		--> has-a
			-- Vehicle has-a wheels.
			-- Vehicle has-a company
			-- Vehicle has-a cont 

* Casting :
	
	--> byte  (8 bit)
	--> short (16)
	--> int (32)
	--> char (32)
	--> long (64)
	--> float (32)
	--> double (64)

	Casting types :
		1. Down Cast (loss-less cast / Implicit Cast)
		2. Up Cast (lossy cast / Explicit Cast)


									byte 					^
									  |						|
									  |						|
									short 					| (Up cast)
									  |						|
									  |
							char---->int---->float
									  |			|
									  |			|
									  long--->double



			down cast : long ---> float , int ---> double, float --> double
		boolean : boolean can not be casted to anything.

* Arrays : 
		-- Arrays are Objects in Java.
		-- Arrays are being constructed rather than created.
		-- length is the attr of the array, which can be used to get the length of the array.
			Ex ; 
				int ary[] = new int[3];
				System.out.println(ary.length); // op : 3
		-- Multidimensional Arrays :
			-- java supports jagged array.
				int[][] ary7 = new int[3][3];
				int[] ary8[] = new int[4][3]; // legal

* Method Overload : 
	-- method with same signature but diff. param list is method Overload.
	-- java will find the exact match first, if the exact match is not applied then java will find 
		the suitable method by applying casting on the given types.
	-- you may get an error that the call to the method is ambiguous, means more then 1 method is 
		matching with the given types.

* Inheritance :	
	-- it follows is-a realtionship.
	-- it is the realtionship between super class and sub class.
		Ex :
		  Animal (<-- super class)
			^ 
			|
			|
		   Dog (<-- Sub class)
		(Dog is-a Aniaml)
	-- java supports only single level Inheritance.
		(a class can inherit from only 1 super class.)

			A 	C
			|	|
			|	|
			B 	B ( Not allowed in java)

			A 	A 
			|	|
			|	|
			B 	C (allowed)

			X
			|
			|
			Y
			|
			| 
			Z (allowed)
	-- Inheritance is every where in Java, you can not create a single class without Inheritance.
	-- Every class created by the programmer has the absolute super class and i.e. Object

* Create a class MyStack with void push(int), int pop() and displayStack() methods.
	-- create another class with main method and use MyStack.

* Method Override : 
	-- Method with the same signature, param and return type (except covarient return) is present in the sub class then, the 
		method is said to be Overridden.
	-- overridden method should have atlist equal access than the super class method.
	-- we can not override static method.


* Abstract : 
	-- abstract calss cannot be instantiated. so, it must be subclassed.
	-- abstract class tells the programmer that, what to do, but not how to do.
	-- if a method marked as abstract then, the class should also marked as abstract.
	-- the first concrete subclass in hirerchy of abstract classes should Override all the 
		abstract methods from its super class.

* Final :
	-- Final Variable :
		--. if a Variable marked final then, programmer can not change its value. 
		(its value will be fixed (final))
		(value of the final Variable can not be changed once init.)

	-- Final method :
		--. final method can not be overridden.

	-- Final class :
		--. final class can not be inherited.


* can we mark method as abstract and final both at the same time ? NO
* can we mark class as abstract and final both ? NO

* Polymorphism :
	-- it is the ref of super class, holding the instance of subclass
	-- in java Object is actually showing multiple behaviour. (Polymorphic behaviour)
	-- Polymorphism melts down at runtime.

* Encapsulation :
	-- attr must be marked as private and methods must be marked as public.

* Static :
	-- static are class specific, not instance specific.
	-- statics can be accessed with class name.
		Ex :
		class Chair{
			static int cost;
		}

		==> Chair.cost = 400; --> accessing cost (static) with class name.
	-- statics get loaded when the class get loaded.
	-- you can not access non-static in the static context.

	-- static Variable : 
		-- if we marked the Variable as static then, the Variable will class specific rather than,
			Object.
		-- it will share its value will all instances of the class.

	-- static method : 
		-- it shares the common functionality with class instances.

	-- static block : 
		-- static blocks act as initilizers.

* Constructor : 
	-- Constructors are used to construct the objects in java.
	-- There is a default Constructor present in the class if the programmer didnt define 
		any Constructor. (javas provided Constructor)
	-- The default Constructor is also known as non-param Constructor.
	-- The Constructor can be defined with the following syntax : 
		class_name(pram1, ....){
			------ // body of the constructor.
		}
	-- Note : there is no return type for the Constructor.
	-- If by mistake a programmer gave the return type to the Constructor then, it will
		be treated as method of the class.
	-- You can also write, the param Constructor.
	-- Constructor can also be overloaded.

	-- there is call to super() in every Constructor of java. It can be either programmer defined call	
		or will be inserted by java.

	-- super() <-- call to super class Constructor.
	-- this <-- ref to current class instance. 
	-- super <-- instance of super class.
	-- this() <-- call to current class Constructor.

* Interface : 
	-- Interface is 100% abstract super class.
	-- Interface must be implemented.
	-- all the methods in interface are public and abstract.
	-- all the variables in the interface are final,static and public. 
	-- interface names are generally ends with 'able' according to java convenion.
	-- a class can implement multiple interfaces at a time>
		Ex :
			class A implements I1,I2,I3{

			}

			or

			class A extends B implements I1, I2, I3{

			}

	-- an interface can extend another interface, hence the abstract methods present
		in the super interface will get inherited into the sub interface.

	-- if an interface contains no members in it, then the interface is said to be a 
		marker interface.
			Ex :
				Serilizable
				Remote

* Access Modifiers : 
	--> private : can be access within class only.
	--> public :  
		-- can be accessed within and outside the package as well.
		-- there can be only 1 public class per source file.
		-- if the class is public then its source file name should equal to the class name.
	--> protected : 
		-- members which are marked protected can be accessed within the package (as of default) and 
			outside of the package with inheritance only.
	--> default : can be accessed within package only.

		Class(private)
		<-------->
		Package (default)
		<---------------------->
		Out side of Package (public)
		<-------------------------------------------------------->---------
		Protected(within package as default) (Protected) but through Inheritance ONLY
		<----------------------><......................................>

* Package :
	--> you should create a folder and store the source files within the folder.
	--> in the source file you should keep package statement on the first line.
	--> to run the code always use full qualified name of the class file.
	--> full qualified name will be : package name (.) class name
	--> (.) dot is the separator for package and class.

	--> Ex :
		a
		|
		|
	InsideADemo.java

	--> Compile the file as : javac a\InsideADemo.java
	--> Run the code as : java a.InsideADemo

	--> Nested package : 
			a 
			|
			|
			b 
			|
			|
		InsideBDemo.java
	--> Compile the file as : javac a\b\InsideBDemo.java
	--> Run the code as : java a.b.InsideBDemo (<-- full qualified name of the class)

	--> consider the following ex to implement:

			e 								m
			|								|
			|								|
			f 								n
			|								|
			|								|
		InsideEF.java                   InsideMNDemo.java
		[void test(), int x]     [p s v main() --> create inst. of InsideEF and access test() , x]

	--> generally, the package name used within the projects are reverse domain names
		Ex : www.google.co.in
		Package that can be used :
			package in.co.google

	--> consider the following ex to implement.

					j                            k
					|							 |
					|                            |
					l                            l
					|                            |
					|                            |
				InsideJL.java                InsideKL.java
				[void go();]                  [void doSomething();]

			--> Note : there is no main method defined in both the package source files.
			--> create AccessKLJLDemo.java to define the main() method, create 
				instance of InsideKL, InsideJL  and get access to go() as well as doSomething()
				method.

	--> a package named java.lang will be auto imported in every source file as follows:
		import java.lang.*;

--> can we mark the class as protected ?  NO
--> can we mark the Constructor as protected ? NO
--> How to access the member of the class, if the class Constructor is marked as private ? 

* Var-Arg (Variable Argument list)
	--> var-arg accepts any no of arguments of the given type.
	--> you can define the var-arg using following syntax :
		ex : void test(int... x){}
	--> x is var-arg in above method, which will accept any no of args.
	--> x is also treated as an array inside the test method.
	--> var-arg must be the last arg of the method.
	--> you can define only 1 var-arg per method.
	--> you can use the var-arg even as the param to main method.
		ex; public static void main(String... args){}
	--> var-arg also receives array of the same type in which var-arg is defined.


* Strings :
	--> String is a class in java.
	--> Strings are immutable objects in java.
	--> API methods of string : 
		--
	--. StringBuffer & StringBuilder
		-- these objects are mutable objects
		-- the API of StringBuffer and StringBuilder is same
		-- the diff betn these 2 is : All the methods in the StringBuffer class are 
			thread safe. (that means all methods are marked as synchronized )
		-- StringBuilder methods are not thread safe.

* Exception :

	-- exception is the situation / condition which will alters the normal flow of the program.
		which may also stop the program from execution, leads to crash.
	
	-- use try block to keep the dangerous or exceptional code.
	-- if their is an exception in the code within try block, then java will search for	the
		appropriate catch block.

	-- use Exception in the catch block, so that all exceptions from code get catched in the 
		single catch :
			try{
				//------ E 1
				//------ E 2
			}catch(Exception e){ // broader exception catch.
				//---------
			}
		in the above code Exception 1 and 2 will be catched in the same catch block.

	-- the broader exception catch block should be the last catch in the hirerchy.

	-- Exception propagates  through the call stack.

	-- there are 2 types of exception :
		--> Checked Exception
			-- Checked exception are those which are subclass of Exception class, excluding 
				Runtime Exception and Error.
		--> Unchecked Exception
			-- for Unchecked exception, java will not take care about the exception is declared 
				or not.

	--. throw : 
		--> throw can be used to throw the exception manually depending on situation.
		--> progammer can throw existing exception or create new to throw.
		
	--. throws :
		--> throws in front of the method suggest that the method may contain the exceptional code.

			Ex : 
				void test() throws NullPointerException, ArrayIndexOutOfBoundsException{

				}
				--> the above test method may throw NullPointerException or ArrayIndexOutOfBoundsException
				void test() throws Exception{

				}
				-- the above test method may throw any type of Exception.
	-- finally :
		--. finally block will get exceuted in any case regardless of the exception in the try block.

	-- from 1.7+ java added multiple catch block.



* Wrapper Class :
	--> for every primitive datatype, the wrapper class is available.
	--> for ex : int --> Integer
				float --> Float
				double --> Double
				char --> Character
				boolean --> Boolean
				byte --> Byte
				short --> Short


* Command Line Argument : 
	--> the arguments that can be passed while running the program.
	--> these arguments are generally, accepted in the main method.
	--> the arguments which are accepted, are always in the form of Strings.

* Thread :
	-- Java supports multithreading.
	-- There are two ways to create a thread in java.
		1. extending a thread class.
		2. implementing Runnable interface.
	-- Constructors :
		1. public Thread()
	    2. public Thread(String name);  
     	3. public Thread(Runnable target);  
     	4. public Thread(Runnable target, String name);

    -- Methods form Thread Class :
			--> sleep() -- static method of the thread class
			    -- Current thread will get into waiting state for given amount of time
			--> currentThread() -- static method of a thread class
				-- will return the instance of the thread which is in currently exectution.
			--> join() -- instance method of thread class
			    -- will wait for the current thread to complete its exectution.
			--> isAlive() -- check for the thread is alive or not. ?????

	-- Methods from Object class :
			--> wait() -- will move the current thread into waiting state. and the thread will not awake till 
						  some other thread will call to notify()
					   -- this method must be called in the Synchronized context.
			--> notify() -- will notifies the thread which is in waiting/blocking state. ( it will make the 
						  thread in the waiting state to alive )
			--> notifyAll() -- will notifies all the thread which are in waiting/blocking state.

	

* IO : package --> java.io.*;
		
		1. File class :
			--> used to perform file operations like
				-- creation of file / folder
				-- deletion of file / folder
				-- setting file permission like read and write 
				-- checking for file permissions redable or writable
				-- getting last modified information
				-- checking for existatnce of the file 
			--> Important methods :
				-- createNewFile();
				-- isFile() / isDirectory()
				-- lastModified()
				-- getPath() / getAbsolutePath() / getCanonicalPath()
				-- renameTo()
				-- listFiles()
		2. FileReader class : 
			--> used to read the file :
				-- read the file using read method ( int read() ) which returns integer form of the 
				   character.
				-- read() returns -1 if End Of File reached.

		3. BufferedReader class : 
			--> used to read the file :
				-- BufferedReaders allows you read the bulky file data.
				-- readLine() is the method which return the string.

		4. FileWriter class : 
			--> used to write the file :
				-- use write() method to write the char[] , char or String to the file.
				-- also creates a new file, in case not in existatnce.
				-- or opens the exisisting file but will make it empty for use.

			--> you can also append the file by making 2nd param of the FileWriter 
				Constructor as true. FileWriter fw = new FileWriter(File fle , boolen appendable)

			--> use always a flush() method at the end of all write operations, to write the data 
				into the file permanently.

		5. BufferedWriter class : 
			--> used to write the bulk content into the file.
			--> you can use the write(String s) method to write the content.
			--> newLine() method will help you to insert a newLine into the file.
			--> as of FileWriter BufferedWriters also has the flush() method to write the contents to 
				the file permanently.

		6. LineNumberReader : 
			--> This class is a character input stream that keeps track of the number of lines of 
			    text that have been read from it

		7. InputStreamReader : 
			--> This class is a character input stream that uses a byte input stream as its data source.
			--> you can also use this class to read the data from the console.
			--> use constructor InputStreamReader(InputStream in) // InputStream -- System.in
			    to read from the console.

		8. PrintWriter :
			--> This class is a character output stream that implements a number of print( ) and 
				println( ) methods that output textual representations of primitive values and objects.
			--> important methods :
				-- write(String), write(char[])
				-- print(int )  --- and all overloaded versions
				-- println(int ) --- and all overloaded versions
			--> you can make PrintWriter autoflushable using const---or 2nd param true
			--> make sure you are using println() method to see the autoflushable behaviour.

	--> Serialization :
		--> Serialization is the process of saving the state of the Object.
		--> The ObjectOutputStream serializes objects, arrays, and other values to a stream.
		--> The writeObject( ) method serializes an object or array, and various other methods
			write primitive data values to the stream.
		--> Note that only objects that implement the Serializable or Externalizable interface can be serialized.
		--> Serializable is the marker interface.

		--> Deserialization :
			-- ObjectInputStream deserializes objects, arrays, and other values from a stream that was 
			   previously created with an ObjectOutputStream
			-- The readObject( ) method deserializes objects and arrays (which should then be cast to
			   the appropriate type); various other methods read primitive data values from the stream.

		--> For Ex : there is a class Table and Table has-a Plate.
			-- if we want to serialize the Table Object, then we have to make Table as well as Plate 
			   implements Serializable.
			-- if the Table class implements Serializable then, the process of writting Object 
			   will fail (RuntimException occurs : java.io.NotSerializableException: Plate) due to the Plate 
			   is not implementing Serializable.
		--> if the attribute of the class marked transient then, after deserialization you will get 
			default value. ( the attribute will be omitted from the Serialization process).

		--> if the subclass implements Serializable then, in the deserialization process of subclass 
			Object state, all super class default constructors will be called.

		--> Any class who implements Serializable then, after deserialization process the Const---or
			of the serialized class will never be called.


Inner Class : a class def within the another class.

types :
	1. Nested Inner Class
	2. Method Local Inner Class
	3. Static Inner Class
	4. Anonymous Inner Class