class A{
	A getInstance(){
		A a1 = new A();
		return a1;
	}
}

class B extends A{
	B getInstance(){ // Legat override with co-varient return
		B b1 = new B();
		return b1;
	}
}