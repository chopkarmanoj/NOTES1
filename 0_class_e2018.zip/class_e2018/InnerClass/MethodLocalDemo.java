class Animal{
	void eat(){
		System.out.println("Animal is eating");

	class Cat{
		void test(){
			System.out.println("Cat is eating");
		}
	}
	Cat c = new Cat();
	c.test();

	}
}



class MethodLocalDemo{
	public static void main(String[] args) {
		Animal a = new Animal();
		a.eat();
	}
}