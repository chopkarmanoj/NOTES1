class MyOuter{
	void test(){
		System.out.println("Reply from test of MyOuter class");
	}
		

	static class MyInner{
			void test1(){
				System.out.println("Reply from test1 of MyInner Class");
			}
		}


	}class StaticClassDemo{
		public static void main(String[] args) {
			MyOuter.MyInner mi = new MyOuter.MyInner(); //No Instance of outer class requires
			mi.test1();
			
		}
	}
