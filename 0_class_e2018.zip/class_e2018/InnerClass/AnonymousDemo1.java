interface Testable{
	void test1();
}

class MyTest{
	Testable t = new Testable(){
		public void test1(){
			System.out.println("reply from test1 of Testable");
		}
		};

	void t1(){
		t.test1();
	}
}
class AnonymousDemo1{
	public static void main(String[] args) {
		MyTest mt = new MyTest();
		mt.t1();
	}
}
//We can either implement an interface or extend a superclass, one at a time. Applying both at a time is not possible