class Cricket{
	void play(){
		System.out.println("Playing Cricket");
	}
}

class BasketBall{
	void play(){
		System.out.println("Playing Basketball");
	}
}

class MyGames{

	Cricket c = new Cricket(){
		void play(){
			System.out.println("I am Playing the Cricket Now !!");
		}
	};

	BasketBall bb = new BasketBall(){
		void play(){
			System.out.println("I am Playing the Basketball Now !!");
		}
	};
	void playMyGame(){
		c.play();
		bb.play();
	}
}

class AnonymousDemo{
	public static void main(String[] args) {
		MyGames mg = new MyGames();
		mg.playMyGame();
	}
}