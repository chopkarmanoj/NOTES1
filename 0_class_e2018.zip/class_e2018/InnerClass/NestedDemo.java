class MyOuter{
	int a = 10;

	int getA(){
		return a;
	}

class MyInner{
	int x = 20;
	int getX(){
		return x;
	}

	void test(){
		System.out.println("Reply from test");
		System.out.println("this ref : "+this);// Reference of Inner class
		System.out.println("Outer this ref : "+MyOuter.this); //here we accessing the 'this' of MyOuter class
	}
}
}

class NestedDemo{
	public static void main(String[] args) {
	MyOuter mo = new MyOuter();
	System.out.println(mo.getA());	

	MyOuter.MyInner mi = mo.new MyInner();	
	System.out.println(mi.getX());

 
	mi.test();
	System.out.println(mi.getA());
	//System.out.println(mo.getX()); error: cannot find symbol
	
	}
}

// Inner Class : a class def within the another class.
// types :
// 	1. Nested Inner Class
// 	2. Method Local Inner Class
// 	3. Static Inner Class
// 	4. Anonymous Inner Class