class CastDemo{
	public static void main(String[] args) {
		byte b1 = 24;
		short s1 = b1;
		System.out.println(s1);

		short s2 = 25;
		int i1 = s2;
		System.out.println(i1);

		byte b2 = 126;
		int i2 = b2;
		System.out.println(i2);

		int i3 = 45;
		float f1 = i3;
		System.out.println(f1);

		int i4 = 268;
		long l1 = i4;
		System.out.println(i4);

		char c1 = 'a';
		int i5 = c1;
		System.out.println(i5);
		
		long l5	= 34; // in this casting size is not compared. it compares the precision, float has higher precision than long.
		float f5 = l1;

		int i6 = 65;
		//char c6 = i6;
		short s11 = 45;
		byte b11 = (byte)s11; // Explicit cast ---v lossy cast
		System.out.println(b11);

		short s12 = 245;
		byte b12 = (byte)s12;
		System.out.println(b12); 

		long l13 = 567;
		short s13 = (short)l13;
		System.out.println(l13);
	}


}