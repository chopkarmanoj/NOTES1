System is a class which has three objects : in, out and error
System.out.println is a predefined method in class System

* Identifier and Literals :
	--> Identifier : who identify themselves through out the program.	
		Ex : int a; // a is an identifier.

		-- Only $ and _ is allowed in the identifier.
	--> Literals :

		1. Integer Literal :
			--> Decimals (10,203,40) -- the numbers with base 10
			--> Hexadeicmals (0x458A, 0XAbc) -- the numbers with base 16 --  0x or 0X is the prefix
			--> Octals (012, 001, 010) -- the numbers with base 8 -- 0 is the prefix
			--> Binary (0b1100110, 0B110101) -- the numbers with base 2 -- 0b or 0B is the prefix

		2. Float
			--> any floating point number in java is by default double.
			--> for a floating point number ex : 3.14, the user should add 'f' or 'F' at the end.

			default values
			Inteher - > 0
			Float - > 0.0f
			double - > 0.00
			Character - > /u000
			Boolean - > false

* Control Structures :
	--> loops 
		--. for loop
		--. while loop

	--> non-loops
		--. if / if-else
		--. switch


	int a = 5;

	if(a == 5){
		// -------------- 1

		if(a > 3){
			// -----------2
		}else{
			// ----------3
		}

		if(a < 6){
			// ----------4
		}
	}

	if(a > 3){
		// ----------- 1
	}else if(a < 6){
		// -----------2
	}else if(a == 5){
		// -----------3
	}

* Class and Object.
	class : collection of Objects
	Object : template of the class.
	
	class Vehicle :
		--> has-a
			-- Vehicle has-a wheels.
			-- Vehicle has-a company
			-- Vehicle has-a cont 

			

		* Casting :
	
	--> byte  (8 bit)
	--> short (16)
	--> int (32)
	--> char (32)
	--> long (64)
	--> float (32)
	--> double (64)

	Casting types :
		1. Down Cast (loss-less cast / Implicit Cast)
		2. Up Cast (lossy cast / Explicit Cast)


									byte 					^
									  |						|
									  |						|
									short 					| (Up cast)
									  |						|
									  |
							char---->int---->float
									  |
									  |
									  long--->double



			down cast : long ---> float , int ---> double, float --> double
		boolean : boolean can not be casted to anything.	

		
	Arrays : 
		-- Arrays are Objects in Java.
		-- Arrays are being constructed rather than created.
		-- length is the attr of the array, which can be used to get the length of the array.
			Ex ; 
				int ary[] = new int[3];
				System.out.println(ary.length); // op : 3
		-- Multidimensional Arrays :
			-- java supports jagged array.
				int[][] ary7 = new int[3][3];
				int[] ary8[] = new int[4][3]; // legal
				
				int[][] ary = new int[4][];
				ary[0] = new int[3];
				ary[1] = new int[4];


* Method Overload : 
	-- method with same signature but diff. param list is method Overload.
	-- if only return type is different but parametera are same then it is not Overloading
	-- java will find the exact match first, if the exact match is not applied then java will find 
		the suitable method by applying casting on the given types else it gives 
		Error : No Suitable method found as it does not match any method signature
	-- you may get an error that the call to the method is ambiguous, means more then 1 method is 
		matching with the given types.
	-- Overridden method should have more or at least equal access modifier to the method in the super class
	-- We cannot Override statics

* Inheritance :	
	-- it follows is-a realtionship.
	-- it is the realtionship between super class and sub class.
		Ex :
		  Animal (<-- super class)
			^ 
			|
			|
		   Dog (<-- Sub class)
		(Dog is-a Aniaml)
	-- java supports only single level Inheritance.
		(a class can inherit from only 1 super class.)

			A 	C
			|	|
			|	|
			B 	B ( Not allowed in java)

			A 	A 
			|	|
			|	|
			B 	C (allowed)

			X
			|
			|
			Y
			|
			| 
			Z (allowed)
	-- Inheritance is every where in Java, you can not create a single class without Inheritance.
	-- Every class created by the programmer has the absolute super class and i.e. Object
	-- instance of super class cannot access cannot access the method of subclass.

* Create a class MyStack with void push(int), int pop() and displayStack() methods.
	-- create another class with main method and use MyStack.

	
* Method Override : 
	-- Method with the same signature, param and return type (except covarient return) is present in the sub class then, the 
		method is said to be Overridden.

* Abstract class : 
	-- abstract class cannot be instantiated. so, it must be subclassed.
	-- abstract class is an incomplete class which tells the programmer that, what to do, but not how to do.
	-- if a method marked as abstract then, the class should also marked as abstract.
	-- the first concrete subclass in hirerchy of abstract classes should Override all the 
		abstract methods from its super class.

* Final :
	-- Final Variable :
		--. if a Variable marked final then, programmer can not change its value. 
		(its value will be fixed (final))
		(value of the final Variable can not be changed once init.)

	-- Final method :
		--. final method can not be overridden.

	-- Final class :
		--. final class can not be inherited.


* can we mark method as abstract and final both at the same time ? NO
* can we mark class as abstract and final both ? NO
* we can have a final method in abstract class but vice versa is not possible.

* Polymorphism :
	-- it is the ref of super class, holding the instance of subclass
	-- in java Object is actually showing multiple behaviour. (Polymorphic behaviour)
	-- Polymorphism melts down at runtime.

* Encapsulation :
	-- attr must be marked as private and methods must be marked as public.

*  Static :
	-- static are class specific, not instance specific.
	-- statics can be accessed with class name.
		Ex :
		class Chair{
			static int cost;
		}

		==> Chair.cost = 400; --> accessing cost (static) with class name.
	-- statics get loaded when the class get loaded.
	-- you can not access non-static in the static context.

	-- static Variable : 
		-- if we marked the Variable as static then, the Variable will class specific rather than,
			Object.
		-- it will share its value will all instances of the class.

	-- static method : 
		-- it shares the common functionality with class instances.

	-- static block : 
		-- static blocks act as initilizers.


* Constructor : 
	-- Constructors are used to construct the objects in java.
	-- There is a default Constructor present in the class if the programmer didnt define 
		any Constructor. (javas provided Constructor)
	-- The default Constructor is also known as non-param Constructor.
	-- The Constructor can be defined with the following syntax : 
		class_name(pram1, ....){
			------ // body of the constructor.
		}
	-- Note : there is no return type for the Constructor.
	-- If by mistake a programmer gave the return type to the Constructor then, it will
		be treated as method of the class.
	-- You can also write, the param Constructor.
	-- Constructor can also be overloaded.

	-- there is call to super() in every Constructor of java. It can be either programmer defined call	
		or will be inserted by java.

	-- super() <-- call to super class Constructor.
	-- this <-- ref to current class instance. 
	-- super <-- instance of super class.
	-- this() <-- call to current class Constructor.