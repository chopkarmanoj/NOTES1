class ExceptionDemo{
	public static void main(String[] args) {
		System.out.println("Main Starts");

		try{
			System.out.println("Trying Dangerous Code");			
			int a = 10;
			int b = a / 0;
			System.out.println("Dangerous Code Ends");
		}catch(ArithmeticException e){
			System.out.println("There is an Exception");
		}

		System.out.println("Main Ends");
	}
}