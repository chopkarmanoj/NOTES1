//Runnable is not a marker interface as it contains an abstract method i.e public static void run()
class MyThread implements Runnable{
	public void run(){
	for(int i=0; i<5; i++){
		System.out.println("by : "+Thread.currentThread().getName()+" "+i);
		try{	
				Thread.sleep(500);
			}catch(Exception e){
				e.printStackTrace();
			}
	}
}
}
class ThreadDemo3{
	public static void main(String[] args) {
		System.out.println("Main Starts-----------");

		MyThread mt1 = new MyThread(); // instance of Runnable created not an instance of Thread
		//MyThread mt2 = new MyThread();
		Thread t1 = new Thread(mt1); // Giving runnable instance to Thread()
		Thread t2 = new Thread(mt1);
		t1.start(); 
		t2.start();
		for(int i=0; i<5; i++){
			System.out.println("by "+Thread.currentThread().getName()+" "+i);
			try{	
				Thread.sleep(2000);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	System.out.println("Main Ends");
	}
}