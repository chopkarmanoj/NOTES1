import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class SaveCode extends HttpServlet{
	public void doPost(HttpServletRequest req, HttpServletResponse res)throws IOException, ServletException{
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();

		String Uname = req.getParameter("nme");
		String Password = req.getParameter("pwd");
		out.print("Entered Username is : "+Uname+"<br> Entered Password is : "+Password);

		Cookie c = new Cookie("myuname",Uname);
		c.setMaxAge(60);
		res.addCookie(c);

		Cookie c1 = new Cookie("mypwd",Password);
		c1.setMaxAge(60);
		res.addCookie(c1);

		//out.print("Info saved in cookie is available in the browser settings");
		out.print("<br>Info saved in cookie<br>");
		out.print("<a href='http://localhost:8080/app9/RetrieveCookie.xyz'>Click to Retrieve Cookie </a>");

		out.close();
	}
}
// --> Cookie : Cookie is the small amount of information that can be stored
// 	in user browser
// 	--. Non - persistant : if the user closes the browser tab, the cookie will be auto removed 
// 	--. persistant : these cookies will be alive even if the user closes the tab or the browser

// 	--> cookie has the maximum age limit (the time in sec)
// 	--> cookie can store only string data.