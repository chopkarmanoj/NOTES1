import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class HelloServlet extends HttpServlet{
		public void doGet(HttpServletRequest req, HttpServletResponse res)
		throws IOException, ServletException{
			res.setContentType("text/html");

			PrintWriter pw = res.getWriter(); 
			pw.print("Hello this is the reply from HelloServlet<br>");
			pw.print("<h3>this may be the another line.... </h3>");
			pw.print("this is just added line");




			pw.close();

		}

}