import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Hello7 extends HttpServlet{
	public void doGet(HttpServletRequest req, HttpServletResponse res)throws IOException, ServletException{
		res.setContentType("text/html");
		// PrintWriter out = res.getWriter();

		// out.print("This is the reply from Test.xyz <br>");
		res.sendRedirect("http://localhost:8080/app6");

		//out.close();

	}
}

// //Common Interview Question : Difference between sendRedirect and Forward method
// --> sendRedirect is a client side method for redirection
// --> Forward is a server side method for redirection
// --> when sendRedirect method is used then resquest and response object become null as soon as redirection is done 
// --> when forward method is used for redirection then request ans response object stays alive even after redirection