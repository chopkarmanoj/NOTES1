import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class HomeServlet extends HttpServlet{
	public void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException, ServletException{
		res.setContentType("text/html");
 		PrintWriter out = res.getWriter();
		String uname = req.getParameter("uname");
		String msg = "Hello <b>"+uname+"</b>, You are now on Admin Homepage !!";
		out.print(msg);
		out.close();
	}
}