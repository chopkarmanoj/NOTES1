import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ValidateServlet extends HttpServlet{
	public void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException, ServletException{
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		String val1 = req.getParameter("uname");
		String val2 = req.getParameter("pwd");
		if(val1.equals("admin")&&val2.equals("admin")){
			
			//Username and Password correct, hence Forward to Home Servlet
			RequestDispatcher rd = req.getRequestDispatcher("Home.xyz");
			rd.forward(req,res);
			//out.print("<h1>Validate succesfull!!!</h1>");

		}else{
			//Username or Password incorrect, hence include to index page
			//Request Dispatcher is an interface which cannot be directly instantiated hence we use getRequestDispatcher method of req object
			//RequestDispatcher object rd is basically used to forward(forward redirection) or include(backward redirection) the request and response objects i.e req and res

			RequestDispatcher rd = req.getRequestDispatcher("/index.html");
			out.print("<font color = 'red'>Username or Password Incorrect !!</font>");
			rd.include(req,res);
		}
		out.close();
	}
}


// --> RequestDispatcher is an interface
// --> this interface can be used to forward or include the req and res Object from one page to another
// --> the advantage of using these methods, is the req and res Object will be alive and also keeps 
// 	the value with them
// --> the forward and include methods are server side methods.