import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class AddDemo extends HttpServlet{
	public void doPost(HttpServletRequest req, HttpServletResponse res)throws IOException,ServletException{
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		// String val1 = req.getParameter("val1");
		// String val2 = req.getParameter("val2");
		int n1=0, n2=0, a=0;
		try{
				n1 = Integer.parseInt(req.getParameter("val1"));
				n2 = Integer.parseInt(req.getParameter("val2"));
				a = n1+n2;
			}catch(NumberFormatException nfe){
				out.print("Please Enter Number Only");
			} 

		out.print("<h3>Addition of"+n1+" and "+n2+" is : <h3>"+a+"</h3>");

		out.close();




	}
}