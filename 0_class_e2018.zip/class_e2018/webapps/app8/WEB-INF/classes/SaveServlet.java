import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class SaveServlet extends HttpServlet{
	public void doGet(HttpServletRequest req, HttpServletResponse res)throws IOException,ServletException{
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();

		String name = req.getParameter("nme");
		out.print("We reccieved val as :"+name+"<br/>");
		
		HttpSession se = req.getSession();
		se.setAttribute("myname",name);

		out.print("<h4>The value is saved in session succesfully !!!</h4><br>");
		 out.print("To view the session value you can click the following <a href='http://localhost:8080/app8/Retrieve.xyz'>Retrieve Session Link</a>");


		out.close();
	}
}