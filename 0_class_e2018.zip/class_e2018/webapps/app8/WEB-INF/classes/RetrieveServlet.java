import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class RetrieveServlet extends HttpServlet{
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException{
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();

		out.print("<h2>Session Retrieved</h2>");
		HttpSession se = req.getSession();
		//out.print("The value retrieved from session : "+se.getAttribute("myname"));
		String val = (String) se.getAttribute("myname");
		out.print("Session val retrieved :<b> "+val+"</b>
			");

	
	out.close();
}}