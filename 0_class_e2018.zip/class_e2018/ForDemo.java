class ForDemo{
	public static void main(String[] args) {
		// int i=0; This results in inefficient use of stack and scope of variable is throughout the method
		for(int i=0; i<5 ;i++){ // This declaration results in efficient utilization of stack and scope of the variable is limited to the loop
			//System.out.println(i);  // println stands for print_line. it prints on new line.
			System.out.print(i+" "); //simple print with space concatenation
		}

		int i = 0;
		while (i < 5) { // required boolean; while (true) <-- Infinite loop It is same as while(1) in C language
			System.out.println(i);
			i++;			
		}

		// Difference between for and while is that iterations are fixed in for and not fixed in while. this is more clear when loops are working on the strings.
	}
}