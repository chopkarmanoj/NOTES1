import java.io.*;
class CopyFileD{
			void myCopy(String source, String dest){
			try{
				 FileReader fr = new FileReader(dest);
				 FileWriter fw = new FileWriter(source);
				 int x;
				while((x = fr.read()) != -1){
					fw.write(x);
				}			
				fw.flush();
				fw.close();

				System.out.println("File "+source+" copied to "+dest+" succesfully !!!");
			}catch(Exception e){ e.printStackTrace();}
		}
}

class CopyFileDemo{
	public static void main(String[] args) {
		CopyFileD cf = new CopyFileD();
		cf.myCopy("CopyFileDemo.java","Duplicate_CopyFileDemo.java");
	}
}