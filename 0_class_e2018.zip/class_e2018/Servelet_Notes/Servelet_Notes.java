app1 : root dir of the project
	--> WEB-INF : contains all the java classes with itss configuration
		-- . classes(folder) : contains all the java classes
		-- . lib(folder) : contains all the external .jar files as a lib
		-- . web.xml : servlet configuration file.
					--this file is to be created only after creating the servlet/dynamic class.
	--> may 

	-->Any change in the classes folder or in the web.xml file requires restarting of the tomcat server to see reflected the changes.
	--> All files out of WEB-INF are static files. Changes to theses files do not require tomcat restart.

	app1 : root dir of the project
	--> WEB-INF : contains all the java classes with its configuration
		-- . classes : contains all the java classes
		-- . lib : contains all external .jar files as a lib 
		-- . web.xml : servlet configuration file.
	--> may contains all the static data
		like : js / css / .html / .htm / .jsp

--> Rules for writing servlet class
	-->Import three packages servlet,httpservlet and io 
	--> Make the servlet class public
	--> extend the servlet class to HttpServlet



-->MustKnowConcepts
	--> Request Response Object
	--> Session
	--> Cookies
	--> Request Dispatcher