interface I1{
	void test();
}
interface I2{
	void test2();
}
class A{
	void test1(){
		System.out.println("test1");
	}
}

class C extends A implements I1,I2{
	/*class can extend only one superclass but can implement multiple interfaces at a time.
	extends --> keyword should be used first and then implements <--- keyword is to be used
	*/
	
	public void test(){
		System.out.println("From test");
	}

	public void test2(){
		System.out.println("test2");
	}
}

class InterfaceDemo4{
	public static void main(String[] args) {
		C c1 = new C();
		c1.test();
		c1.test1();
		c1.test2();
	}
}