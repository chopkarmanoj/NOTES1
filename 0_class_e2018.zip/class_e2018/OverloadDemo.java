class MyOperations{
	void add(int x, int y){
		System.out.println(x+y);
	}

	void add(int x, int y, int z){
		System.out.println(x+y+z);
	}

}

class OverloadDemo{
	public static void main(String[] args) {
		MyOperations mo = new MyOperations();
		mo.add(10,25);
		mo.add(1,2,3);
		//mo.add(); // Error : No Suitable method found as it does not match any method signature

		
	}
}