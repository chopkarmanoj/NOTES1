class MyOperations{
	void add(int x, int y){
		System.out.println("int int");
	}
	void add(double d1,double d2){
		System.out.println("double double");
	}
	void add(int x, double y){
		System.out.println("int double");
	}
	void add(double d1, int x){
		System.out.println("double int");
	}
}

class OverloadDemo1{
	public static void main(String[] args) {
		MyOperations mo = new MyOperations();
		mo.add(12,23.23);
		//mo.add("abc","X"); Error: No suitable method found for add(String,String);
		
	}
}