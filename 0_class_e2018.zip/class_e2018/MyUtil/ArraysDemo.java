//

import java.util.*;

class ArraysDemo{
	public static void main(String[] args) {
		int[] ary = {12,36,95,78,78,64,25};
		for(int x : ary){
			System.out.print(x+", ");
		}
		System.out.println();
		
		Arrays.sort(ary); //sort method is directly accessed by classname Arrays
		//Arrays.sort(ary,4,7); //to sort subpart of array
		for (int x : ary){
			System.out.print(x+", ");
		}
		System.out.println();

		String c =  Arrays.toString(ary);
		System.out.println(c);

		int x = Arrays.binarySearch(ary,45);
		System.out.println("Key present in array at index : "+x );

		//If the element is not present in the given array, then the binarySearch method will return the index where the value can be inserted but with a negative sign
		
		int y = Arrays.binarySearch(ary, 12);
		System.out.println("key present in array at index : "+y);


		Arrays.fill(ary, 2, 4, -2); //to fill a subpart
		for (int z : ary){
			System.out.print(z+", ");
		}
		System.out.println();

		Arrays.fill(ary, 2); //to fill a subpart
		for (int a : ary){
			System.out.print(a+", ");
		}
		System.out.println();



}
}