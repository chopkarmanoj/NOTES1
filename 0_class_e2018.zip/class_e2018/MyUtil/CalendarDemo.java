import java.util.*;
//Calendar class is abstract class and cannot be directly instantiated. But we can get its instance through getInstance

class CalendarDemo{
	public static void main(String[] args) {
		Calendar c1 = Calendar.getInstance();
		//System.out.println(c1);
		//All the members of Calendar class are constants and are marked as static and final. Hence they can be directly accessed by the class.
		System.out.println("Year : "+c1.get(Calendar.YEAR));
		System.out.println("Week of Month : "+c1.get(Calendar.WEEK_OF_MONTH));
		System.out.println("Week of Year : "+c1.get(Calendar.WEEK_OF_YEAR));
		
		System.out.println("Day of Month : "+c1.get(Calendar.DAY_OF_MONTH));
		System.out.println("Day of Week : "+c1.get(Calendar.DAY_OF_WEEK));
		System.out.println("Day of Year : "+c1.get(Calendar.DAY_OF_YEAR));

		System.out.println("Date is : "+c1.get(Calendar.DATE));
		System.out.println("Month is : "+c1.get(Calendar.MONTH));
		System.out.println("Hour of the day running : "+c1.get(Calendar.HOUR_OF_DAY));



		Date d = c1.getTime();
		System.out.println("Date : "+d);

		// c1.add(Calendar.MONTH,5);
		// System.out.println("Month added : "+c1.getTime());

		// c1.add(Calendar.DATE,10)		;
		// System.out.println("Date added : "+c1.getTime());


		c1.roll(Calendar.DATE,10);
		System.out.println("Date rolled : "+c1.getTime());
		
		//Difference between roll and add method : roll method allows to roll in the same month or year
		
	}	
}