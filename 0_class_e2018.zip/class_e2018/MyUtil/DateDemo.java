import java.util.*;
class DateDemo{
	public static void main(String[] args) {
		// Date d1 = new Date(100000000L);
		// System.out.println(d1);

		Date d1 = new Date(); //Current Date
		System.out.println(d1);

		System.out.println("Time : " +d1.getTime());
		System.out.println("Date : "+d1.getDate());
		System.out.println("Hours : "+d1.getHours());
		System.out.println("Minutes : "+d1.getMinutes());
		System.out.println("Seconds : "+d1.getSeconds());
		System.out.println("Month : "+d1.getMonth());
		System.out.println("GMT string : "+d1.toGMTString());
	}
}