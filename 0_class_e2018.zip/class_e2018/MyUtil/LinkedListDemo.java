import java.util.*;
//allows easy insert and remove operations
// allows dup;icates
// List is an ordered collecton as it maintains the order in which they are inserted.
class LinkedListDemo{
	public static void main(String[] args) {
		LinkedList<Integer> l1 = new LinkedList<Integer>();
		l1.add(10);
		l1.add(20);
		l1.add(30);
		l1.add(40);
		l1.add(50);


		l1.add(1,15); // add(index. element)
		for(int i=0; i<l1.size(); i++){
			System.out.println(l1.get(i));
		}


		l1.addFirst(05);
		l1.addLast(55);

		System.out.println(("List : "+l1));

		l1.removeFirst();

		System.out.println(("List : "+l1));

		l1.removeLast();

		System.out.println(("List : "+l1));

		l1.remove(3);  //Remove by index method

		System.out.println(("List : "+l1));


	}
}