import java.util.*;

//Hash is an unordered collection
//Does not permit to store duplicates, simply omits the call to insert duplicate
//No set allows to store duplicate
//Inorder to maintain the order of elements in the set, SortedSet can be used

class HashSetDemo{
	public static void main(String[] args) {
		HashSet<Integer> hs1 = new HashSet<Integer>();
		hs1.add(100);
		hs1.add(200);
		hs1.add(300);
		hs1.add(400);

		System.out.println("Print : "+hs1);
		System.out.println("Size of HS = "+hs1.size());


		hs1.add(200);
		System.out.println("Print : "+hs1);	



		Iterator<Integer> it = hs1.iterator();

		while(it.hasNext()){
			System.out.println("Ele : "+it.next());
		}
		

		System.out.println("Contains 100 ? : "+hs1.contains(100));
	}
}
