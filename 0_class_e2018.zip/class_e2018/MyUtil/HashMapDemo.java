import java.util.*;

//HashMap uses <K,V> i.e key value pair
//Duplicate values ar allowed
//Duplicate keys are not allowed

class HashMapDemo{
	public static void main(String[] args) {
		HashMap<Integer, String> hm = new HashMap<Integer, String>();
		hm.put(2,"Gupta");
		hm.put(4,"Marodkar");
		hm.put(3,"Diwija");
		hm.put(5,"Gupta");
		

		System.out.println("Hm : "+hm);


		hm.put(4,"Manjeet");
		System.out.println("hm : "+hm);
	}

}