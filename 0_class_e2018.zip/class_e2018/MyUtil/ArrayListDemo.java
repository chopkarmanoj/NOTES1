import java.util.*;

class ArrayListDemo{
	public static void main(String[] args){
		ArrayList<String> al1 = new ArrayList<String>();
		al1.add("Reetu");
		al1.add("Disha");
		al1.add("Rashi");

		System.out.println("Zeroth Element : "+al1.get(0));
		System.out.println("arraylist : "+al1);   //Since its a list we can print the complete list at a time

		for(int i = 0; i<al1.size(); i++){
			System.out.println("List "+i+" : is "+al1.get(i));
		}
		
		al1.set(1,"jfghcfgdsdxgcxb");
		System.out.println("arraylist : "+al1);

		al1.remove(2);
		System.out.println("arraylist : "+al1);

		al1.add("Reetu");
		al1.add("Reetu");
		al1.add("Reetu");
		al1.add("Reetu");
		System.out.println("arraylist : "+al1);
		System.out.println("Index of Reetu : "+al1.indexOf("Reetu"));
		System.out.println("Last Index of Reetu : "+al1.lastIndexOf("Reetu"));



	}

}