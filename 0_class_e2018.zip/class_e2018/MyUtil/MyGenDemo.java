//Class with a parameter is called as generic class.
T : Type V : Value  E : Element K : Key
class SaveVal<T>{
	T x;

	void setX(T val){
		x = val;
	}

T getX(){
	return x;
}
}
class MyGenDemo{
	public static void main(String[] args) {
		SaveVal<Integer> s = new SaveVal<Integer>();  		//Making use of wrapper integer to pass object of type integer
		s.setX(10);
		System.out.println("Integer x : "+s.getX());


		SaveVal<String> s1 = new SaveVal<String>();
		s1.setX("Disha");
		System.out.println("String x : "+s1.getX());
	}
}

