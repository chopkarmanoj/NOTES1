import java.util.*;
class StackDemo{
	public static void main(String[] args) {
		Stack<Integer> s1 = new Stack<Integer>();
		s1.push(10);
		s1.push(24);
		s1.push(65);
		s1.push(45);
		s1.push(69);

		System.out.println("popped : "+s1.pop());
		System.out.println("is empty : "+s1.empty());

		System.out.println("Is Present : "+s1.search(24));


		System.out.println("peek : "+s1.peek());
		while(!s1.empty()){
			System.out.println("popped : "+s1.pop());
		}
	
		Stack<String> s2 = new Stack<String>();
		s2.push("Ramu");
		s2.push("Shamu");
		System.out.println("Popped : "+s2.pop());
	}
}