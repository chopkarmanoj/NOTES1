import java.util.*;

class StringTokenizerDemo{
	public static void main(String[] args) {
		String str = "Hey I am Learning Java Collections and I am exploring Token class now ";
		StringTokenizer st = new StringTokenizer(str," ");
		System.out.println("No. of tokens : "+st.countTokens());


		// while(st.hasMoreTokens()){
		// 	System.out.println("token "+(i++)+" : "+st.nextToken());
		// }
		

		ArrayList<String> al1 = new ArrayList<String>();

		int i = 1;
		while(st.hasMoreTokens()){
			al1.add(st.nextToken());
		}

		System.out.println("New Array List : "+al1);
//We can get access to any token by using arraylist and its get(index) method	
System.out.println("Get 5th Token : "+al1.get(4));
	}

}