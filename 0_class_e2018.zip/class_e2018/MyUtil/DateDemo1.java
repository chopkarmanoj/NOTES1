import java.util.*;
import java.text.*;

//Inorder to use the dateformat class, it is mandatory to include the text package
//If we give the date instance of Date class to DateFormat class it returns the formatted date
//Dateformat class is abstract class and cannot be directly instantiated. But we can get its instance through getDateInstance
class DateDemo1{
	public static void main(String[] args) {
		Date d1 = new Date();
		System.out.println("Current Date Time : "+d1);

		DateFormat df1 = DateFormat.getDateInstance(DateFormat.SHORT);
		System.out.println("Short date format : "+df1.format(d1));

		DateFormat df2 = DateFormat.getDateInstance(DateFormat.LONG);
		System.out.println("long format : "+df2.format(d1));

		DateFormat df3 = DateFormat.getDateInstance(DateFormat.FULL);
		System.out.println("full format : "+df3.format(d1));

		DateFormat df4= DateFormat.getDateInstance(DateFormat.MEDIUM);
		System.out.println("Medium format : "+df4.format(d1));
	}
}