class ThreadDemo1{
	public static void main(String[] args) {
		Thread t = Thread.currentThread(); //creates instance of the current thread..in this case its the main thread.

		System.out.println("Thread name is : "+t.getName());
		for(int i =0; i<7; i++){
			System.out.println("i : "+i);
			try{
				Thread.sleep(1500);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	}
}