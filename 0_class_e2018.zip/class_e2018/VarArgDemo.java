class MyOperations{
	void add(int... x){ 
		int sum = 0;
		for(int i=0; i<x.length; i++){ //VarArg behaves as array inside the methods, hence all array operations are applicable on VarArg
			sum += x[i];
		}	//for(int a : x)	sum += a;
		System.out.println("addn is : "+sum);
	}
}


class VarArgDemo{
	public static void main(String[] args) {
		MyOperations mo = new MyOperations();
		mo.add(10,20);
		mo.add(14,15,19,8,5);
		mo.add(88);
		mo.add(1487,15986,12584);

		int[] ary = {'A','B'};
		mo.add(ary);
	}
}