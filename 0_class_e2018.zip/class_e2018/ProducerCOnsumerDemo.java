class ProducerConsumer{
	int n = -1;
	synchronized void produce() throws Exception{
		if (n != -1){
			System.out.println("No need to produce anymore");
			wait(); // wait() and notify() to be called in synchronized context only
		}else{
			n = 10;
			System.out.println(n+" Produced . . !");
			Thread.sleep(1000);
			notifyAll();
		}

	}

	synchronized void consume() throws Exception{
		if( n != -1){
			System.out.println("Consumed by : "+Thread.currentThread().getName());
			n = -1;
			Thread.sleep(1000);
			notify();
		}else{
			System.out.println("Nothing to consume!");
			wait();
		}

	}
}
class MyThread implements Runnable{
	ProducerConsumer pc;
	MyThread(ProducerConsumer pc){
		this.pc = pc;
	}

	public void run(){
		while(true){
			try{
			String nm = Thread.currentThread().getName();
			if(nm.equals("Producer")) pc.produce();
			else pc.consume();

		}catch(Exception e){ e.printStackTrace();}

	}
}
}
class ProducerConsumerDemo{
	public static void main(String[] args) {
		ProducerConsumer pc = new ProducerConsumer();
		MyThread mt1 = new MyThread(pc);
		MyThread mt2 = new MyThread(pc);
		Thread t1 = new Thread(mt1, "Producer");
		t1.start();
		Thread t2 = new Thread(mt1,"Consumer_1");
		t2.start();
		Thread t3 = new Thread(mt1,"Consumer_2");
		t3.start();
	}
}