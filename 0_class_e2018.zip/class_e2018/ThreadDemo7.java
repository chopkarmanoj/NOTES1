class MyThread implements Runnable{
	public void run(){
		for(int i=0; i<5; i++){
			System.out.println("by : "+Thread.currentThread().getName()+" : "+i);
			try{
				Thread.sleep(1000);
			}catch(Exception e){ e.printStackTrace();}
		}
	}
}

class ThreadDemo7{
	public static void main(String[] args) {
		System.out.println("Main Starts");

		MyThread mt1 = new MyThread();
		Thread t1 = new Thread(mt1);
		t1.start();


		for(int i=0; i<3; i++){
			System.out.println("by "+Thread.currentThread().getName()+" : "+i);
			try{
				Thread.sleep(500);
			}catch(Exception e){ e.printStackTrace(); }
		}
		try{
			t1.join();   // Join() method causes the thread of the current context to wait until the instance calling the join finishes its execution. In this case main thread is waiting for t1 thread to complete its execution.
		}catch(Exception e){
			e.printStackTrace();
		}

	System.out.println("Main Ends");
	}
	
}