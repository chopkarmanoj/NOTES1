//Example of Thread Synchronization
class Chat{
	synchronized void textMe(){ // if the method is marked as synchronized then it can be entered by only one thread at a time
		System.out.println("Rajkumar---");
		try{
			Thread.sleep(1000);
		}catch(Exception e){
			e.printStackTrace();
		}
		System.out.println("--Hirani");
	}
}
class MyThread implements Runnable{
	Chat c; // this is compulsory to acquire lock for synchronization as the instance has to be intialized
	
	MyThread(Chat val){
		c = val;
	}
	
	public void run(){
		c.textMe();

	}
}
class ThreadDemo5{
	public static void main(String[] args) {
		Chat c1 = new Chat();
		MyThread mt1 = new MyThread(c1);

		Thread t1 = new Thread(mt1);
		Thread t2 = new Thread(mt1);
		t1.start();
		t2.start(); 
	}
}