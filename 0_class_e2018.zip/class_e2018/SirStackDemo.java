class MyStack{
	int[] stk;
	int top;

	void init(){
		stk = new int[5];
		top = -1;
	}

	void extendMe(){
		int[] n = new int[(stk.length) * 2];
		for(int i=0; i<stk.length; i++) n[i] = stk[i];
		stk = n; 
	}

	
	void push(int val){ 
		if((stk.length-1) == top){
			// System.out.println("Stack Full");
			extendMe(); // this method will extend the stack.
			System.out.println("Stack extended to size :"+(stk.length));
		}

		stk[++top] = val;
		System.out.println("Ele pushed : "+val);
	
	}

	int pop(){
		int z = -1;
		if(top == -1){
			System.out.println("Stack Empty");
		}else{
			z = stk[top--];
		}
		return z;
	}

	void displayStack(){
		System.out.println("---------------------");
		for(int i=top; i>=0; i--){
			System.out.println("Stack["+i+"] = "+stk[i]);
		}
		System.out.println("---------------------");
	}
}

class MyStackDemo{
	public static void main(String[] args) {
		MyStack ms1 = new MyStack();
		ms1.init();

		ms1.push(65); ms1.push(34);
		ms1.push(23); ms1.push(67);
		ms1.push(12); ms1.push(89);
		ms1.push(27);

		ms1.displayStack();

		System.out.println("Ele popped : "+ms1.pop());
		System.out.println("Ele popped : "+ms1.pop());

		ms1.displayStack();
	}
}