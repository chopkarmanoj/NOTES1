class MyOperations{
	void add(){
		System.out.println("Addition is :"+(10+20));
	}

	void multiply(){
		System.out.println("mul is : "+(10*20));
	}
}


class MyThread implements Runnable{
	public void run(){
		Thread t = Thread.currentThread();
		String name = t.getName();

		MyOperations mo = new MyOperations();

		if(name.equals("T1")){
			mo.add();
		}else{
			mo.multiply();
		}

	}
}
//Multiple Threadsi.e t1 and t2 are executing the same process i.e MyThread
class ThreadDemo4{
	public static void main(String[] args) {
		System.out.println("Main Starts.........");
		MyThread mt1 = new MyThread();
		 Thread t1 = new Thread(mt1);
		 t1.setName("T1");
		 t1.start();

		 Thread t2 = new Thread(mt1);
		 t2.setName("T2");
		 t2.start();

		 System.out.println("Main Ends.........");
	}
}