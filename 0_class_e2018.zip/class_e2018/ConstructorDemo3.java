class Table{
	double height;
	double width;

	Table(double height, double width){
		this.height = height;  //this references to the instance of the current class
		this.width = width;
	}

	void displayTable(){
		System.out.println("height is : "+height);
		System.out.println("width is : "+width);
	}

	void setHeight(double height){
		// height = height; Shadowing effect
		this.height = height; // this keyword is used to overcome the shadowing effect
	}
}

class ConstructorDemo3{
	public static void main(String[] args) {
		Table t1 = new Table(5.5,15.2);
		t1.setHeight(8.5);
		t1.displayTable();
	}

}