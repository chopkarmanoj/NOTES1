class MyStack{
	int[] stk;
	int top;
	
	void init(){
		stk = new int[5];
		top = -1;
	}
	//Modify the push method in such a way that 
	// the Stack should never say Stack Full
	// (Hint : if the stack is full, create a new stack with double size and 
	// 		copy all prev ele in it)
	
	void extendMe(){
		int[] n = new int[(stk.length)*2];
		for(int i=0; i<stk.length; i++){
			n[i] = stk[i];
			}
			stk = n;
	}

	void push(int val){
		if((stk.length-1) == top){
		//System.out.println("Stack Overflow");*
			extendMe();
			System.out.println("Stack extended to size :"+(stk.length));
		}
		stk[++top] = val;
		System.out.println("Element Pushed : " +val);
		}

	int pop(){
		int z = -1;
		if(top == -1){
			System.out.println("Stack Empty");
		}else{
			z = stk[top--];
		}
	return z;
	}

	void displayStack(){
		System.out.println("------------------------");
		for (int i=top; i>=0 ; i-- ) {
			System.out.println("Stack["+i+"] = "+stk[i]);
			}
		System.out.println("--------------------");
	}

}
class StackDemo2{
	public static void main(String[] args) {
		MyStack S = new MyStack();
		S.init();
		S.push(1);
		S.push(2);
		S.push(3);
		S.push(4);
		S.push(5);
		S.push(6);	
		S.push(7);
		S.push(8);
		S.push(9);
		S.push(10);
		S.push(11);
		S.displayStack();
		
		for(int i = 0; S.top == -1; i++){
		System.out.println("Top : "+S.top);
		System.out.println("Element popped :"+S.pop());
	}
		// System.out.println("Element popped :"+S.pop());
		// System.out.println("Element popped :"+S.pop());
		// System.out.println("Element popped :"+S.pop());
		// System.out.println("Element popped :"+S.pop());
		// System.out.println("Element popped :"+S.pop());
		// S.displayStack();
		
		
				

	}
}