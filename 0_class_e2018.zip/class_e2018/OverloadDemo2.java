class MyOperations{
	void add(char c1, int c2){
		System.out.println("int char");
	}
	void add(int c1, char c2){
		System.out.println("char int");
	}

}

class OverloadDemo2{
	public static void main(String[] args) {
		MyOperations mo = new MyOperations();
		mo.add('a','a'); // Error : Reference to add is ambiguous
	}
}