class WrapperDemo1{
	public static void main(String[] args) {
		String s1 = "12a";
		String s2 = "34";

		try{
		int i = Integer.parseInt(s1);
		int j = Integer.parseInt(s2);

		int k = i + j;
		System.out.println(k);

	}catch(NumberFormatException e){
		System.out.println("Number not in format...Please enter integers only");
	}
		// String s3 = s1 + s2;
		// System.out.println(s3);
	}
}