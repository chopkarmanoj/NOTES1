class A{

}
class B{

}
/* Duplicate Error for multiple definitions with more than one super class
class C extends A{

}
class C extends B{

}
*/
//Having multiple subclass is allowed
class C extends A{

}
class D extends A{

}

class Animal{

}

class Dog extends Animal{

}

class Cat extends Animal{

}

//Transitivity

class X{
	void x1(){
		System.out.println("reply from x1 of X");
	}
}
class Y extends X{
	void y1(){
		System.out.println("reply from y1 of Y");
	}
}
class Z extends Y{
	void z1(){
		System.out.println("reply from z1 of Z");
	}
}
class InheritDemo1{
	public static void main(String[] args) {
		Z z = new Z();
		z.x1();
		z.y1();
		z.z1();
		
	}
}