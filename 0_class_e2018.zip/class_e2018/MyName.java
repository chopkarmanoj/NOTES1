class MyName{
	public static void main(String[] args) {
		System.out.println("My name is Disha");
		System.out.println("I am in Nagpur");
	}
}

// * WAP to print your name.
