class Horse{
	int height;
	int weight;

	private Horse(){
		height = 10;
		weight = 75;
	
	 static Horse getInstance(){
	 	return new Horse();
	 }

	void display(){
		System.out.println("height of animal : "+height);
		System.out.println("weight of animal : "+weight);
	}
}

class AccessInstDemo{
	public static void main(String[] args) {
		// Horse h1 = new Horse(); // Constructor has private access in the class.
		// h1.display(); 

		Horse h1 = Horse.getInstance();
		h1.display();
	}
}