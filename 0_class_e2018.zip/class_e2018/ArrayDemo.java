class ArrayDemo{
	public static void main(String[] args) {
		int arr[] = new int[3];
		System.out.println(arr[0]);

		arr[0] = 10;
		arr[1] = 20;
		arr[2] = 30;
		System.out.println(arr[2]);

		//arr[3] = 40;
		//System.out.println(arr[3]);

		int arr1[] = {1,2,3,4,5}; // In the background the compiler converts this int arr1 = new int[]{1,2,3,4,5}
		System.out.println(arr1[1]);

		int arr2[] = new int[3];
		/* The dimension of array or the elements in the array anyone should be specified, otherwise the compiler gets confused.
		if dimension is to be given then it is to be given after 'new' as it specifies the memory
		*/
		int arr3[] = new int[]{6,7,8,9,10,11};
		System.out.println(arr3[4]);
		//System.out.println(arr3[7]);
		System.out.println("");
		System.out.println("Length of arr3[] is "+arr3.length); //Length is the attribute of the array which can be used to get the length of array.


		System.out.println("Array Using Normal for Loop");
		for (int i = 0; i<arr3.length; i++){
			System.out.println(arr3[i]);
			}

		int[] arr4 = new int[5]; //type is integer array int[]
		System.out.println("");
		System.out.println("");
		System.out.println("Enhanced For");

		/* Enchanced for is applicable only for arrays. It works on complete arrays, not on any particular part of array */
		for (int x : arr3 ) { 
			System.out.println(x);
		}

		int arr5[][] = new int[3][3];
		System.out.println(arr5[0][1]);
		arr5[0][1] = 34;
		System.out.println(arr5[0][1]);

		int arr6[][] = new int[3][];
		arr6[0] = new int[3];
		arr6[1] = new int[2];
		arr6[2] = new int[4];

		System.out.println("Multidimesional array dimensions ");
		System.out.println("Length of Outer Array : "+arr6.length);
		System.out.println("Length of Inner Arrays");
		System.out.println(" First Inner Array : " +arr6[0].length);
		System.out.println(" Second Inner Array : " +arr6[1].length);
		System.out.println(" Third Inner Array : " +arr6[2].length);

		for(int i=0; i<arr6.length; i++){
			for(int j=0; j<arr6[i].length; j++){
				System.out.print(arr6[i][j]+" ");
			}
			System.out.println();
		}

		//int[][] arr7 = new int[3][4];
		//int[] arr8 = new int[4][3]; //legal

		int arr7[][]= new int[5][0];
		//int[] arr7=new int[] {1,2,3,4,5};

		arr7[0] = new int[2];
		arr7[0][0]=1;
		arr7[0][1]=2;
		System.out.println(arr7[0][0]+arr7[0][1]);

		int[] arr8;
		arr8 = new int[5];
		int arr9[]={1,2,3,4,5};



	}
}