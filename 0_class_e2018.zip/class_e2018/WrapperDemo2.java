class WrapperDemo2{
	public static void main(String[] args) {
		if(args.length == 2){
			try{
				int z = Integer.parseInt(args[0]) + Integer.parseInt(args[1]);
				System.out.println("Addn is :"+z);
			}catch(NumberFormatException e){
				System.out.println("Please supply Integers ONLY, & try again");
		}}else{
				System.out.println("Supply any two numbers only & try again");
			}
		}

}