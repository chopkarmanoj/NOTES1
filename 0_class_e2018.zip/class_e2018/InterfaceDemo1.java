interface Stackable{
	void push(int val);
	int pop();
}

class MyStack implements Stackable{
	public void push(int val){

	}
	public int pop(){
		return -1;
	}
}
class InterfaceDemo1{
	public static void main(String[] args) {
		
	}
}