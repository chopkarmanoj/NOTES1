public class PublicDemo{// a class which is marked public should have equal name as filename

}
/* public class PublicDemo{
	-- Duplicate class error
}

public class xyz{
	-- public class xyz should be declared within the file xyz.java
}
*/
// A class is identified as public if it is