class WrapperDemo3{
	public static void main(String[] args) {
		Character c = new Character('a');
		System.out.println(c);

		//isDigit method
		System.out.println("is A digit : "+Character.isDigit('A'));
		System.out.println("is 1 digit : "+Character.isDigit('1'));

		//isLetter method
		System.out.println("is A Letter : "+Character.isLetter('A'));
		System.out.println("is 5 Letter : "+Character.isLetter('5'));

		System.out.println("is A lowercase : "+Character.isLowerCase('A'));
		System.out.println("is A Uppercase : "+Character.isUpperCase('A'));

		System.out.println("is space : "+Character.isSpaceChar(' '));

		System.out.println(" diwija to Title Case : "+Character.toTitleCase('a'));
		System.out.println("Upper case : "+Character.toUpperCase('b'));

		System.out.println("is Title Case : "+Character.isTitleCase('B'));


	}
}