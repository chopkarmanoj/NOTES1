class MyThread extends Thread{ // extending the class Thread
	public void run(){
		for(int i=0; i<5; i++){
			System.out.println("by : "+Thread.currentThread().getName()+" "+i);

			try{	
				Thread.sleep(500);
			}catch(Exception e){
				e.printStackTrace();
			}
		}

	}

}
//The above mentioned way of creating thread by extending the Thread  class is not the recommeded way to create thread by java because it does not support multiple inheritance when some other class(other than thread) is to be extended.

class ThreadDemo2{
	public static void main(String[] args) {
		System.out.println("Main Starts");

		MyThread mt1 = new MyThread(); 
		// Creating an instance of Thread Class directly. Instance of Thread is always runnable. 
		mt1.start(); // Only runnable instance can call to start()method.
		for(int i=0; i<5; i++){
			System.out.println("by : "+Thread.currentThread().getName()+" "+i);

			try{	
				Thread.sleep(1000);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		System.out.println("Main Ends");
		
	}
}