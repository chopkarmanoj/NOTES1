class Chair{
	String color;
	static int cost;
	void displayChair(){
		System.out.println("color : "+color);
		System.out.println("cost : "+cost);
	}
}

class StaticDemo{
	public static void main(String[] args) {
		Chair.cost = 400;		//Static can be directly accessed by the class
		Chair c1 = new Chair();
		c1.color = "black";
		//c1.cost = 400;
		
		Chair c2 = new Chair();
		c2.color = "red";
		

		displayChairair c3 = new Chair();
		c3.color = "Blue";
		c3.cost = 500; //Static can also be accessed by the instance and the same static attribute is shared by all the instances.

		c1.displayChair();	
		c2.displayChair();
		c3.displayChair();

	}
}