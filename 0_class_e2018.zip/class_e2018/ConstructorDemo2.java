class Animal{
	double height;
	Animal(){
		height = 4.5;
	}
	Animal(double h){
		height = h;
	}

}
class Dog extends Animal{
	int legs;
	String name;

	Dog(){
		legs = 4;
		name = "Tommy";
	}

	Dog(int l, String n, double h){
		super(h); // super() constructor is used to call the constructor of the super class
		legs = l;
		name = n;
	}

	void display(){
		System.out.println("height is : "+height);
		System.out.println("legs are : "+legs);
		System.out.println("name is : "+name);
	}
	

}
class ConstructorDemo2{
	public static void main(String[] args) {
		Dog d1 = new Dog(2,"Tuffy", 5.5);
		d1.display();

		Dog d2 = new Dog();
		d1.display();
	}	
}