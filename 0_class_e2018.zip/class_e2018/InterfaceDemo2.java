interface Testable{
	int x = 10 ;
}
class Test implements Testable{
	void t1(){
		// x = 30; cannot reassign values to any interface variable as the interface variables are final
		System.out.println("x is : "+x);
	}
}
class InterfaceDemo2{
	public static void main(String[] args) {
		Test t1 = new Test();
		t1.t1();
	}
}