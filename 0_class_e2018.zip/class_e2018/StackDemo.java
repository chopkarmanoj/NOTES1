class MyStack{
	int[] stk;
	int top;
	
	void init(){
		stk = new int[5];
		top = -1;
	}
	//Modify the push method in such a way that 
	// the Stack should never say Stack Full
	// (Hint : if the stack is full, create a new stack with double size and 
	// 		copy all prev ele in it)
	

	void push(int val){
		if((stk.length-1) == top){
		System.out.println("Stack Overflow");
	}else{
		stk[++top] = val;
		System.out.println("Element Pushed : " +val);
	}
	

	}

	int pop(){
		int z = -1;
		if(top == -1){
			System.out.println("Stack Empty");
		}else{
			z = stk[top--];
		}
	return z;
	}

	void displayStack(){
		System.out.println("------------------------");
		for (int i=top; i>=0 ; i-- ) {
			System.out.println("Stack["+i+"] = "+stk[i]);
			}
		System.out.println("--------------------");
	}

}
class StackDemo{
	public static void main(String[] args) {
		MyStack S = new MyStack();
		S.init();
		S.push(1);
		//S.displayStack();
		S.push(2);
		S.push(3);
		S.push(4);
		S.push(5);
		S.push(6);
		//S.displayStack();
		//S.pop();
		S.displayStack();
		
		System.out.println("Element popped :"+S.pop());
		System.out.println("Element popped :"+S.pop());
		System.out.println("Element popped :"+S.pop());
		System.out.println("Element popped :"+S.pop());
		System.out.println("Element popped :"+S.pop());
		System.out.println("Element popped :"+S.pop());
		S.displayStack();
		
				

	}
}