import java.io.*;

class PrintWriterDemo{
public static void main(String[] args) {
	try{
		File f1 = new File("xyz.txt");
		PrintWriter pw = new PrintWriter(f1);

		pw.println(10);
		pw.println(12.34);
		pw.println("this is string");
		pw.println('c');

		pw.flush();
		pw.close();

	}catch(Exception e){ e.printStackTrace();}
}
}