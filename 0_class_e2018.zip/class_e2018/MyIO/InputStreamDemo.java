import java.io.*;
class InputStreamDemo{
	public static void main(String[] args) {
		try{
			InputStreamReader isr = new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(isr);
			String ch = "Y";
			String str = "";
			while(ch.equalsIgnoreCase("Y")){
			System.out.println(" Enter Text ");
			str += br.readLine();
			System.out.println(" Do you wish to write next line ? Enter Y for YES and N for NO");
			// ch = (char) br.read();
			// System.out.println(ch);
			ch = br.readLine();
		}
		System.out.println("You just typed : "+str);
		}catch(Exception e){ e.printStackTrace();}
	}
}