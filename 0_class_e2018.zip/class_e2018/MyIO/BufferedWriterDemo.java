// This for bulky write operations where we can afford to write character by character
// These are not appendable
// FileWriter only has the appendable constructor

import java.io.*;
class BufferedWriterDemo{
	public static void main(String[] args) {
		try{
			File f1 = new File ("abc.txt");
			FileWriter fw = new FileWriter(f1);
			BufferedWriter bw = new BufferedWriter(fw);

			bw.write(" Hey this is the first line in the file");
			bw.newLine();
			bw.write("This is the secondline ");
			bw.write("This is the third line");
			bw.flush();
			bw.close();
			
		}catch( Exception e){ e. printStackTrace();}
	}
}