import java.io.*;
class FileWriterDemo{
	public static void main(String[] args) {
		try{
			//Objects written inside try-catch block are accessible only in the try-catch block
			File f1 = new File("xyz.txt");
			FileWriter fw = new FileWriter(f1);

			String str = "This is the first line in the file";
			fw.write(str);
			fw.write("\n This may be the 2nd line...");
			

			fw.flush(); // it transfer the contents from primary storage to secondary storage
			fw.close(); // close methods autoflushes the contents of the buffer before closing

		}catch(Exception e){ e.printStackTrace(); }
	}
}