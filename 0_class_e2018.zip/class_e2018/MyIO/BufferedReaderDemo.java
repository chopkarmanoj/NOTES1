import java.io.*;
class BufferedReaderDemo{
	public static void main(String[] args) {
		try{
			File f1 = new File("FileReaderDemo.java");
			FileReader fr = new FileReader(f1);
			BufferedReader br = new BufferedReader(fr);
			
			// String str = br.readLine();
			// System.out.println(str);

			String tmp;
				while((tmp = br.readLine()) != null){
				System.out.println(tmp);
			}
			

		}catch(Exception e){ e.printStackTrace();

		}
	}
}