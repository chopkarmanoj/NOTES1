import java.io.*;

class FileAppendDemo{
	public static void main(String[] args) {
	try{
		File f1 = new File("xyz.txt");
		FileWriter fw = new FileWriter(f1, true);
		fw.write("\n This may be the Third line..");
		fw.write("\n z");
		fw.write(105);
		fw.flush();
		fw.close();

	}catch (Exception e){ e.printStackTrace();}
	}
}