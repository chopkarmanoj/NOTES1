import java.io.*;
class CopyFileD{
			void myCopy(String source, String dest){
			try{
				File f1 = new File(dest);
				File f2 = new File(source);
				

				 FileReader fr = new FileReader(f2);
				 FileWriter fw = new FileWriter(f1);
				 int x;
				while((x = fr.read()) != -1){
					fw.write(x);
				}			
				fw.flush();
				fw.close();

				System.out.println("File "+source+" copied to "+dest+" succesfully !!!");
			}catch(Exception e){ e.printStackTrace();}
		}
}

class CopyFileDemo{
	public static void main(String[] args) {
		CopyFileD cf = new CopyFileD();
		cf.myCopy("CopyFileDemo.java","Duplicate_CopyFileDemo.java");
	}
}