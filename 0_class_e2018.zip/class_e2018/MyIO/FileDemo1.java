import java.io.*;
class FileDemo1{
	public static void main(String[] args) {
		try{
			File f1 = new File("a");
			f1.mkdir();

			File f2 = new File(f1, "b");
			f2.mkdir();

			File f3 =  new File(f2, "ab.txt"); //Here f1 is the parent
			f3.createNewFile();

			File [] ary = f1.listFiles();
			for(File x : ary){
				System.out.println(x.getName());
			}

		}catch(Exception e){
			e.printStackTrace();
		}
	}
}