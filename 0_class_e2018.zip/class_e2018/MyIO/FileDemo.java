import java.io.*;

class FileDemo{
	public static void main(String[] args) {
		try{
			File f1 = new File("abc.txt"); //File is a class available in io package. f1 is an object of class FILE
			f1.createNewFile();	//Method to create new file
			System.out.println("Path : "+f1.getAbsolutePath());
			System.out.println("Name of the file : "+f1.getName());
			System.out.println("is file : "+f1.isFile());
			System.out.println("is dir : "+f1.isDirectory());
			System.out.println("is hidden : "+f1.isHidden());
			System.out.println("last modified :"+f1.lastModified());
			System.out.println("Size of file : "+f1.length());
			System.out.println("Is Readable ? "+f1.canRead());
			System.out.println("is Writable ? "+f1.canWrite());

			//f1.delete();

			File f2 = new File("xyz.txt");
			f1.renameTo(f2);
			//f2.delete();
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
}