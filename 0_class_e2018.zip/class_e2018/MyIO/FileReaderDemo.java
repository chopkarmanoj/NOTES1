import java.io.*;
class FileReaderDemo{
	public static void main(String[] args) {
		try{
			File f1 = new File("FileReaderDemo.java");
			FileReader fr = new FileReader(f1); //Recommended way of creating Reader in Java
			char x = (char) fr.read();
			System.out.println(x);

			int x1;
			while((x1 = fr.read()) != -1){
				System.out.print((char)x1);
			}

			char [] ch = new char[25];
			fr.read(ch); // will read only first 25 characters

			for(char x2 : ch){
				System.out.print(x2);
			}
			fr.close();
		}catch(Exception e){ e.printStackTrace(); }
	
	}

}