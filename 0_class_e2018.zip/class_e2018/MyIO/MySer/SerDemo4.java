//Serialization in is-a relationship
//If super class is also marked serializable then its attributes are also serialized and no default constructor is called during deserialization
//If the super class is not marked serializable then only the attributes of subclass are serialized, no attribute of super class is serialized. During deserialization it makes a call to the default constructor of the super class. Therefore, it is mandatory for super class to have default constructor to avoid exception during deserialization.

import java.io.*;

class Animal implements Serializable { //

	int legs;
	Animal(){
		legs = 4;
	}
	//Parametrized Constructor
	// Animal(int l){
	// 	legs = l;
	// }
}

class Frog extends Animal implements Serializable{
	String type;
	String color;
	Frog(){
		//super(16); Value for parameterized constructor for super class
		type = "Long Jumping Frog";
		color = "Dark Green";
	}

	void displayFrog(){
		System.out.println("Frog type is : "+type);
		System.out.println("Color is : "+color);
		System.out.println("Legs are : "+legs);
	}
}
class SerDemo4{
	public static void main(String[] args) {
		Frog f1 = new Frog();
		f1.legs = 10;
		f1.color = "Black";
		f1.displayFrog();
		try{
		ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream("FrogObj.Ser"));
		os.writeObject(f1);
		System.out.println("-------Frog Serialized-----------");

		ObjectInputStream is = new ObjectInputStream(new FileInputStream("FrogObj.Ser"));
		Frog f = (Frog) is.readObject();
		f.displayFrog();
		System.out.println("-------Frog Deserialized----------");
		} catch(Exception e){e.printStackTrace();}

	}
}
