// Serialization in has-a relationship

//All the objects which are in a has-a relationship with the class which is to be serialized must also implements serializable
//Here we want to serialize the object of class House
//House has-a Kitchen i.e another class
//In-order to serialize House class we need to serialize the Kitchen first
//Hence we write kitchen implements Serializable
//If kitchen is not marked  serializable then it does not allow to serialize House class also 


import java.io.*;
class Kitchen implements Serializable{
	int spoons;
	Kitchen(){
		spoons = 10;
	}
}


class House implements Serializable{
	String name;
	int rooms;
	Kitchen k; 

	House(){
		name = "Yatrik";
		rooms = 5;
		k = new Kitchen();
	}

	void displayHouse(){
		System.out.println("-------House-----------");
		System.out.println("House Name : "+name);
		System.out.println("Rooms in the house : "+rooms);
		System.out.println("Spoons in he kitchen are : "+k.spoons);
		System.out.println("------------------------");
	}

}

class SerDemo3{
	public static void main(String[] args) {
		House h = new House();
		h.displayHouse();
		try{
		ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream("HouseObj.Ser"));
		os.writeObject(h);
		System.out.println("House Serialized");

		System.out.println("After Deserialization");
		ObjectInputStream is = new ObjectInputStream(new FileInputStream("HouseObj.Ser"));
		House h1 = (House) is.readObject();
		h1.displayHouse();

	}catch(Exception e){e.printStackTrace();}
	}
}