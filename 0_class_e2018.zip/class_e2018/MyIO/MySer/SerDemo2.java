import java.io.*;
class Animal implements Serializable{
	String name;
	transient int legs; // this will omit the value of the attribute while saving the object state

	Animal(){
		name = "Elephant";
		legs = 4;
	}

	void displayAnimal(){
		System.out.println("Animal Name : "+name);
		System.out.println("Legs are : "+legs);
	}
}
class SerDemo2{
	public static void main(String[] args) {
		try{
			Animal a1 = new Animal();
			System.out.println("-------------Before Serialization-------------");
			a1.displayAnimal();

			ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream("AnimalObj.ser"));
			os.writeObject(a1);
			System.out.println("---------------Animal Serialized---------------");


			ObjectInputStream is = new ObjectInputStream(new FileInputStream("AnimalObj.ser"));
			Animal a2 = (Animal) is.readObject();
			a2.displayAnimal();
			System.out.println("----------Deserialization Done----------------");
		}catch(Exception e){e.printStackTrace();}
	}

}