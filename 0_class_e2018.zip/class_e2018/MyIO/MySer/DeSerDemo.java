import java.io.*;
class DeSerDemo{
	public static void main(String[] args){
		try{
			//Deserialization
			FileInputStream fis = new FileInputStream("Person.ser");
			ObjectInputStream is = new ObjectInputStream(fis);


			Person p = (Person) is.readObject(); //Casting the object returned by readObject to object Person
			p.displayPerson();
			System.out.println("Object State Retrieved Successfully");

		}catch(Exception e){ e.printStackTrace();}
		}
	
}