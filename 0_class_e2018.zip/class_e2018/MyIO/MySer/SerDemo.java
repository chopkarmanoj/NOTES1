import java.io.*;

class Person implements Serializable{
	String name;
	int age;

void displayPerson(){
	System.out.println("Person Name : "+name);
	System.out.println("age is : "+age);
}
} 

class SerDemo{
	public static void main(String[] args) {
		Person p1 = new Person();
		p1.name = "RamuKaka";
		p1.age = 45;
		p1.displayPerson();

		//Serialization
		try{
			FileOutputStream fos = new FileOutputStream("Person.ser");
			ObjectOutputStream os = new ObjectOutputStream(fos);
			os.writeObject(p1);
			System.out.println("Object Write Operation Performed");

		}catch(Exception e){ e.printStackTrace();}

	}
}