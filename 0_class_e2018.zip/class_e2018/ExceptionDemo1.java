class ExceptionDemo1{
	public static void main(String[] args) {
		System.out.println("Main Starts");
		// try{
			
		// 	int[] ary = {10,20,30};
		// 	System.out.println("ary 3 : "+ary[3]);
		// 	int a = 10/0;

		// }catch(ArithmeticException e){
		// 	System.out.println("There is an Arithmetic Exception");
		// }

		// catch(ArrayIndexOutOfBoundsException a){
		// 	System.out.println("Out of Bound Exception, Kindly access the array within index");
		// }

		try{
			//int a = 10/0;
			int[] ary = {10,20,30};
			System.out.println("ary 3 : "+ary[3]);
		}catch(Exception e){
					System.out.println("There is an Exception");
		}
		System.out.println("Main Ends");
	}
}
