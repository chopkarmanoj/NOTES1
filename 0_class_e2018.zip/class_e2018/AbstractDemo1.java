abstract class GrandFather{
	void job(){
		System.out.println("--doing job");
	}
	abstract void car();
	abstract void house();
}

abstract class Father extends GrandFather{
	void plot(){
		System.out.println("on plot");
	}
	void house(){
		System.out.println("Inside House");
	}
	abstract void govtJob();
}
class Child extends Father{
	void govtJob(){
		System.out.println("on govt job");
	}
	void car(){
	System.out.println("in car");
}
}

class AbstractDemo1{
	public static void main(String[] args) {
		Child c = new Child();
		c.job();
		c.house();
		c.car();
		c.plot();
	}
}