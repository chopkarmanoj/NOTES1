class StringDemo{
	public static void main(String[] args) {
		String s1 = new String("abc");
		String s2 = "xyz" ; //Java converts this to new String("xyz") if xyz is already not available in the Heap
		
		System.out.println(s1);
		System.out.println(s2);

		
		s1.concat("pqr");
		System.out.println(s1);
		s1 = s1.concat("pqr");
		System.out.println(s1);
		System.out.println(s1.concat("pqr"));

		
		String s3 = new String ("Shamu");
		String s4 = new String ("Shamu");

		String s5 = "Ramu";
		//String s4 = new String("Ramu"); // This will expilicity create a new object s4 with value "Ramu"
		String s6 = "Ramu"; 
		//--> It checks if any object is already available in Heap with same value, if it is present it will not make a new object it will simply assign the refrerence of existing object to the new one

		if(s5 == s6){ // this is actually the comparasion of references not values
			System.out.println("s5 and s6 are equal");
		}else{
			System.out.println("s5 != s6");
		}

		// TO check ot compares values of String Objects
					if(s3.equals(s4)){ //.equals method check the values of the string
				System.out.println("Value of s3 and s4 are equal");
			}else{
				System.out.println("s3 and s4 values are not equal");
			}
	}
}